"""
Acyclic_causal_graph
====================

Causal discovery for acyclic (DAG / CPDAG) structures on cross-sectional data:
PC, NOTEARS, GES and DirectLiNGAM.

Every function takes a DataFrame produced by ``Utils.preprocess_df``
(standardised numeric features and 0/1 binary features) and returns a dict
with at least:

* ``method``     : name of the algorithm
* ``adjacency``  : DataFrame where ``adjacency.loc[i, j] != 0`` means ``i -> j``
* ``edges``      : edge list DataFrame (source, target, weight)
* ``is_dag``     : whether the directed part of the graph is acyclic

Dependencies: numpy, pandas, scipy, causal-learn (PC, GES), lingam (LiNGAM).

Notes
-----
Author : Navita Singh
Date : 2026-10-28
Version : 1
Change log :
    v1 (2026-10-28) : Initial version.
"""

from typing import Any, Dict, List, Tuple

import numpy as np
import pandas as pd
import scipy.linalg as slin
import scipy.optimize as sopt

from Utils import adjacency_to_edges, is_dag, validate_input_df


def _cpdag_matrix_to_result(
    graph: np.ndarray, columns: List[str]
) -> Tuple[pd.DataFrame, List[Tuple[str, str]], List[Tuple[str, str]]]:
    """
    Convert a causal-learn graph matrix into an adjacency DataFrame.

    causal-learn convention: ``graph[j, i] == 1`` and ``graph[i, j] == -1``
    means ``i -> j``; both ``-1`` means ``i --- j`` (undirected); both ``1``
    means ``i <-> j``.

    Parameters
    ----------
    graph : numpy.ndarray
        Square graph matrix from causal-learn (``G.graph``).
    columns : list of str
        Variable names in matrix order.

    Returns
    -------
    adjacency : pandas.DataFrame
        1 where ``i -> j`` is directed.
    undirected : list of tuple
        Pairs connected by an undirected edge.
    bidirected : list of tuple
        Pairs connected by a bidirected edge.

    Raises
    ------
    None

    Examples
    --------
    >>> adj, und, bi = _cpdag_matrix_to_result(cg.G.graph, list(df.columns))

    Notes
    -----
    Author : Navita Singh
    Date : 2026-10-28
    Version : 1
    Change log :
        v1 (2026-10-28) : Initial version.
    """
    d = len(columns)
    adj = np.zeros((d, d))
    undirected, bidirected = [], []
    for i in range(d):
        for j in range(i + 1, d):
            a, b = graph[i, j], graph[j, i]
            if a == -1 and b == 1:
                adj[i, j] = 1
            elif a == 1 and b == -1:
                adj[j, i] = 1
            elif a == -1 and b == -1:
                undirected.append((columns[i], columns[j]))
            elif a == 1 and b == 1:
                bidirected.append((columns[i], columns[j]))
    return pd.DataFrame(adj, index=columns, columns=columns), undirected, bidirected


def _package_result(method: str, adjacency: pd.DataFrame, **extra: Any) -> Dict[str, Any]:
    """
    Assemble the common result dictionary.

    Parameters
    ----------
    method : str
        Algorithm name.
    adjacency : pandas.DataFrame
        Directed adjacency matrix (``i -> j`` when non-zero).
    **extra
        Additional entries added to the dictionary.

    Returns
    -------
    dict
        Keys ``method``, ``adjacency``, ``edges``, ``is_dag`` plus ``extra``.

    Raises
    ------
    None

    Examples
    --------
    >>> res = _package_result("PC", adjacency)

    Notes
    -----
    Author : Navita Singh
    Date : 2026-10-28
    Version : 1
    Change log :
        v1 (2026-10-28) : Initial version.
    """
    result = {
        "method": method,
        "adjacency": adjacency,
        "edges": adjacency_to_edges(adjacency),
        "is_dag": is_dag(adjacency),
    }
    result.update(extra)
    return result


# --------------------------------------------------------------------------- #
# PC
# --------------------------------------------------------------------------- #
def run_pc(
    df: pd.DataFrame,
    alpha: float = 0.05,
    indep_test: str = "fisherz",
    stable: bool = True,
) -> Dict[str, Any]:
    """
    Run the PC (Peter-Clark) constraint-based algorithm.

    PC learns a CPDAG (an equivalence class of DAGs) using conditional
    independence tests, so some edges may stay undirected.

    Parameters
    ----------
    df : pandas.DataFrame
        Standardised numeric features and 0/1 binary features
        (see ``Utils.preprocess_df``).
    alpha : float, default 0.05
        Significance level of the independence tests.
    indep_test : str, default "fisherz"
        Test name passed to causal-learn (``"fisherz"``, ``"chisq"``,
        ``"gsq"``, ``"kci"``...). ``"fisherz"`` assumes roughly continuous,
        Gaussian data and is only an approximation for binary columns.
    stable : bool, default True
        Use the order-independent (stable) skeleton search.

    Returns
    -------
    dict
        ``method``, ``adjacency`` (directed edges only), ``edges``,
        ``is_dag``, ``undirected_edges`` and ``bidirected_edges`` (lists of
        column-name pairs).

    Raises
    ------
    ImportError
        If ``causal-learn`` is not installed.
    TypeError, ValueError
        If ``df`` fails validation.

    Examples
    --------
    >>> from Utils import preprocess_df
    >>> from Acyclic_causal_graph import run_pc
    >>> res = run_pc(preprocess_df(raw_df), alpha=0.01)
    >>> res["edges"]

    Notes
    -----
    Author : Navita Singh
    Date : 2026-10-28
    Version : 1
    Change log :
        v1 (2026-10-28) : Initial version.
    """
    try:
        from causallearn.search.ConstraintBased.PC import pc
    except ImportError as exc:
        raise ImportError("Install causal-learn: pip install causal-learn") from exc

    X = validate_input_df(df)
    cg = pc(X, alpha=alpha, indep_test=indep_test, stable=stable,
            verbose=False, show_progress=False)
    adj, und, bi = _cpdag_matrix_to_result(cg.G.graph, list(df.columns))
    return _package_result("PC", adj, undirected_edges=und, bidirected_edges=bi)


# --------------------------------------------------------------------------- #
# NOTEARS
# --------------------------------------------------------------------------- #
def _notears_linear(
    X: np.ndarray,
    lambda1: float,
    max_iter: int,
    h_tol: float,
    rho_max: float,
    w_threshold: float,
) -> np.ndarray:
    """
    Solve linear NOTEARS with an augmented Lagrangian and L-BFGS-B.

    Minimises ``0.5/n * ||X - XW||^2 + lambda1 * ||W||_1`` subject to the
    acyclicity constraint ``tr(exp(W * W)) - d = 0`` (Zheng et al., 2018).

    Parameters
    ----------
    X : numpy.ndarray
        Data matrix (n_samples, n_features).
    lambda1 : float
        L1 penalty.
    max_iter : int
        Maximum number of dual ascent steps.
    h_tol : float
        Tolerance on the acyclicity measure.
    rho_max : float
        Upper bound of the penalty parameter.
    w_threshold : float
        Weights with absolute value below this are set to zero.

    Returns
    -------
    numpy.ndarray
        Weighted adjacency matrix ``W`` where ``W[i, j]`` is the effect
        ``i -> j``.

    Raises
    ------
    None

    Examples
    --------
    >>> W = _notears_linear(X, 0.1, 100, 1e-8, 1e16, 0.3)

    Notes
    -----
    Author : Navita Singh
    Date : 2026-10-28
    Version : 1
    Change log :
        v1 (2026-10-28) : Initial version.
    """
    n, d = X.shape

    def _adj(w):
        return (w[: d * d] - w[d * d:]).reshape(d, d)

    def _loss(W):
        R = X - X @ W
        return 0.5 / n * (R ** 2).sum(), -1.0 / n * X.T @ R

    def _h(W):
        E = slin.expm(W * W)
        return np.trace(E) - d, E.T * W * 2

    def _func(w):
        W = _adj(w)
        loss, G_loss = _loss(W)
        h, G_h = _h(W)
        obj = loss + 0.5 * rho * h * h + alpha * h + lambda1 * w.sum()
        G_smooth = G_loss + (rho * h + alpha) * G_h
        g_obj = np.concatenate((G_smooth + lambda1, -G_smooth + lambda1), axis=None)
        return obj, g_obj

    w_est, rho, alpha, h = np.zeros(2 * d * d), 1.0, 0.0, np.inf
    bounds = [(0, 0) if i == j else (0, None)
              for _ in range(2) for i in range(d) for j in range(d)]

    for _ in range(max_iter):
        w_new, h_new = None, None
        while rho < rho_max:
            sol = sopt.minimize(_func, w_est, method="L-BFGS-B", jac=True, bounds=bounds)
            w_new = sol.x
            h_new, _ = _h(_adj(w_new))
            if h_new > 0.25 * h:
                rho *= 10
            else:
                break
        if w_new is None:
            break
        w_est, h = w_new, h_new
        alpha += rho * h
        if h <= h_tol or rho >= rho_max:
            break

    W_est = _adj(w_est)
    W_est[np.abs(W_est) < w_threshold] = 0
    return W_est


def run_notears(
    df: pd.DataFrame,
    lambda1: float = 0.1,
    max_iter: int = 100,
    h_tol: float = 1e-8,
    rho_max: float = 1e16,
    w_threshold: float = 0.3,
) -> Dict[str, Any]:
    """
    Run linear NOTEARS (continuous DAG optimisation).

    Learns a weighted DAG by solving a smooth constrained optimisation
    problem with a least-squares loss, L1 sparsity and a differentiable
    acyclicity constraint.

    Parameters
    ----------
    df : pandas.DataFrame
        Standardised numeric features and 0/1 binary features. Columns are
        mean-centred internally (the model has no intercept).
    lambda1 : float, default 0.1
        L1 regularisation strength; larger values give sparser graphs.
    max_iter : int, default 100
        Maximum number of dual ascent iterations.
    h_tol : float, default 1e-8
        Tolerance for the acyclicity constraint.
    rho_max : float, default 1e16
        Maximum value of the augmented Lagrangian penalty.
    w_threshold : float, default 0.3
        Absolute weights below this value are pruned to 0.

    Returns
    -------
    dict
        ``method``, ``adjacency`` (weighted, ``[i, j]`` = effect i -> j),
        ``edges`` and ``is_dag``. If thresholding leaves a cycle, increase
        ``w_threshold`` or ``lambda1``.

    Raises
    ------
    TypeError, ValueError
        If ``df`` fails validation or hyper-parameters are invalid.

    Examples
    --------
    >>> res = run_notears(preprocess_df(raw_df), lambda1=0.05, w_threshold=0.2)
    >>> res["adjacency"]

    Notes
    -----
    Binary variables are treated as continuous, so edges involving them
    should be interpreted with care.

    Author : Navita Singh
    Date : 2026-10-28
    Version : 1
    Change log :
        v1 (2026-10-28) : Initial version.
    """
    if lambda1 < 0 or w_threshold < 0:
        raise ValueError("`lambda1` and `w_threshold` must be non-negative.")
    X = validate_input_df(df)
    X = X - X.mean(axis=0, keepdims=True)
    W = _notears_linear(X, lambda1, max_iter, h_tol, rho_max, w_threshold)
    adj = pd.DataFrame(W, index=df.columns, columns=df.columns)
    return _package_result("NOTEARS", adj)


# --------------------------------------------------------------------------- #
# GES
# --------------------------------------------------------------------------- #
def run_ges(df: pd.DataFrame, score_func: str = "local_score_BIC") -> Dict[str, Any]:
    """
    Run GES (Greedy Equivalence Search), a score-based algorithm.

    GES greedily adds and then removes edges to maximise a decomposable
    score, returning a CPDAG.

    Parameters
    ----------
    df : pandas.DataFrame
        Standardised numeric features and 0/1 binary features.
    score_func : str, default "local_score_BIC"
        causal-learn score (``"local_score_BIC"``, ``"local_score_BDeu"``,
        ``"local_score_CV_general"``...). BIC suits continuous data.

    Returns
    -------
    dict
        ``method``, ``adjacency`` (directed edges only), ``edges``,
        ``is_dag``, ``undirected_edges``, ``bidirected_edges`` and ``score``.

    Raises
    ------
    ImportError
        If ``causal-learn`` is not installed.
    TypeError, ValueError
        If ``df`` fails validation.

    Examples
    --------
    >>> res = run_ges(preprocess_df(raw_df))
    >>> res["score"]

    Notes
    -----
    GES can be slow on many columns, since the search is greedy over
    equivalence classes.

    Author : Navita Singh
    Date : 2026-10-28
    Version : 1
    Change log :
        v1 (2026-10-28) : Initial version.
    """
    try:
        from causallearn.search.ScoreBased.GES import ges
    except ImportError as exc:
        raise ImportError("Install causal-learn: pip install causal-learn") from exc

    X = validate_input_df(df)
    record = ges(X, score_func=score_func)
    adj, und, bi = _cpdag_matrix_to_result(record["G"].graph, list(df.columns))
    return _package_result(
        "GES", adj, undirected_edges=und, bidirected_edges=bi, score=record.get("score")
    )


# --------------------------------------------------------------------------- #
# LiNGAM
# --------------------------------------------------------------------------- #
def run_lingam(
    df: pd.DataFrame,
    min_weight: float = 0.0,
    measure: str = "pwling",
    random_state: int = None,
) -> Dict[str, Any]:
    """
    Run DirectLiNGAM (Linear Non-Gaussian Acyclic Model).

    Identifies a fully directed DAG assuming linear relations and
    non-Gaussian, independent noise.

    Parameters
    ----------
    df : pandas.DataFrame
        Standardised numeric features and 0/1 binary features.
    min_weight : float, default 0.0
        Absolute coefficients ``<= min_weight`` are set to 0.
    measure : str, default "pwling"
        Independence measure used by DirectLiNGAM (``"pwling"`` or
        ``"kernel"``).
    random_state : int, optional
        Seed for reproducibility.

    Returns
    -------
    dict
        ``method``, ``adjacency`` (``[i, j]`` = effect i -> j), ``edges``,
        ``is_dag`` and ``causal_order`` (variable names, causes first).

    Raises
    ------
    ImportError
        If ``lingam`` is not installed.
    TypeError, ValueError
        If ``df`` fails validation.

    Examples
    --------
    >>> res = run_lingam(preprocess_df(raw_df), min_weight=0.05, random_state=0)
    >>> res["causal_order"]

    Notes
    -----
    The lingam package stores ``B`` with ``B[i, j]`` = effect of ``j`` on
    ``i``; it is transposed here so all functions share the ``i -> j``
    convention. Results are most reliable when the data are non-Gaussian.

    Author : Navita Singh
    Date : 2026-10-28
    Version : 1
    Change log :
        v1 (2026-10-28) : Initial version.
    """
    try:
        import lingam
    except ImportError as exc:
        raise ImportError("Install lingam: pip install lingam") from exc

    X = validate_input_df(df)
    model = lingam.DirectLiNGAM(random_state=random_state, measure=measure)
    model.fit(X)

    B = np.array(model.adjacency_matrix_, dtype=float)
    B[np.abs(B) <= min_weight] = 0
    adj = pd.DataFrame(B.T, index=df.columns, columns=df.columns)
    order = [df.columns[i] for i in model.causal_order_]
    return _package_result("LiNGAM", adj, causal_order=order)
