"""
Utils
=====

Generic helper functions for the causal discovery repository: reading and
writing files, preprocessing a raw DataFrame, validating model inputs and
converting graph representations.

Notes
-----
Author : Navita Singh
Date : 2026-10-28
Version : 1
Change log :
    v1 (2026-10-28) : Initial version.
"""

import logging
import os
import warnings
from typing import Dict, List, Optional, Sequence

import numpy as np
import pandas as pd
from pandas.api.types import (
    is_bool_dtype,
    is_datetime64_any_dtype,
    is_numeric_dtype,
    is_timedelta64_dtype,
)

logger = logging.getLogger(__name__)

_NULL_STRATEGIES = ("none", "drop", "impute")

# --------------------------------------------------------------------------- #
# Directories
# --------------------------------------------------------------------------- #

DATA_DIR = r"C:\Laptop_current\git_projects\causality_cd\dataset_causRCA"
REAL_OP_DIR = r"C:\Laptop_current\git_projects\causality_cd\dataset_causRCA\real_op"
OUTPUT_DIR = os.path.join(DATA_DIR, "eda")
GROUND_TRUTH_DIR = os.path.join(DATA_DIR, "ground_truth/")
PREDICTION_DIR = os.path.join(DATA_DIR, "predictions/")

FULL_GRAPH_DIR = os.path.join(DATA_DIR, "expert_graph")  # all_edges.csv, all_nodes.csv
COOLANT_DIR = os.path.join(DATA_DIR, "dig_twin/exp_coolant")        # coolant_*.csv
HYDRAULICS_DIR = os.path.join(DATA_DIR, "dig_twin/exp_hydraulics")  # hydraulics_*.csv
PROBE_DIR = os.path.join(DATA_DIR, "dig_twin/exp_probe")            # probe_*.csv

# --------------------------------------------------------------------------- #
# File I/O
# --------------------------------------------------------------------------- #
def read_file(file_path: str, **kwargs) -> pd.DataFrame:
    """
    Read a tabular file into a pandas DataFrame.

    The reader is chosen from the file extension. Supported extensions are
    ``.csv``, ``.tsv``, ``.txt``, ``.xlsx``, ``.xls``, ``.parquet``,
    ``.json`` and ``.pkl``.

    Parameters
    ----------
    file_path : str
        Path of the file to read.
    **kwargs
        Extra keyword arguments forwarded to the underlying pandas reader.

    Returns
    -------
    pandas.DataFrame
        The data contained in the file.

    Raises
    ------
    FileNotFoundError
        If ``file_path`` does not exist.
    ValueError
        If the file extension is not supported.

    Examples
    --------
    >>> df = read_file("data/raw_data.csv")
    >>> df = read_file("data/raw_data.xlsx", sheet_name="Sheet1")

    Notes
    -----
    Author : Navita Singh
    Date : 2026-10-28
    Version : 1
    Change log :
        v1 (2026-10-28) : Initial version.
    """
    if not os.path.isfile(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")

    ext = os.path.splitext(file_path)[1].lower()
    readers = {
        ".csv": pd.read_csv,
        ".txt": pd.read_csv,
        ".tsv": lambda p, **kw: pd.read_csv(p, sep="\t", **kw),
        ".xlsx": pd.read_excel,
        ".xls": pd.read_excel,
        ".parquet": pd.read_parquet,
        ".json": pd.read_json,
        ".pkl": pd.read_pickle,
    }
    if ext not in readers:
        raise ValueError(
            f"Unsupported file extension '{ext}'. Supported: {sorted(readers)}"
        )
    return readers[ext](file_path, **kwargs)


def write_file(df: pd.DataFrame, file_path: str, index: bool = False, **kwargs) -> str:
    """
    Write a DataFrame to disk, creating parent folders when required.

    The writer is chosen from the file extension. Supported extensions are
    ``.csv``, ``.tsv``, ``.xlsx``, ``.parquet``, ``.json`` and ``.pkl``.

    Parameters
    ----------
    df : pandas.DataFrame
        Data to write.
    file_path : str
        Destination path.
    index : bool, default False
        Whether to write the DataFrame index (ignored for ``.pkl``).
    **kwargs
        Extra keyword arguments forwarded to the underlying pandas writer.

    Returns
    -------
    str
        The path that was written.

    Raises
    ------
    TypeError
        If ``df`` is not a pandas DataFrame.
    ValueError
        If the file extension is not supported.

    Examples
    --------
    >>> write_file(df, "output/clean_data.csv")
    'output/clean_data.csv'

    Notes
    -----
    Author : Navita Singh
    Date : 2026-10-28
    Version : 1
    Change log :
        v1 (2026-10-28) : Initial version.
    """
    if not isinstance(df, pd.DataFrame):
        raise TypeError("`df` must be a pandas DataFrame.")

    ext = os.path.splitext(file_path)[1].lower()
    folder = os.path.dirname(file_path)
    if folder:
        os.makedirs(folder, exist_ok=True)

    if ext == ".csv":
        df.to_csv(file_path, index=index, **kwargs)
    elif ext == ".tsv":
        df.to_csv(file_path, sep="\t", index=index, **kwargs)
    elif ext == ".xlsx":
        df.to_excel(file_path, index=index, **kwargs)
    elif ext == ".parquet":
        df.to_parquet(file_path, index=index, **kwargs)
    elif ext == ".json":
        df.to_json(file_path, **kwargs)
    elif ext == ".pkl":
        df.to_pickle(file_path, **kwargs)
    else:
        raise ValueError(f"Unsupported file extension '{ext}'.")
    return file_path


# --------------------------------------------------------------------------- #
# Column type detection, EDA and preprocessing
# --------------------------------------------------------------------------- #
def _is_binary_series(series: pd.Series) -> bool:
    """
    Check whether a Series is binary, i.e. boolean or containing only 0 and 1.

    Parameters
    ----------
    series : pandas.Series
        Series to inspect. Nulls are ignored.

    Returns
    -------
    bool
        True if the series is boolean or numeric with values in {0, 1}.

    Raises
    ------
    None

    Examples
    --------
    >>> _is_binary_series(pd.Series([0, 1, 1, 0]))
    True

    Notes
    -----
    Author : Navita Singh
    Date : 2026-10-28
    Version : 1
    Change log :
        v1 (2026-10-28) : Initial version.
    """
    if is_bool_dtype(series):
        return True
    if not is_numeric_dtype(series):
        return False
    values = series.dropna().unique()
    return len(values) > 0 and set(values).issubset({0, 1})


def detect_column_types(
    df: pd.DataFrame,
    categorical_cols: Optional[Sequence[str]] = None,
    binary_cols: Optional[Sequence[str]] = None,
) -> Dict[str, List[str]]:
    """
    Classify every column as binary, categorical, numeric or other.

    Rules (in priority order): columns listed in ``binary_cols`` or
    ``categorical_cols`` are honoured; boolean columns and numeric columns
    holding only 0/1 are binary; remaining numeric columns are numeric;
    datetime/timedelta columns are "other"; everything else (object, string,
    category dtype) is categorical.

    Parameters
    ----------
    df : pandas.DataFrame
        Input data.
    categorical_cols : sequence of str, optional
        Columns to force to categorical (e.g. integer-coded categories).
    binary_cols : sequence of str, optional
        Columns to force to binary. They must contain only 0/1 or booleans.

    Returns
    -------
    dict of {str: list of str}
        Keys ``"binary"``, ``"categorical"``, ``"numeric"`` and ``"other"``.

    Raises
    ------
    KeyError
        If a user-listed column is not in ``df``.
    ValueError
        If a column appears in both lists, or a ``binary_cols`` column is not
        actually binary.

    Examples
    --------
    >>> types = detect_column_types(df, categorical_cols=["region_code"])
    >>> types["numeric"]
    ['age', 'income']

    Notes
    -----
    Author : Navita Singh
    Date : 2026-10-28
    Version : 1
    Change log :
        v1 (2026-10-28) : Initial version.
    """
    categorical_cols = list(categorical_cols or [])
    binary_cols = list(binary_cols or [])

    missing = [c for c in categorical_cols + binary_cols if c not in df.columns]
    if missing:
        raise KeyError(f"Columns not found in DataFrame: {missing}")
    overlap = set(categorical_cols) & set(binary_cols)
    if overlap:
        raise ValueError(f"Columns listed as both binary and categorical: {sorted(overlap)}")

    types: Dict[str, List[str]] = {"binary": [], "categorical": [], "numeric": [], "other": []}
    for col in df.columns:
        s = df[col]
        if col in binary_cols:
            if not _is_binary_series(s):
                raise ValueError(f"Column '{col}' was declared binary but is not 0/1.")
            types["binary"].append(col)
        elif col in categorical_cols:
            types["categorical"].append(col)
        elif _is_binary_series(s):
            types["binary"].append(col)
        elif is_numeric_dtype(s):
            types["numeric"].append(col)
        elif is_datetime64_any_dtype(s) or is_timedelta64_dtype(s):
            types["other"].append(col)
        else:
            types["categorical"].append(col)
    return types


def build_eda_report(
    df: pd.DataFrame, column_types: Optional[Dict[str, List[str]]] = None
) -> pd.DataFrame:
    """
    Build a simple EDA report: column name, data type and null count.

    Parameters
    ----------
    df : pandas.DataFrame
        Original (un-processed) data.
    column_types : dict, optional
        Output of :func:`detect_column_types`. When given, a
        ``detected_type`` column is added to the report.

    Returns
    -------
    pandas.DataFrame
        One row per original column with columns ``column_name``,
        ``data_type``, ``null_count`` and optionally ``detected_type``.

    Raises
    ------
    TypeError
        If ``df`` is not a pandas DataFrame.

    Examples
    --------
    >>> report = build_eda_report(df, detect_column_types(df))

    Notes
    -----
    Author : Navita Singh
    Date : 2026-10-28
    Version : 1
    Change log :
        v1 (2026-10-28) : Initial version.
    """
    if not isinstance(df, pd.DataFrame):
        raise TypeError("`df` must be a pandas DataFrame.")

    report = pd.DataFrame(
        {
            "column_name": df.columns,
            "data_type": [str(t) for t in df.dtypes],
            "null_count": df.isna().sum().values,
        }
    )
    if column_types is not None:
        lookup = {c: k for k, cols in column_types.items() for c in cols}
        report["detected_type"] = report["column_name"].map(lookup)
    return report


def preprocess_df(
    df: pd.DataFrame,
    categorical_cols: Optional[Sequence[str]] = None,
    binary_cols: Optional[Sequence[str]] = None,
    eda_report_path: Optional[str] = "eda_report.csv",
    null_strategy: str = "none",
    drop_first: bool = False,
) -> pd.DataFrame:
    """
    Prepare a raw DataFrame for the causal discovery algorithms.

    Steps performed:

    1. Detect binary, categorical and numeric columns.
    2. Print an EDA report (original column names, data types, null counts)
       and save it as a CSV file.
    3. Optionally handle nulls (``null_strategy``).
    4. Standardise numeric columns (zero mean, unit variance), excluding
       binary and categorical columns.
    5. Leave binary columns unchanged (booleans are cast to 0/1).
    6. One-hot encode categorical columns; the resulting 0/1 columns are
       not standardised.

    Parameters
    ----------
    df : pandas.DataFrame
        Raw input data. It is not modified in place.
    categorical_cols : sequence of str, optional
        Columns to treat as categorical even if numeric (integer codes).
    binary_cols : sequence of str, optional
        Columns to force as binary (must contain only 0/1).
    eda_report_path : str or None, default "eda_report.csv"
        Where to save the EDA report. If None, the report is only printed.
    null_strategy : {"none", "drop", "impute"}, default "none"
        ``"none"`` keeps nulls (the model functions will reject them),
        ``"drop"`` removes rows containing any null, ``"impute"`` fills
        numeric columns with the median and binary/categorical columns with
        the mode. Nulls are counted in the EDA report before any handling.
    drop_first : bool, default False
        Drop the first dummy level of each categorical column to avoid
        perfect collinearity.

    Returns
    -------
    pandas.DataFrame
        Processed data: standardised numeric features and binary (0/1)
        features, ready to pass to the functions in
        ``Acyclic_causal_graph.py`` and ``cyclic.py``.

    Raises
    ------
    TypeError
        If ``df`` is not a pandas DataFrame.
    ValueError
        If ``df`` is empty or ``null_strategy`` is invalid.
    KeyError
        If a user-listed column is missing from ``df``.

    Examples
    --------
    >>> raw = read_file("data/raw_data.csv")
    >>> clean = preprocess_df(raw, categorical_cols=["region_code"],
    ...                       eda_report_path="output/eda_report.csv",
    ...                       null_strategy="impute")

    Notes
    -----
    Zero-variance numeric columns cannot be standardised; they are set to 0
    and a warning is issued. For time-series methods keep the rows in time
    order (``null_strategy="drop"`` preserves order).

    Author : Navita Singh
    Date : 2026-10-28
    Version : 1
    Change log :
        v1 (2026-10-28) : Initial version.
    """
    if not isinstance(df, pd.DataFrame):
        raise TypeError("`df` must be a pandas DataFrame.")
    if df.empty:
        raise ValueError("`df` is empty.")
    if null_strategy not in _NULL_STRATEGIES:
        raise ValueError(f"`null_strategy` must be one of {_NULL_STRATEGIES}.")

    types = detect_column_types(df, categorical_cols, binary_cols)

    # EDA report on the ORIGINAL data
    report = build_eda_report(df, types)
    print("EDA report")
    print(report.to_string(index=False))
    if eda_report_path:
        write_file(report, eda_report_path, index=False)
        print(f"\nEDA report saved to: {eda_report_path}")

    out = df.copy()

    # Null handling
    if null_strategy == "drop":
        out = out.dropna().reset_index(drop=True)
        if out.empty:
            raise ValueError("All rows were dropped by null_strategy='drop'.")
    elif null_strategy == "impute":
        for col in types["numeric"]:
            out[col] = out[col].fillna(out[col].median())
        for col in types["binary"] + types["categorical"]:
            if out[col].isna().any():
                out[col] = out[col].fillna(out[col].mode(dropna=True).iloc[0])

    # Binary: unchanged (only cast booleans to 0/1)
    for col in types["binary"]:
        if is_bool_dtype(out[col]):
            out[col] = out[col].astype(int)

    # Numeric: standardise
    for col in types["numeric"]:
        mean, std = out[col].mean(), out[col].std(ddof=0)
        if not np.isfinite(std) or std == 0:
            warnings.warn(f"Column '{col}' has zero variance; set to 0.")
            out[col] = 0.0
        else:
            out[col] = (out[col] - mean) / std

    # Categorical: one-hot encode (left as 0/1)
    if types["categorical"]:
        out = pd.get_dummies(
            out, columns=types["categorical"], prefix_sep="_",
            drop_first=drop_first, dtype=int,
        )

    if types["other"]:
        warnings.warn(
            f"Columns {types['other']} are datetime/timedelta and were left unchanged; "
            "drop or convert them before running causal discovery."
        )
    return out


# --------------------------------------------------------------------------- #
# Validation
# --------------------------------------------------------------------------- #
def validate_input_df(df: pd.DataFrame, min_rows: int = 3, allow_nan: bool = False) -> np.ndarray:
    """
    Validate a pre-processed DataFrame and return its values as an array.

    Checks that ``df`` is a non-trivial DataFrame with only numeric, finite
    columns, and warns if a non-binary column does not look standardised.

    Parameters
    ----------
    df : pandas.DataFrame
        Output of :func:`preprocess_df` (standardised numeric features and
        0/1 binary features).
    min_rows : int, default 3
        Minimum number of rows required.
    allow_nan : bool, default False
        If False, any null value raises an error.

    Returns
    -------
    numpy.ndarray
        Float array of shape (n_samples, n_features).

    Raises
    ------
    TypeError
        If ``df`` is not a pandas DataFrame.
    ValueError
        If there are too few rows or columns, non-numeric columns, nulls
        (when not allowed) or infinite values.

    Examples
    --------
    >>> X = validate_input_df(clean)
    >>> X.shape
    (500, 8)

    Notes
    -----
    Author : Navita Singh
    Date : 2026-10-28
    Version : 1
    Change log :
        v1 (2026-10-28) : Initial version.
    """
    if not isinstance(df, pd.DataFrame):
        raise TypeError("`df` must be a pandas DataFrame.")
    if df.shape[0] < min_rows:
        raise ValueError(f"`df` needs at least {min_rows} rows; got {df.shape[0]}.")
    if df.shape[1] < 2:
        raise ValueError("`df` needs at least 2 columns.")

    non_numeric = [c for c in df.columns if not is_numeric_dtype(df[c])]
    if non_numeric:
        raise ValueError(
            f"Non-numeric columns found: {non_numeric}. Run preprocess_df first."
        )
    if not allow_nan and df.isna().any().any():
        bad = df.columns[df.isna().any()].tolist()
        raise ValueError(
            f"Null values found in columns {bad}. Use preprocess_df(null_strategy=...)."
        )

    X = df.to_numpy(dtype=float)
    if np.isinf(X).any():
        raise ValueError("`df` contains infinite values.")

    for col in df.columns:
        if _is_binary_series(df[col]):
            continue
        mean, std = df[col].mean(), df[col].std(ddof=0)
        if abs(mean) > 0.1 or abs(std - 1) > 0.1:
            warnings.warn(f"Column '{col}' does not appear standardised (mean={mean:.2f}, std={std:.2f}).")
    return X


# --------------------------------------------------------------------------- #
# Graph helpers
# --------------------------------------------------------------------------- #
def adjacency_to_edges(adjacency: pd.DataFrame, tol: float = 0.0) -> pd.DataFrame:
    """
    Convert an adjacency matrix into an edge list.

    Convention: ``adjacency.loc[i, j] != 0`` means a directed edge ``i -> j``.

    Parameters
    ----------
    adjacency : pandas.DataFrame
        Square matrix with identical row and column labels.
    tol : float, default 0.0
        Entries with absolute value ``<= tol`` are treated as no edge.

    Returns
    -------
    pandas.DataFrame
        Columns ``source``, ``target``, ``weight``, sorted by absolute weight
        (descending).

    Raises
    ------
    ValueError
        If ``adjacency`` is not square.

    Examples
    --------
    >>> edges = adjacency_to_edges(result["adjacency"], tol=0.05)

    Notes
    -----
    Author : Navita Singh
    Date : 2026-10-28
    Version : 1
    Change log :
        v1 (2026-10-28) : Initial version.
    """
    if adjacency.shape[0] != adjacency.shape[1]:
        raise ValueError("`adjacency` must be square.")
    rows = []
    for i, src in enumerate(adjacency.index):
        for j, tgt in enumerate(adjacency.columns):
            w = adjacency.iloc[i, j]
            if abs(w) > tol:
                rows.append((src, tgt, float(w)))
    edges = pd.DataFrame(rows, columns=["source", "target", "weight"])
    if not edges.empty:
        edges = edges.reindex(edges["weight"].abs().sort_values(ascending=False).index)
        edges = edges.reset_index(drop=True)
    return edges


def is_dag(adjacency: pd.DataFrame, tol: float = 0.0) -> bool:
    """
    Check whether a directed graph has no cycles (Kahn's algorithm).

    Parameters
    ----------
    adjacency : pandas.DataFrame
        Square matrix; ``adjacency.iloc[i, j] != 0`` means ``i -> j``.
    tol : float, default 0.0
        Entries with absolute value ``<= tol`` are ignored.

    Returns
    -------
    bool
        True if the graph is acyclic.

    Raises
    ------
    ValueError
        If ``adjacency`` is not square.

    Examples
    --------
    >>> is_dag(result["adjacency"])
    True

    Notes
    -----
    Author : Navita Singh
    Date : 2026-10-28
    Version : 1
    Change log :
        v1 (2026-10-28) : Initial version.
    """
    A = (np.abs(adjacency.to_numpy(dtype=float)) > tol).astype(int)
    if A.shape[0] != A.shape[1]:
        raise ValueError("`adjacency` must be square.")
    indeg = A.sum(axis=0)
    queue = [i for i in range(A.shape[0]) if indeg[i] == 0]
    visited = 0
    while queue:
        node = queue.pop()
        visited += 1
        for child in np.nonzero(A[node])[0]:
            indeg[child] -= 1
            if indeg[child] == 0:
                queue.append(child)
    return visited == A.shape[0]


def lagged_edges_to_summary_adjacency(edges: pd.DataFrame, columns: Sequence[str]) -> pd.DataFrame:
    """
    Collapse a lagged edge list into a single summary adjacency matrix.

    For each ordered pair (source, target), the entry holds the signed
    strength of the strongest link across all lags. The summary graph may
    contain cycles, which is expected for time-series methods.

    Parameters
    ----------
    edges : pandas.DataFrame
        Must contain columns ``source``, ``target`` and ``strength``.
    columns : sequence of str
        Variable names defining the matrix order.

    Returns
    -------
    pandas.DataFrame
        Square matrix; entry ``[i, j]`` is the strength of ``i -> j``.

    Raises
    ------
    KeyError
        If required columns are missing from ``edges``.

    Examples
    --------
    >>> summary = lagged_edges_to_summary_adjacency(result["edges"], df.columns)

    Notes
    -----
    Author : Navita Singh
    Date : 2026-10-28
    Version : 1
    Change log :
        v1 (2026-10-28) : Initial version.
    """
    summary = pd.DataFrame(0.0, index=list(columns), columns=list(columns))
    if edges.empty:
        return summary
    for col in ("source", "target", "strength"):
        if col not in edges.columns:
            raise KeyError(f"`edges` is missing column '{col}'.")
    for _, row in edges.iterrows():
        current = summary.loc[row["source"], row["target"]]
        if abs(row["strength"]) > abs(current):
            summary.loc[row["source"], row["target"]] = row["strength"]
    return summary
