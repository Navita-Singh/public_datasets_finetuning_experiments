import numpy as np
import pandas as pd
import os
from typing import Dict, List, Optional, Tuple
from utils import DATA_DIR, REAL_OP_DIR, OUTPUT_DIR, GROUND_TRUTH_DIR, PREDICTION_DIR, FULL_GRAPH_DIR, COOLANT_DIR, HYDRAULICS_DIR, PROBE_DIR
from eval_metrics import compare_adj_matrix_metrics

#--------------------------
#BUILD GROUND TRUTH GRAPH
#--------------------------

def edges_to_adjacency(graph_dir: str, prefix: str) -> pd.DataFrame:
    """
    Build the adjacency matrix of one graph.
 
    Parameters
    ----------
    graph_dir : str
        Folder holding ``<prefix>_edges.csv`` and ``<prefix>_nodes.csv``.
    prefix : str
        File prefix, e.g. ``"coolant"`` or ``"all"``.
 
    Returns
    -------
    pandas.DataFrame
        0/1 matrix, rows and columns in the order of the nodes file's ``id``
        column and labelled with ``label``; ``[i, j] = 1`` means ``i -> j``.
    """
    nodes = pd.read_csv(os.path.join(graph_dir, f"{prefix}_nodes.csv"))
    edges = pd.read_csv(os.path.join(graph_dir, f"{prefix}_edges.csv"))
 
    if nodes["id"].duplicated().any():
        raise ValueError(f"Duplicate ids in {prefix}_nodes.csv")
 
    ids = nodes["id"].tolist()                      # keep the file's order
    labels = nodes["label"].astype(str).tolist()
    pos = {node_id: k for k, node_id in enumerate(ids)}
 
    adj = pd.DataFrame(0, index=labels, columns=labels, dtype=int)
    missing = 0
    for s, t in zip(edges["source_id"], edges["target_id"]):
        if s not in pos or t not in pos:
            missing += 1
            continue
        adj.iat[pos[s], pos[t]] = 1                 # source -> target
 
    if missing:
        warnings.warn(f"{prefix}: {missing} edge(s) reference ids missing from the nodes file.")
    return adj
 
 
def build_ground_truth(output_dir: str = OUTPUT_DIR) -> dict:
    """
    Write ground-truth adjacency matrices to ``output_dir``.
 
    1. Digital-twin subsystems (coolant, hydraulics, probe), one file each:
       ``<name>_ground_truth_adjacency.csv``.
    2. Full expert graph: ``all_ground_truth_adjacency.csv``.
 
    Returns
    -------
    dict of {str: pandas.DataFrame}
        Name -> adjacency matrix.
    """
    os.makedirs(output_dir, exist_ok=True)
    graphs = {
        "coolant": COOLANT_DIR,
        "hydraulics": HYDRAULICS_DIR,
        "probe": PROBE_DIR,
        "all": FULL_GRAPH_DIR,
    }
    result = {}
    for prefix, folder in graphs.items():
        adj = edges_to_adjacency(folder, prefix)
        path = os.path.join(output_dir,f"{prefix}_ground_truth_adjacency.csv")
        adj.rename_axis("node").to_csv(path)
        print(f"{prefix}: {adj.shape[0]} nodes, {int(adj.values.sum())} edges -> {path}")
        result[prefix] = adj
    return result
 

#--------------------------
#BUILD PREDICTIONGRAPH
#--------------------------

"""
pred_to_graphs
==============
 
Take an adjacency matrix predicted by an algorithm (``[i, j] != 0`` means
``i -> j``, rows and columns named by variable) and produce one matrix per
ground-truth graph, with rows/columns in the order of the ``id`` column of
that graph's ``*_nodes.csv``, so it can be compared directly with the files
written by ``ground_truth.py``.
 
Outputs (in ``out_dir``):
    all_pred_adjacency.csv, coolant_pred_adjacency.csv,
    hydraulics_pred_adjacency.csv, probe_pred_adjacency.csv
 
Handling of mismatches between predicted columns and ground-truth nodes
    * Exact label match -> used as is.
    * Ground-truth node absent but one-hot dummies ``<label>_<value>`` present
      (e.g. ``Prog_Name_MEAS_X_SPF``) -> the dummies are merged: an edge
      to/from the node exists if ANY of its dummies has that edge.
    * Node with no matching column at all (dropped as constant/duplicate, or
      not in the data) -> row and column of zeros, and listed in the printout.
"""


GRAPHS = {
    "all": FULL_GRAPH_DIR,
    "coolant": COOLANT_DIR,
    "hydraulics": HYDRAULICS_DIR,
    "probe": PROBE_DIR,
}
 
 
def align_prediction(
    pred: pd.DataFrame, labels: List[str], threshold: float = 0.0
) -> Tuple[pd.DataFrame, List[str], Dict[str, List[str]]]:
    """
    Reorder a predicted adjacency to ``labels`` (the ground-truth node order).
 
    Parameters
    ----------
    pred : pandas.DataFrame
        Predicted matrix; may be weighted. Rows and columns share the names.
    labels : list of str
        Ground-truth node labels in the wanted order.
    threshold : float, default 0.0
        An edge exists where ``abs(value) > threshold``.
 
    Returns
    -------
    aligned : pandas.DataFrame
        0/1 matrix indexed by ``labels``.
    missing : list of str
        Labels with no matching predicted column (all-zero row/column).
    merged : dict
        Label -> list of one-hot columns merged into it.
    """
    if list(pred.index) != list(pred.columns):
        if set(pred.index) != set(pred.columns):
            raise ValueError("Rows and columns of the predicted matrix have different names.")
        pred = pred.loc[list(pred.columns), list(pred.columns)]
 
    arr = (pred.abs().to_numpy() > threshold).astype(int)
    pos = {c: k for k, c in enumerate(pred.columns)}
    exact = set(labels)
 
    groups: Dict[str, List[int]] = {}
    merged: Dict[str, List[str]] = {}
    missing: List[str] = []
    for lab in labels:
        if lab in pos:
            groups[lab] = [pos[lab]]
            continue
        dummies = [c for c in pred.columns if c.startswith(lab + "_") and c not in exact]
        if dummies:
            groups[lab] = [pos[c] for c in dummies]
            merged[lab] = dummies
        else:
            groups[lab] = []
            missing.append(lab)
 
    n = len(labels)
    out = np.zeros((n, n), dtype=int)
    for a, la in enumerate(labels):
        ra = groups[la]
        if not ra:
            continue
        for b, lb in enumerate(labels):
            cb = groups[lb]
            if a == b or not cb:
                continue
            out[a, b] = int(arr[np.ix_(ra, cb)].max() > 0)
    return pd.DataFrame(out, index=labels, columns=labels), missing, merged
 
 
def pred_to_ground_truth_graphs(
    pred_path: str,
    out_dir: Optional[str] = None,
    threshold: float = 0.0,
) -> Dict[str, pd.DataFrame]:
    """
    Read a predicted adjacency CSV and write the four aligned matrices.
 
    Parameters
    ----------
    pred_path : str
        CSV with the node names in the first column and as the header, e.g.
        ``OUTPUT_DIR/pc_adjacency.csv`` or the LiNGAM adjacency.
    out_dir : str, optional
        Output folder (default ``OUTPUT_DIR``). Use a separate folder per
        algorithm (e.g. ``OUTPUT_DIR/pc``) so files are not overwritten.
    threshold : float, default 0.0
        Weights with ``abs(value) <= threshold`` are treated as no edge.
 
    Returns
    -------
    dict of {str: pandas.DataFrame}
        Graph name -> aligned 0/1 adjacency.
    """
    out_dir = out_dir or OUTPUT_DIR
    os.makedirs(out_dir, exist_ok=True)
    pred = pd.read_csv(pred_path, index_col=0)
 
    result = {}
    for prefix, folder in GRAPHS.items():
        nodes = pd.read_csv(os.path.join(folder, f"{prefix}_nodes.csv"))
        labels = nodes["label"].astype(str).tolist()          # order of the id column
        aligned, missing, merged = align_prediction(pred, labels, threshold)
 
        path = os.path.join(out_dir, f"{prefix}_pred_adjacency.csv")
        aligned.rename_axis("node").to_csv(path)
        result[prefix] = aligned
        print(f"{prefix}: {len(labels)} nodes, {int(aligned.values.sum())} predicted edges -> {path}")
        if merged:
            print(f"  merged one-hot columns: { {k: len(v) for k, v in merged.items()} }")
        if missing:
            print(f"  not in prediction ({len(missing)}): {missing}")
    return result


#--------------------------
#Compare metrics
#--------------------------

def get_eval_metrics(ground_truth_dict, pred_truth_dict):

    """
    Compare the predicted adjacency matrices with the ground truth adjacency matrices and return a dictionary of metrics for each graph.

    Returns:
    dict: A dictionary containing the comparison metrics for each graph.
    """

    eval_metrics_dict = {}
    for graph_name in ground_truth_dict.keys():
        adj_true = ground_truth_dict[graph_name].to_numpy()
        adj_pred = pred_truth_dict[graph_name].to_numpy()
        metrics = compare_adj_matrix_metrics(adj_true, adj_pred)
        eval_metrics_dict[graph_name] = metrics

    return eval_metrics_dict