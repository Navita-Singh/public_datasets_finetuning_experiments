def compare_adj_matrix_metrics(adj_true, adj_pred):
    """
    Compare adjacency matrices for true and predicted causal graphs and return a dictionary of metrics. The metrics include precision, recall, F1 score, and structural hamming distance.
    The value of the edge X->Y in the adjacency matrix is 1 only if there is a directed edge from X to Y (X causes Y), and 0 otherw

    Parameters:
    adj_true(numpy.ndarray): The adjacency matrix of the true causal graph.
    adj_pred (numpy.ndarray): The adjacency matrix of the predicted causal graph.

    Returns:
    dict: A dictionary containing the comparison metrics.
    """
    import numpy as np

    # Ensure the matrices are of the same shape
    if adj_true.shape != adj_pred.shape:
        raise ValueError("Adjacency matrices must have the same shape.")

    # Calculate metrics
    
    metrics = {}
    rows, cols = adj_true.shape

    # Calculate True Positives, False Positives, True Negatives, False Negatives
    TP = np.sum((adj_true == 1) & (adj_pred == 1))
    FP = np.sum((adj_true == 0) & (adj_pred == 1))
    TN = np.sum((adj_true == 0) & (adj_pred == 0))
    FN = np.sum((adj_true == 1) & (adj_pred == 0))

    # Calculate Precision, Recall, F1 Score
    precision = TP / (TP + FP) if (TP + FP) > 0 else 0
    recall = TP / (TP + FN) if (TP + FN) > 0  else 0
    f1_score = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0

    # Store metrics in the dictionary
    metrics["precision"] = precision
    metrics["recall"] = recall
    metrics["f1_score"] = f1_score
    metrics["structural_hamming_distance"] = np.sum(FP)+ np.sum(FN)  # Number of differing edges
    print(metrics)

    return metrics

if __name__ == "__main__":
    import numpy as np

    # Example usage
    adj_true = np.array([[0, 1, 0],
                         [0, 0, 1],
                         [0, 0, 0]])

    adj_pred = np.array([[0, 1, 0],
                         [1, 0, 1],
                         [0, 0, 0]])

    metrics = compare_adj_matrix_metrics(adj_true, adj_pred)
    print(metrics)