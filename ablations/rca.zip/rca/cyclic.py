"""
cyclic
======

Causal discovery for time-series data, where feedback loops (cycles) can
appear in the summary graph: PCMCI and VAR-LiNGAM.

Every function takes a DataFrame produced by ``Utils.preprocess_df``
(standardised numeric features and 0/1 binary features) whose rows are in
chronological order, and returns a dict with at least:

* ``method``            : name of the algorithm
* ``edges``             : DataFrame (source, target, lag, strength[, p_value]);
                          ``source`` at time ``t - lag`` causes ``target`` at ``t``
* ``summary_adjacency`` : DataFrame collapsing all lags (``[i, j]`` = i -> j);
                          may contain cycles

Dependencies: numpy, pandas, tigramite (PCMCI), lingam (VAR-LiNGAM).

Notes
-----
Author : Navita Singh
Date : 2026-10-28
Version : 1
Change log :
    v1 (2026-10-28) : Initial version.
"""

from typing import Any, Dict, Optional

import numpy as np
import pandas as pd

from utils import lagged_edges_to_summary_adjacency, validate_input_df


def run_pcmci(
    df: pd.DataFrame,
    tau_max: int = 3,
    tau_min: int = 1,
    pc_alpha: Optional[float] = 0.05,
    alpha_level: float = 0.05,
    fdr_method: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Run PCMCI for lagged causal discovery in time series.

    PCMCI first selects candidate parents of each variable with a PC-style
    condition-selection step, then applies the Momentary Conditional
    Independence (MCI) test to each lagged link. Partial correlation
    (``ParCorr``) is used as the independence test.

    Parameters
    ----------
    df : pandas.DataFrame
        Standardised numeric features and 0/1 binary features, rows in time
        order.
    tau_max : int, default 3
        Maximum lag considered.
    tau_min : int, default 1
        Minimum lag considered. Keep at 1 for lagged links only (PCMCI does
        not orient contemporaneous links; use PCMCI+ for that).
    pc_alpha : float or None, default 0.05
        Significance level of the condition-selection step. ``None`` lets
        tigramite choose it by AIC.
    alpha_level : float, default 0.05
        A link is kept when its (corrected) p-value is below this level.
    fdr_method : str or None, default None
        Multiple testing correction (e.g. ``"fdr_bh"``). ``None`` uses the
        raw p-values.

    Returns
    -------
    dict
        ``method``, ``edges`` (source, target, lag, strength, p_value),
        ``summary_adjacency``, ``val_matrix`` and ``p_matrix`` (arrays of
        shape ``(N, N, tau_max + 1)``; entry ``[i, j, tau]`` is the link
        ``i(t - tau) -> j(t)``) and ``var_names``.

    Raises
    ------
    ImportError
        If ``tigramite`` is not installed.
    TypeError, ValueError
        If ``df`` fails validation or lags are invalid.

    Examples
    --------
    >>> from Utils import preprocess_df
    >>> from cyclic import run_pcmci
    >>> res = run_pcmci(preprocess_df(ts_df), tau_max=5, fdr_method="fdr_bh")
    >>> res["edges"]

    Notes
    -----
    Partial correlation assumes linear relations; binary variables are
    treated as continuous, so interpret their links with care.

    Author : Navita Singh
    Date : 2026-10-28
    Version : 1
    Change log :
        v1 (2026-10-28) : Initial version.
    """
    try:
        from tigramite import data_processing as pp
        from tigramite.independence_tests.parcorr import ParCorr
        from tigramite.pcmci import PCMCI
    except ImportError as exc:
        raise ImportError("Install tigramite: pip install tigramite") from exc

    if tau_min < 0 or tau_max < max(tau_min, 1):
        raise ValueError("Require 0 <= tau_min and tau_max >= max(tau_min, 1).")
    X = validate_input_df(df, min_rows=tau_max + 10)
    names = list(df.columns)

    dataframe = pp.DataFrame(X, var_names=names)
    pcmci = PCMCI(dataframe=dataframe, cond_ind_test=ParCorr(), verbosity=0)
    results = pcmci.run_pcmci(tau_min=tau_min, tau_max=tau_max, pc_alpha=pc_alpha)

    val_matrix = results["val_matrix"]
    p_matrix = results["p_matrix"]
    if fdr_method:
        p_matrix = pcmci.get_corrected_pvalues(
            p_matrix=p_matrix, tau_min=tau_min, tau_max=tau_max, fdr_method=fdr_method
        )

    rows = []
    n_vars = len(names)
    for i in range(n_vars):
        for j in range(n_vars):
            for tau in range(tau_min, tau_max + 1):
                if tau == 0 and i == j:
                    continue
                if p_matrix[i, j, tau] < alpha_level:
                    rows.append((names[i], names[j], tau,
                                 float(val_matrix[i, j, tau]), float(p_matrix[i, j, tau])))
    edges = pd.DataFrame(rows, columns=["source", "target", "lag", "strength", "p_value"])
    edges = edges.sort_values("p_value").reset_index(drop=True)

    return {
        "method": "PCMCI",
        "edges": edges,
        "summary_adjacency": lagged_edges_to_summary_adjacency(edges, names),
        "val_matrix": val_matrix,
        "p_matrix": p_matrix,
        "var_names": names,
    }


def run_var_lingam(
    df: pd.DataFrame,
    lags: int = 1,
    criterion: Optional[str] = "bic",
    prune: bool = True,
    min_weight: float = 0.0,
    random_state: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Run VAR-LiNGAM for time-series causal discovery.

    VAR-LiNGAM fits a vector autoregression to estimate lagged effects, then
    applies LiNGAM to the residuals to identify the instantaneous (lag 0)
    structure, assuming non-Gaussian independent noise.

    Parameters
    ----------
    df : pandas.DataFrame
        Standardised numeric features and 0/1 binary features, rows in time
        order.
    lags : int, default 1
        Order of the VAR model (maximum lag). With a ``criterion`` set, it
        is the maximum order searched.
    criterion : {"aic", "bic", "hqic", "fpe", None}, default "bic"
        Information criterion for lag selection. ``None`` uses ``lags``
        exactly.
    prune : bool, default True
        Apply adaptive-lasso pruning to the estimated coefficients.
    min_weight : float, default 0.0
        Absolute coefficients ``<= min_weight`` are dropped from the output.
    random_state : int, optional
        Seed for reproducibility.

    Returns
    -------
    dict
        ``method``, ``edges`` (source, target, lag, strength; lag 0 are
        instantaneous effects), ``summary_adjacency``, ``matrices`` (dict
        mapping lag to a DataFrame with ``[i, j]`` = effect i -> j),
        ``causal_order`` (instantaneous order, causes first) and
        ``residuals`` (DataFrame).

    Raises
    ------
    ImportError
        If ``lingam`` is not installed.
    TypeError, ValueError
        If ``df`` fails validation or ``lags`` is invalid.

    Examples
    --------
    >>> from Utils import preprocess_df
    >>> from cyclic import run_var_lingam
    >>> res = run_var_lingam(preprocess_df(ts_df), lags=2, random_state=0)
    >>> res["matrices"][1]

    Notes
    -----
    The lingam package stores matrices with ``M[i, j]`` = effect of
    ``x_j(t - k)`` on ``x_i(t)``; they are transposed here so all outputs
    share the ``source -> target`` convention.

    Author : Navita Singh
    Date : 2026-10-28
    Version : 1
    Change log :
        v1 (2026-10-28) : Initial version.
    """
    try:
        import lingam
    except ImportError as exc:
        raise ImportError("Install lingam: pip install lingam") from exc

    if lags < 1:
        raise ValueError("`lags` must be >= 1.")
    X = validate_input_df(df, min_rows=lags + 10)
    names = list(df.columns)

    model = lingam.VARLiNGAM(
        lags=lags, criterion=criterion, prune=prune, random_state=random_state
    )
    model.fit(X)

    matrices, rows = {}, []
    for lag, M in enumerate(model.adjacency_matrices_):
        M = np.array(M, dtype=float)
        M[np.abs(M) <= min_weight] = 0
        matrices[lag] = pd.DataFrame(M.T, index=names, columns=names)
        for tgt in range(M.shape[0]):
            for src in range(M.shape[1]):
                if M[tgt, src] != 0:
                    rows.append((names[src], names[tgt], lag, float(M[tgt, src])))
    edges = pd.DataFrame(rows, columns=["source", "target", "lag", "strength"])
    edges = edges.reindex(edges["strength"].abs().sort_values(ascending=False).index)
    edges = edges.reset_index(drop=True)

    return {
        "method": "VAR-LiNGAM",
        "edges": edges,
        "summary_adjacency": lagged_edges_to_summary_adjacency(edges, names),
        "matrices": matrices,
        "causal_order": [names[i] for i in model.causal_order_],
        "residuals": pd.DataFrame(model.residuals_, columns=names),
    }
