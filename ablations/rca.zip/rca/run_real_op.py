"""
run_real_op
===========

Driver for the event-log files in ``dataset_causRCA/real_op``.

Each file is a long event log with rows ``time, signal, value, type`` where a
signal is written only when its value changes. Every file is converted into a
wide table (one column per signal, one row per time point, values
forward-filled), then:

CROSS-SECTIONAL route (rows treated as independent snapshots)
    * PC       : all files concatenated -> ``run_pc``.
    * LiNGAM   : ``run_lingam`` per file, edge kept if present in more than
                 ``MAJORITY`` of the per-file graphs.

TIME-SERIES route (fixed time grid, rows kept in time order, one series per file)
    * PCMCI and VAR-LiNGAM per file, majority vote over the summary graphs.

Categorical signals are one-hot encoded ONCE on the concatenation of all files
(via ``utils.preprocess_df``) so that every file shares identical columns, and
the result is split back by file.

Place next to utils.py, acyclic_causal_graph.py and cyclic.py.
"""

import glob
import os
import warnings
from typing import Callable, Dict, List

import numpy as np
import pandas as pd

from utils import preprocess_df, write_file
from utils import DATA_DIR, REAL_OP_DIR, OUTPUT_DIR, GROUND_TRUTH_DIR, PREDICTION_DIR, FULL_GRAPH_DIR, COOLANT_DIR, HYDRAULICS_DIR, PROBE_DIR
from acyclic_causal_graph import run_lingam
from cyclic import run_pcmci

from ground_truth_prediction import build_ground_truth, pred_to_ground_truth_graphs, get_eval_metrics

# --------------------------------------------------------------------------- #
# Configuration
# --------------------------------------------------------------------------- #


MODE = "cross_sectional"            # "cross_sectional", "time_series" or "both"
CS_STEP = None           # None = one row per event time; or e.g. 0.05 for a fixed grid
TS_STEP = 0.05           # grid step (seconds) for the time-series route
MAJORITY = 0.5           # keep an edge if present in MORE than this fraction of graphs
PC_ALPHA = 0.05
TAU_MAX = 3              # PCMCI max lag
VAR_LAGS = 2             # VAR-LiNGAM max lag
DROP_SIGNALS = ["Prog_Name_LineNo"]   # signals removed entirely (add "Prog_Name" here to drop it)
NUMERIC_AS_CATEGORICAL = ["Prog_LineNo"]  # categorical signals with an order: used as ONE numeric column
TOP_K = 10               # other categoricals: keep the K most frequent levels, group the rest as "other"
                         # (set to None to keep all levels)
REDUNDANCY_THRESHOLD = 0.999          # drop columns with |corr| >= this to an earlier column
LINGAM_COEFF_THRESHOLD = 0.05         # keep an edge if the estimated coefficient is >= this (absolute value)


# --------------------------------------------------------------------------- #
# Reading and reshaping the event logs
# --------------------------------------------------------------------------- #
def load_event_logs(folder: str) -> list:
    """Read every ``.csv``/``.txt`` log in ``folder`` as ``time, signal, value, dtype``."""
    paths = sorted(
        p for p in glob.glob(os.path.join(folder, "*"))
        if os.path.isfile(p) and p.lower().endswith((".csv", ".txt"))
    )[0:30]
    if not paths:
        raise FileNotFoundError(f"No .csv/.txt files found in: {folder}")

    logs = []
    for p in paths:
        try:
            ev = pd.read_csv(p, header=None, usecols=[0, 1, 2, 3],
                             names=["time", "signal", "value", "dtype"],
                             dtype=str, skipinitialspace=True)
            ev["time"] = pd.to_numeric(ev["time"], errors="coerce")
            ev = ev.dropna(subset=["time", "signal"])     # also drops a header row
            ev = ev[~ev["signal"].isin(DROP_SIGNALS)]
            logs_val = {}
            logs_val[os.path.basename(p)] = ev.reset_index(drop=True)
            logs.append(logs_val)
            print(f"Read {os.path.basename(p)}: {len(ev)} events, {ev['signal'].nunique()} signals")
        except Exception as exc:
            warnings.warn(f"Skipping {p}: {exc}")
    if not logs:
        raise ValueError("No file could be read.")
    print(logs)
    return logs


def restrict_to_common_signals(logs: list) -> Dict[str, pd.DataFrame]:
    """Keep only signals that occur in every file."""

    sets = [set(logs[i][list(logs[i].keys())[0]]["signal"]) for i in range(len(logs))]
    common = set.intersection(*sets)
    lost = set.union(*sets) - common
    if lost:
        warnings.warn(f"Signals not present in every file were dropped: {sorted(lost)}")
    if len(common) < 2:
        raise ValueError("Fewer than 2 signals are shared by all files.")

    n = len(logs)
    for i in range(n):
        logs_val = logs[i]
        key = list(logs_val.keys())[0]
        value = logs_val[key]
        logs_val[key] = value[value["signal"].isin(common)].reset_index(drop=True)

    return logs


def signal_types(logs: list) -> Dict[str, str]:
    """Map signal -> declared type (first occurrence over all files)."""
    all_pd_frames = [logs[i][list(logs[i].keys())[0]] for i in range(len(logs))]
    all_ev = pd.concat(all_pd_frames, ignore_index=True)
    types = all_ev.drop_duplicates("signal").set_index("signal")["dtype"].to_dict()
    for s in NUMERIC_AS_CATEGORICAL:       # ordered codes -> numeric instead of one-hot
        if s in types:
            types[s] = "Continuous"
    return types


def events_to_wide(ev: pd.DataFrame, filename: str, types: Dict[str, str], step: float = None) -> pd.DataFrame:
    """
    Convert one long event log into a wide DataFrame.

    Pivot to time x signal, forward-fill (a value holds until the next change),
    optionally sample on a fixed grid, convert types, and turn monotone
    counters into rates (diff / dt). Rows before every signal has been seen
    are dropped.
    """
    ev = ev.copy()
    
    ev["time"] = ev["time"].round(6)
    wide = (ev.drop_duplicates(["time", "signal"], keep="last")
              .pivot(index="time", columns="signal", values="value")
              .sort_index())

    if step:
        grid = np.round(np.arange(wide.index.min(), wide.index.max() + 1e-9, step), 6)
        wide = wide.reindex(wide.index.union(grid)).ffill().loc[grid]
    else:
        wide = wide.ffill()

    for s in wide.columns:
        kind = types.get(s, "")
        if kind in ("Binary", "Alarm"):
            wide[s] = wide[s].astype(str).str.strip().str.lower().map({"true": 1.0, "false": 0.0})
        elif kind in ("Continuous", "Counter"):
            wide[s] = pd.to_numeric(wide[s], errors="coerce")
        else:  # Categorical or unknown -> keep as text
            wide[s] = wide[s].astype("object")

    '''
    dt = wide.index.to_series().diff()
    for s in wide.columns:
        if types.get(s, "") == "Counter":
            wide[s] = wide[s].diff() / dt

    prev_columns = wide.columns.copy()
    wide = wide.iloc[1:].dropna().reset_index()
    wide.columns = ["time"] + list(prev_columns)
    '''
    if wide.empty:
        raise ValueError("No complete rows after forward-filling.")
    for s in wide.columns:
        if types.get(s, "") in ("Binary", "Alarm"):
            wide[s] = wide[s].astype(int)

    #wide.to_csv(os.path.join(OUTPUT_DIR, f"{filename}_wide.csv"), index=True)
    return wide


# --------------------------------------------------------------------------- #
# Preprocessing (one-hot ONCE over all files, then split back by file)
# --------------------------------------------------------------------------- #
def drop_redundant(df: pd.DataFrame, thr: float) -> pd.DataFrame:
    """Greedily drop columns whose |corr| with an earlier kept column is >= thr."""
    corr = df.corr().abs().fillna(0).to_numpy()
    keep = []
    for j in range(df.shape[1]):
        if all(corr[i, j] < thr for i in keep):
            keep.append(j)
    dropped = [c for k, c in enumerate(df.columns) if k not in keep]
    if dropped:
        print(f"Dropped redundant/duplicate columns: {dropped}")
    return df.iloc[:, keep]


def write_eda_report(text:str, mode:str = "a") -> None:
    """Write a simple EDA report to a CSV file."""
    with open(os.path.join(OUTPUT_DIR, "eda_report.txt"), mode) as f:
        f.write(text)
        f.close()

def prepare(wide: Dict[str, pd.DataFrame], types: Dict[str, str], tag: str) -> Dict[str, pd.DataFrame]:
    """
    Concatenate all files, drop constant columns, run ``preprocess_df``
    (standardise numeric, one-hot categorical), drop duplicate columns and
    split the result back into one DataFrame per file (row order preserved).
    """
    names = list(wide)
    file_id = np.concatenate([[n] * len(wide[n]) for n in names])
    big = pd.concat([wide[n] for n in names], ignore_index=True)
    big = big.loc[:, big.nunique() > 1]

    cat = [c for c in big.columns if types.get(c, "") not in ("Binary", "Alarm", "Continuous", "Counter")]
    binary = [c for c in big.columns if types.get(c, "") in ("Binary", "Alarm")]

    '''Columns with categorical type are one-hot encoded ONCE over the concatenation of all files, so that every file shares identical columns.'''
    write_eda_report("-----------------------------------------------------------------","w")
    write_eda_report("categorical columns:"+','.join(cat), "w")
    write_eda_report("\n")
    write_eda_report("binary columns:"+','.join(binary))
    write_eda_report("\n")
    write_eda_report("numerical columns:"+','.join([c for c in big.columns if c not in cat + binary]))
    write_eda_report("\n\n")


    #TOP_K limits how many categories of a text-valued signal become their own 0/1 column.
    if TOP_K:
        for c in cat:
            n_before = big[c].nunique()
            write_eda_report("Counts for categorical column " + c + ":\n" + str(big[c].value_counts()) + ":\n")
            top = big[c].value_counts().nlargest(TOP_K).index
            big[c] = big[c].where(big[c].isin(top), "other")
            print(f"[{tag}] {c}: {n_before} levels -> {big[c].nunique()}")
    clean = preprocess_df(
        big, categorical_cols=cat, binary_cols=binary,
        eda_report_path=os.path.join(OUTPUT_DIR, f"eda_report_{tag}.csv"),
        null_strategy="none", drop_first=True,
    )
    clean = drop_redundant(clean, REDUNDANCY_THRESHOLD)
    print(f"[{tag}] processed shape: {clean.shape}")
    return {n: clean[file_id == n].reset_index(drop=True) for n in names}


# --------------------------------------------------------------------------- #
# Per-file runs and majority vote
# --------------------------------------------------------------------------- #
def majority_vote(
    parts: Dict[str, pd.DataFrame],
    runner: Callable[[pd.DataFrame], pd.DataFrame],
    columns: List[str],
    majority: float,
):
    """
    Run ``runner`` (DataFrame -> adjacency DataFrame) on each file and keep edges
    present in more than ``majority`` of the graphs.

    Columns that are constant inside a file are dropped for that run and count
    as 'no edge' for that file. Returns (vote 0/1 adjacency, edge frequency, used files).
    """
    mats, used = [], []
    for name, df in parts.items():
        d = df.loc[:, df.std() > 0]
        if d.shape[1] < 2:
            warnings.warn(f"{name}: fewer than 2 non-constant columns, skipped.")
            continue
        try:
            adj = runner(d).reindex(index=columns, columns=columns).fillna(0)
            mats.append((adj.to_numpy() != 0).astype(float))
            used.append(name)
        except Exception as exc:
            warnings.warn(f"{name}: run failed ({exc}), skipped.")
    if not mats:
        raise RuntimeError("The algorithm failed on every file.")
    freq = np.mean(mats, axis=0)
    vote = (freq > majority).astype(int)
    np.fill_diagonal(vote, 0)
    return (pd.DataFrame(vote, index=columns, columns=columns),
            pd.DataFrame(freq, index=columns, columns=columns), used)


def save_matrix(df: pd.DataFrame, name: str) -> None:
    write_file(df.reset_index(names="node"), os.path.join(PREDICTION_DIR, name))


# --------------------------------------------------------------------------- #
# Routes
# --------------------------------------------------------------------------- #
def time_series(logs, types) -> None:
    wide = {i: events_to_wide(logs[i][list(logs[i].keys())[0]], list(logs[i].keys())[0],types, CS_STEP) for i in range(len(logs))}
    parts = prepare(wide, types, "time_series")
    columns = list(next(iter(parts.values())).columns)

    # PC on all files concatenated
    big = pd.concat(parts.values(), ignore_index=True)
    big = big.loc[:, big.std() > 0]
    #LiNGAM isn’t only finding whether an edge exists. It fits a linear model for each variable, and each entry is the estimated coefficient of that cause.
    pc = run_lingam(big)
    print("\nPC directed edges:\n", pc["edges"])
    #print("PC undirected edges:", pc["undirected_edges"])
    save_matrix(pc["adjacency"], "lingam_adjacency.csv")
    adj_binary = (abs(pc["adjacency"]) >=LINGAM_COEFF_THRESHOLD).astype(int) 
    save_matrix(adj_binary, "lingam_binary_adjacency.csv")
    #write_file(pd.DataFrame(pc["undirected_edges"], columns=["node_a", "node_b"]),
    #           os.path.join(OUTPUT_DIR, "lingam_undirected_edges.csv"))
    return adj_binary, os.path.join(PREDICTION_DIR, "lingam_binary_adjacency.csv")



def cross_sectional(logs, types) -> None:
    wide = {i: events_to_wide(logs[i][list(logs[i].keys())[0]], list(logs[i].keys())[0],types, CS_STEP) for i in range(len(logs))}
    parts = prepare(wide, types, "cross_sectional")
    columns = list(next(iter(parts.values())).columns)

    vote, freq, used = majority_vote(
        parts, lambda d: run_pcmci(d, tau_max=TAU_MAX, fdr_method="fdr_bh")["summary_adjacency"],
        columns, MAJORITY)
    print(f"\nPCMCI majority summary graph over {len(used)} files: {int(vote.values.sum())} edges")
    save_matrix(vote, "pcmci_majority_adjacency.csv")
    save_matrix(freq, "pcmci_edge_frequency.csv")

    return vote, os.path.join(PREDICTION_DIR, "pcmci_majority_adjacency.csv")




def main() -> None:

    for dir_name in [OUTPUT_DIR, GROUND_TRUTH_DIR, PREDICTION_DIR]:
        if not os.path.exists(dir_name):
            os.makedirs(dir_name)

    ground_truth_dict = build_ground_truth(GROUND_TRUTH_DIR)
    
    logs = restrict_to_common_signals(load_event_logs(REAL_OP_DIR))
    types = signal_types(logs)
    if MODE in ("cross_sectional", "both"):
        _, pred_path = cross_sectional(logs, types)
        pred_truth_dict = pred_to_ground_truth_graphs(pred_path, out_dir=PREDICTION_DIR)    

    if MODE in ("time_series", "both"):
        time_series(logs, types)
    print(f"\nResults saved in: {OUTPUT_DIR}")

    eval_metrics = get_eval_metrics(ground_truth_dict, pred_truth_dict)
    print("\nEvaluation metrics:")
    for metric, value in eval_metrics.items():
        print(f"{metric}: {value}")



if __name__ == "__main__":
    main()