"""
scm_evaluation
==============

Turn a predicted adjacency matrix into a causal graph, fit a DoWhy structural
causal model (SCM) on the data and evaluate it. Everything is written to
``output_dir`` (default ``OUTPUT_DIR``):

    <tag>_scm_evaluation.txt       mechanism assignment summary + evaluation report
    <tag>_scm_falsification.png    graph-falsification histograms (LMC and TPa tests)
    <tag>_scm_ici_<target>.png     optional intrinsic causal influence bar plot

Requires: dowhy, networkx, matplotlib.
"""

import os
import warnings
from typing import Any, Dict, List, Optional, Tuple

import networkx as nx
import numpy as np
import pandas as pd

from utils import OUTPUT_DIR

BINARY_TYPES = {"binary", "bool", "boolean", "alarm"}


# --------------------------------------------------------------------------- #
# Adjacency -> graph
# --------------------------------------------------------------------------- #
def adjacency_to_digraph(
    adjacency: pd.DataFrame, on_cycle: str = "drop_weakest"
) -> Tuple[nx.DiGraph, List[Tuple[str, str]]]:
    """
    Build a directed graph from an adjacency matrix (``[i, j] != 0`` means ``i -> j``).

    DoWhy's SCM needs a DAG. If the matrix has cycles (e.g. a PCMCI summary
    graph) then, with ``on_cycle="drop_weakest"``, the edge with the smallest
    ``abs(weight)`` of each cycle is removed until the graph is acyclic (for a
    0/1 matrix this picks an arbitrary edge of the cycle). ``on_cycle="error"``
    raises instead.

    Returns
    -------
    graph : networkx.DiGraph
    removed : list of (source, target)
        Edges removed to break cycles.
    """
    if list(adjacency.index) != list(adjacency.columns):
        adjacency = adjacency.loc[list(adjacency.columns), list(adjacency.columns)]
    nodes = list(adjacency.columns)
    values = adjacency.to_numpy()

    graph = nx.DiGraph()
    graph.add_nodes_from(nodes)
    for i, j in zip(*np.nonzero(values)):
        if i != j:
            graph.add_edge(nodes[i], nodes[j], weight=abs(float(values[i, j])))

    removed: List[Tuple[str, str]] = []
    while not nx.is_directed_acyclic_graph(graph):
        if on_cycle == "error":
            raise ValueError("The adjacency matrix contains a cycle; a DAG is required.")
        cycle = nx.find_cycle(graph)
        u, v = min(cycle, key=lambda e: graph.edges[e[0], e[1]]["weight"])[:2]
        graph.remove_edge(u, v)
        removed.append((u, v))
    return graph, removed


# --------------------------------------------------------------------------- #
# Data typing
# --------------------------------------------------------------------------- #
def apply_dtypes(df: pd.DataFrame, dtypes: Dict[str, str]) -> pd.DataFrame:
    """
    Cast columns so that DoWhy recognises their type: binary columns become
    ``bool`` (DoWhy treats bool/str as categorical -> classifier mechanisms),
    all others ``float``. Columns not listed in ``dtypes`` are binary when they
    contain only 0 and 1.
    """
    out = df.copy()
    for col in out.columns:
        declared = (dtypes or {}).get(col)
        values = np.unique(out[col].dropna().to_numpy())
        is_01 = len(values) <= 2 and set(values) <= {0, 1, 0.0, 1.0, False, True}
        if declared is None:
            binary = is_01 and len(values) == 2
        else:
            binary = str(declared).lower() in BINARY_TYPES
            if binary and not is_01:
                warnings.warn(f"'{col}' is declared binary but is not 0/1; treated as numeric.")
                binary = False
        out[col] = out[col].astype(bool) if binary else out[col].astype(float)
    return out


# --------------------------------------------------------------------------- #
# SCM fitting and evaluation
# --------------------------------------------------------------------------- #
def evaluate_scm(
    adjacency: pd.DataFrame,
    df: pd.DataFrame,
    dtypes: Dict[str, str],
    tag: str = "model",
    output_dir: str = OUTPUT_DIR,
    max_rows: Optional[int] = 20000,
    quality: str = "GOOD",
    evaluate_structure: bool = True,
    ici_target: Optional[str] = None,
    on_cycle: str = "drop_weakest",
    random_state: int = 0,
) -> Dict[str, Any]:
    """
    Build the SCM from ``adjacency``, fit it on ``df`` and evaluate it.

    Parameters
    ----------
    adjacency : pandas.DataFrame
        ``[i, j] != 0`` means ``i -> j``; rows and columns named by variable.
    df : pandas.DataFrame
        Data containing (at least) the columns of ``adjacency``.
    dtypes : dict
        Column -> type; ``binary``/``bool``/``alarm`` columns are modelled as
        categorical (classifiers), the rest as numeric.
    tag : str
        File-name prefix, e.g. ``"lingam_big"``.
    output_dir : str
        Where the files are written.
    max_rows : int or None, default 20000
        Rows sampled for fitting and evaluation (the SCM fit with GOOD quality
        is slow on very large data). ``None`` uses all rows.
    quality : {"GOOD", "BETTER"}, default "GOOD"
        ``gcm.auto.AssignmentQuality`` used to choose the mechanisms.
    evaluate_structure : bool, default True
        Run the graph falsification (LMC and TPa) and save its figure. This is
        the slowest part; set False for a quick run.
    ici_target : str, optional
        If given, also compute the intrinsic causal influence on this node
        (% of its variance attributed to each upstream feature) and save a bar plot.
    on_cycle : {"drop_weakest", "error"}
        See ``adjacency_to_digraph``.

    Returns
    -------
    dict
        ``scm``, ``graph``, ``removed_edges``, ``evaluation`` (DoWhy result),
        ``report_path`` and ``figure_paths``.
    """

    
    from dowhy import gcm
    
    

    os.makedirs(output_dir, exist_ok=True)
    gcm.util.general.set_random_seed(random_state)
    print("=== DoWhy SCM evaluation ===1")

    graph, removed = adjacency_to_digraph(adjacency, on_cycle=on_cycle)
    nodes = [n for n in graph.nodes if n in df.columns]
    if len(nodes) < len(graph.nodes):
        missing = sorted(set(graph.nodes) - set(nodes))
        warnings.warn(f"Nodes not in the data were removed from the graph: {missing}")
        graph = graph.subgraph(nodes).copy()

    print("=== DoWhy SCM evaluation ===2")
    data = df[list(graph.nodes)]
    if max_rows and len(data) > max_rows:
        data = data.sample(max_rows, random_state=random_state)
    const = [c for c in data.columns if data[c].nunique() <= 1]
    if const:
        warnings.warn(f"Constant columns dropped: {const}")
        graph.remove_nodes_from(const)
        data = data.drop(columns=const)
    data = apply_dtypes(data, dtypes).reset_index(drop=True)

    print("=== DoWhy SCM evaluation ===3")
    # 1-3. create SCM, assign mechanisms, fit
    scm = gcm.StructuralCausalModel(graph)
    assignment = gcm.auto.assign_causal_mechanisms(
        scm, data, override_models=True,
        quality=getattr(gcm.auto.AssignmentQuality, quality),
    )
    gcm.fit(scm, data)

    # 4. evaluate
    evaluation = gcm.evaluate_causal_model(
        scm, data,
        compare_mechanism_baselines=True,
        evaluate_invertibility_assumptions=False,
        evaluate_causal_structure=evaluate_structure,
    )
    evaluation.plot_falsification_histogram = False   # we save the figure instead of showing it

    figure_paths: List[str] = []
    if evaluation.graph_falsification is not None:
        path = os.path.join(output_dir, f"{tag}_scm_falsification.png")
        #plot_evaluation_results(evaluation.graph_falsification, savepath=path,
        #                       display=False, title=f"{tag}: LMC and TPa")
        #figure_paths.append(path)

    ici_text = ""
    if ici_target is not None:
        if ici_target not in graph.nodes:
            warnings.warn(f"ICI target '{ici_target}' is not in the graph; skipped.")
        else:
            from dowhy.utils import bar_plot
            contributions = gcm.intrinsic_causal_influence(scm, ici_target)
            total = sum(abs(v) for v in contributions.values()) or 1.0
            pct = {k: 100 * abs(v) / total for k, v in contributions.items()}
            path = os.path.join(output_dir, f"{tag}_scm_ici_{ici_target}.png")
            bar_plot(pct, ylabel=f"% of variance of {ici_target}",
                     filename=path, display_plot=False)
            figure_paths.append(path)
            ici_text = ("\n\n==== Intrinsic causal influence on " + ici_target + " (%) ====\n"
                        + "\n".join(f"{k}: {v:.2f}" for k, v in
                                    sorted(pct.items(), key=lambda kv: -kv[1])))

    # report
    report_path = os.path.join(output_dir, f"{tag}_scm_evaluation.txt")
    with open(report_path, "w", encoding="utf-8") as fh:
        fh.write(f"Graph: {graph.number_of_nodes()} nodes, {graph.number_of_edges()} edges\n")
        if removed:
            fh.write(f"Edges removed to break cycles ({len(removed)}): {removed}\n")
        fh.write(f"Rows used: {len(data)}\n\n==== Mechanism assignment ====\n")
        fh.write(str(assignment))
        fh.write("\n\n" + str(evaluation))
        fh.write(ici_text + "\n")
    print(f"Report -> {report_path}")
    for p in figure_paths:
        print(f"Figure -> {p}")

    return {"scm": scm, "graph": graph, "removed_edges": removed, "evaluation": evaluation,
            "report_path": report_path, "figure_paths": figure_paths}