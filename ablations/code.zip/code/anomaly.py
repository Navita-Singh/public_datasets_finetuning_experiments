import pandas as pd
import numpy as np

def detect_bollinger_anomalies_all_numeric(big: pd.DataFrame, datatypes: dict, 
                                           window: int = 30, 
                                           suppress_warmup: bool = True) -> pd.DataFrame:
    """
    Performs 2-standard-deviation Bollinger Band anomaly detection on all numeric columns 
    specified in the datatypes dictionary, with clean handling of the warm-up period.
    
    Parameters:
    - big: pd.DataFrame containing the dataset.
    - datatypes: dict mapping column names to their data types (e.g., 'numeric', 'int', 'float').
    - window: int, rolling window size for the Bollinger Bands.
    - suppress_warmup: bool, if True, suppresses anomaly flags during the initial warm-up 
                       period (first `window` rows) to prevent false positives from unstable early statistics.
                       
    Returns:
    - pd.DataFrame with original data plus Bollinger bands and anomaly flags for each numeric column.
    """
    df = big.copy()
    
    # 1. Identify columns marked as numeric in datatypes
    numeric_cols = []
    for col, dtype in datatypes.items():
        dtype_str = str(dtype).lower()
        if col in df.columns and any(t in dtype_str for t in ['numeric', 'int', 'float', 'double', 'decimal']):
            numeric_cols.append(col)
            
    # Fallback to pandas numeric dtypes if none explicitly matched in the dictionary
    if not numeric_cols:
        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()

    # 2. Iterate through each numeric column and apply Bollinger Bands
    for col in numeric_cols:
        series = pd.to_numeric(df[col], errors='coerce')
        
        # Use min_periods=1 to compute values from the start
        rolling_mean = series.rolling(window=window, min_periods=1).mean()
        rolling_std = series.rolling(window=window, min_periods=1).std().fillna(0)
        
        upper_band = rolling_mean + (2 * rolling_std)
        lower_band = rolling_mean - (2 * rolling_std)
        
        # Detect raw anomalies
        anomaly_flag = (series > upper_band) | (series < lower_band)
        
        # 3. Handle warm-up period cleanly
        if suppress_warmup:
            # Force anomaly flag to False for the initial warm-up window to avoid false positives
            anomaly_flag.iloc[:window] = False
        
        # Store results in the DataFrame
        df[f'{col}_bollinger_upper'] = upper_band
        df[f'{col}_bollinger_lower'] = lower_band
        df[f'{col}_bollinger_anomaly'] = anomaly_flag
        
    return df