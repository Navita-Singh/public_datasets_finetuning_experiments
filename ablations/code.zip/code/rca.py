
import os
import sys
import pandas as pd
#from turtle import turtle
from utils import DATA_DIR, REAL_OP_DIR, OUTPUT_DIR, GROUND_TRUTH_DIR, PREDICTION_DIR, FULL_GRAPH_DIR, COOLANT_DIR, HYDRAULICS_DIR, PROBE_DIR
from ground_truth_prediction import build_ground_truth
from pathlib import Path
rca_utils_path = str(Path.cwd()) + "/utils"
sys.path.append(rca_utils_path)
from rca_algorithms import TimeRecency_BaselineUnsupervisedRCA, CausalPrioTimeRecencyRCA, PageRankRCA, RandomWalkRCA, Baro
import networkx as nx

import json

type_folder_dict = {
    "coolant": COOLANT_DIR,
    "hydraulics": HYDRAULICS_DIR,
    "probe": PROBE_DIR
}


def load_coolant_config(file_path: str):
    """
    Reads the coolant experiment JSON file and returns:
    - manipulatedVars as a list
    - alarms as a list
    - diagnoses as a dictionary keyed by diagnosis 'id'
    """
    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
        
    manipulated_vars = data.get("manipulatedVars", [])
    alarms = data.get("alarms", [])
    
    # Transform the diagnoses list into a dictionary keyed by 'id'
    diagnoses_list = data.get("diagnoses", [])
    diagnoses_dict = {diag["id"]: diag for diag in diagnoses_list}

    return manipulated_vars, alarms, diagnoses_dict


def main(rca_model_type: str) -> None:

    res_dict = {}
    for dir_name in [OUTPUT_DIR, GROUND_TRUTH_DIR, PREDICTION_DIR]:
        if not os.path.exists(dir_name):
            os.makedirs(dir_name)

    ground_truth_dict = build_ground_truth(GROUND_TRUTH_DIR) # Dictionary of {graph_name: adjacency DataFrame} for the ground truth graphs
    
    #print("Ground truth graphs built and saved to", ground_truth_dict['coolant'])
    # 1. Initialize the model
    if rca_model_type == "time_recency":model = TimeRecency_BaselineUnsupervisedRCA()

    for key in ['coolant', 'hydraulics', 'probe']:

        total_count, correct_count = 0, 0
        coolant_nodes = ground_truth_dict[key].columns.tolist()
        # Convert to a directed graph preserving node names
        G = nx.from_pandas_adjacency(ground_truth_dict[key], create_using=nx.DiGraph)
        if rca_model_type == "causal_prio":
            model = CausalPrioTimeRecencyRCA(G)
        elif rca_model_type == "pagerank":
            model = PageRankRCA(G)
        elif rca_model_type == "random_walk":
            model = RandomWalkRCA(G)
        elif rca_model_type == "baro":
            model = Baro()

        #print("Nodes:", G.nodes())
        #print(key, "Edges:", G.edges())

        exp_folders = [f for f in Path(type_folder_dict[key]).iterdir() if f.is_dir() and f.name.startswith("exp_")]
        for exp_folder in exp_folders:
            run_folders = [f for f in exp_folder.iterdir() if f.is_dir() and f.name.startswith("run_")]
            exp_name = exp_folder.name
            exp_rca_json_path = os.path.join(exp_folder, f"{exp_name}_description.json")
            #print(f"Loading RCA ground truth from {exp_rca_json_path}...")
            manipulated_vars, alarms, diagnoses_dict = load_coolant_config(exp_rca_json_path)
            #print(f"Ground truth for {exp_name}: {manipulated_vars}")

            for run_folder in run_folders:
                total_count += 1
                run_name = run_folder.name
                amended_exp_name = exp_name.replace("_", "")
                if exp_name =="exp_2_3": amended_exp_name = "exp2"
                
                dataset_csv_path = os.path.join(run_folder, f"faultDataset_{key}_{amended_exp_name}_{run_name}.csv")
                #print(f"Processing {dataset_csv_path}...")
                causes_json_path = os.path.join(run_folder, f"causes.json")
                with open(causes_json_path, 'r', encoding='utf-8') as f:
                    causes_data_dict = json.load(f)
                        
                
                # 2. Call predict to get an ordered list of likely root causes
                root_causes = model.predict(
                    dataset_csv_path=dataset_csv_path,
                    diagnosis_time = causes_data_dict["diagnosis_at"]
                )
                ranked_root_causes = [x for x in root_causes if x in coolant_nodes]
                # 3. Compare the predicted root causes with the ground truth
                if ranked_root_causes[0] in manipulated_vars:  # Check if the top prediction is in the ground truth
                    correct_count += 1
                #print(f"Run: {run_name}, Predicted: {ranked_root_causes}, Ground Truth: {manipulated_vars}, Correct: {ranked_root_causes[0] in manipulated_vars}")

        #print(f"Total runs processed for {key}: {total_count}, Correct predictions: {correct_count}, Accuracy: {correct_count / total_count if total_count > 0 else 0:.2f}")
        res_dict[key] = (total_count, correct_count)
    return res_dict


if __name__ == "__main__":

    for rca_model_type in ["time_recency", "causal_prio", "pagerank", "random_walk", "baro"]:

        res_dict = main(rca_model_type=rca_model_type)
        for key in ['coolant', 'hydraulics', 'probe']:
            total_count, correct_count = res_dict[key]
            accuracy = correct_count / total_count if total_count > 0 else 0
            print(f"Results for {rca_model_type}-{key}: Total runs: {total_count}, Correct predictions: {correct_count}, Accuracy: {accuracy:.2f}")
