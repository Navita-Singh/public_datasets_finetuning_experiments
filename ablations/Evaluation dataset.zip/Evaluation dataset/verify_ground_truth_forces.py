"""
verify_ground_truth_forces.py -- Check Src/forces.py against the ground-truth
values of tasks T1-T6 (see forces_evaluation_tasks.docx) and lint it against
Skills/fea_skills.md conventions.

Usage:  python dataset_tools/verify_ground_truth_forces.py [path/to/Src/forces.py]

Each check_Tn(module) returns a list of (description, passed) tuples. These are
dataset-side checks and are not shown to the agent. All expected values are
hand calculations, closed forms or equilibrium identities.
Conventions: angles in radians, moments counter-clockwise positive.
"""
import importlib.util
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from verify_ground_truth import lint_conventions  # noqa: E402

G = 9.81
DEG = np.pi / 180.0


def _close(got, expected, rtol=1e-6, atol=0.0):
    return bool(np.allclose(got, expected, rtol=rtol, atol=atol))


def load_module(src_dir, name="forces_under_test"):
    """Import forces.py from ``src_dir`` (it has no project dependencies)."""
    spec = importlib.util.spec_from_file_location(name, Path(src_dir) / "forces.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def raises(fn, name):
    """True if fn() raises ValueError whose message contains ``name``."""
    try:
        fn()
    except ValueError as exc:
        return name in str(exc)
    except Exception:  # noqa: BLE001
        return False
    return False


# ---- the checks --------------------------------------------------------------
def check_T1(m):
    uniform = m.trapezoid_load_resultant(4.0, 5000.0, 5000.0)
    tri_up = m.trapezoid_load_resultant(3.0, 0.0, 6000.0)
    tri_down = m.trapezoid_load_resultant(3.0, 6000.0, 0.0)
    trap = m.trapezoid_load_resultant(5.0, 2000.0, 6000.0)
    neg = m.trapezoid_load_resultant(4.0, -5000.0, -5000.0)
    # composite check for the trapezoid: rectangle 2000*5 at 2.5 m + triangle 4000*5/2 at 10/3 m
    composite = (2000.0 * 5.0 * 2.5 + 0.5 * 4000.0 * 5.0 * (2.0 * 5.0 / 3.0)) / (2000.0 * 5.0 + 0.5 * 4000.0 * 5.0)
    return [
        ("uniform 5 kN/m over 4 m: R = 20 kN at 2.0 m", _close(uniform, (20000.0, 2.0))),
        ("triangle 0 -> 6 kN/m over 3 m: R = 9 kN at 2L/3 = 2.0 m", _close(tri_up, (9000.0, 2.0))),
        ("triangle 6 -> 0 kN/m over 3 m: R = 9 kN at L/3 = 1.0 m", _close(tri_down, (9000.0, 1.0))),
        ("trapezoid 2 -> 6 kN/m over 5 m: R = 20 kN", _close(trap[0], 20000.0)),
        ("trapezoid centroid = 2.9167 m (matches rectangle + triangle composite)", _close(trap[1], composite)),
        ("downward (negative) uniform load: R = -20 kN at 2.0 m", _close(neg, (-20000.0, 2.0))),
        ("w_start + w_end = 0 raises ValueError", raises(lambda: m.trapezoid_load_resultant(4.0, 1000.0, -1000.0), "w_start")),
        ("length <= 0 raises ValueError naming 'length'", raises(lambda: m.trapezoid_load_resultant(0.0, 1.0, 1.0), "length")),
    ]


def check_T2(m):
    square = np.array([[0.1, 0.1], [-0.1, 0.1], [-0.1, -0.1], [0.1, -0.1]])
    r = m.bolt_group_shear(square, [0.0, -10.0e3], [0.4, 0.0])
    expected = np.array([[5000, -7500], [5000, 2500], [-5000, 2500], [-5000, -7500]], dtype=float)
    tri = np.array([[0.0, 0.0], [0.2, 0.0], [0.1, 0.2]])
    load, point = np.array([3000.0, -4000.0]), np.array([0.5, 0.3])
    t = m.bolt_group_shear(tri, load, point)
    centre = tri.mean(axis=0)
    moment_of_bolts = sum(p_[0] * f[1] - p_[1] * f[0] for p_, f in zip(tri - centre, t["forces"]))
    moment_of_load = (point[0] - centre[0]) * load[1] - (point[1] - centre[1]) * load[0]
    through = m.bolt_group_shear(square, [0.0, -10.0e3], [0.0, 0.0])
    # Published EN 1993 worked example (mm, kN; the formula is scale-free):
    # 4 bolts at (+/-50, +/-50) mm, P = 100 kN at e = 200 mm -> critical bolt 90.1 kN.
    en = m.bolt_group_shear([[50, 50], [-50, 50], [-50, -50], [50, -50]], [0.0, -100.0], [200.0, 0.0])
    return [
        ("square group, load 10 kN down at e = 0.4 m: M = -4000 N*m", _close(r["moment"], -4000.0)),
        ("square group: J = sum r^2 = 0.08 m^2", _close(r["polar_moment"], 0.08)),
        ("square group: bolt forces (5000,-7500), (5000,2500), (-5000,2500), (-5000,-7500) N", _close(r["forces"], expected)),
        ("square group: magnitudes 9013.9, 5590.2, 5590.2, 9013.9 N", _close(r["magnitudes"], [9013.878, 5590.170, 5590.170, 9013.878], rtol=1e-6)),
        ("square group: forces sum to the load", _close(r["forces"].sum(axis=0), [0.0, -10.0e3], atol=1e-6)),
        ("square group: centroid at the origin", _close(r["centroid"], [0.0, 0.0], atol=1e-12)),
        ("3-bolt group: forces sum to the applied load", _close(t["forces"].sum(axis=0), load, atol=1e-6)),
        ("3-bolt group: bolt moments about the centroid equal the load moment", _close(moment_of_bolts, moment_of_load, atol=1e-6)),
        ("load through the centroid: pure direct shear P/n", _close(through["forces"], [[0.0, -2500.0]] * 4, atol=1e-6)),
        ("EN 1993 example: sum r^2 = 20000 mm^2 and moment = 20000 kN*mm", _close([en["polar_moment"], abs(en["moment"])], [20000.0, 20000.0])),
        ("EN 1993 example: critical bolt force = sqrt(50^2 + 75^2) = 90.1 kN", _close(en["magnitudes"].max(), 90.1388, rtol=1e-5)),
        ("EN 1993 example: torsional component 50 kN on top of direct shear 25 kN", _close(en["forces"][0], [50.0, -75.0])),
        ("fewer than two bolts raises ValueError", raises(lambda: m.bolt_group_shear([[0.0, 0.0]], [0.0, -1.0], [0.0, 0.0]), "bolt_positions")),
    ]


def check_T3(m):
    mass, th, ms, mk = 100.0, 30.0 * DEG, 0.4, 0.3
    w = mass * G
    n = w * np.cos(th)
    drive = w * np.sin(th)
    f0 = m.block_on_incline(mass, th, ms, mk)
    f300 = m.block_on_incline(mass, th, ms, mk, applied_force=300.0)
    f100 = m.block_on_incline(mass, th, ms, mk, applied_force=100.0)
    f700 = m.block_on_incline(mass, th, ms, mk, applied_force=700.0)
    f900 = m.block_on_incline(mass, th, ms, mk, applied_force=900.0)
    return [
        ("F=0: N = W cos(theta) = 849.57 N", _close(f0["normal_force"], n)),
        ("F=0: tendency 490.5 N > mu_s N = 339.8 N, so it slips", f0["slipping"] is True),
        ("F=0: a = g (sin - mu_k cos) = 2.3563 m/s^2 down the slope", _close(f0["acceleration"], G * (np.sin(th) - mk * np.cos(th)))),
        ("F=0: kinetic friction = +254.87 N (up the slope)", _close(f0["friction_force"], mk * n)),
        ("F=300 N up: held at rest, friction = W sin - F = 190.5 N", f300["slipping"] is False and _close(f300["friction_force"], drive - 300.0) and f300["acceleration"] == 0.0),
        ("F=100 N up: still slips, a = (W sin - F - mu_k N)/m = 1.3563 m/s^2", f100["slipping"] is True and _close(f100["acceleration"], (drive - 100.0 - mk * n) / mass)),
        ("F=700 N up: held at rest, friction = -209.5 N (acts down the slope)", f700["slipping"] is False and _close(f700["friction_force"], drive - 700.0)),
        ("F=900 N up: slides up the slope, a = -1.5463 m/s^2, friction = -254.87 N",
         f900["slipping"] is True and _close(f900["acceleration"], (drive - 900.0 + mk * n) / mass) and _close(f900["friction_force"], -mk * n)),
    ]


def check_T4(m):
    a, b = m.cable_tensions_2d(1000.0, 30.0 * DEG, 60.0 * DEG)
    c, d = m.cable_tensions_2d(1000.0, 60.0 * DEG, 30.0 * DEG)
    e, f = m.cable_tensions_2d(1000.0, 45.0 * DEG, 45.0 * DEG)
    a1, a2 = 20.0 * DEG, 50.0 * DEG
    t1, t2 = m.cable_tensions_2d(750.0, a1, a2)
    return [
        ("30 deg / 60 deg, W = 1000 N: T_left = 500 N", _close(a, 500.0)),
        ("30 deg / 60 deg, W = 1000 N: T_right = 866.03 N", _close(b, 866.0254)),
        ("angles swapped (60 deg / 30 deg): 866.03 N and 500 N", _close([c, d], [866.0254, 500.0])),
        ("symmetric 45 deg: 707.11 N each", _close([e, f], [707.1068, 707.1068])),
        ("20 deg / 50 deg: horizontal balance T1 cos a1 = T2 cos a2", _close(t1 * np.cos(a1), t2 * np.cos(a2))),
        ("20 deg / 50 deg: vertical balance T1 sin a1 + T2 sin a2 = W", _close(t1 * np.sin(a1) + t2 * np.sin(a2), 750.0)),
    ]


def check_T5(m):
    th = 30.0 * DEG
    ok = m.block_on_incline(100.0, th, 0.4, 0.3)
    cases = [
        ("mass=0 raises ValueError naming 'mass'", lambda: m.block_on_incline(0.0, th, 0.4, 0.3), "mass"),
        ("mass<0 raises ValueError naming 'mass'", lambda: m.block_on_incline(-5.0, th, 0.4, 0.3), "mass"),
        ("angle=pi/2 raises ValueError naming 'angle_rad'", lambda: m.block_on_incline(100.0, np.pi / 2, 0.4, 0.3), "angle_rad"),
        ("angle<0 raises ValueError naming 'angle_rad'", lambda: m.block_on_incline(100.0, -0.1, 0.4, 0.3), "angle_rad"),
        ("mu_static<0 raises ValueError naming 'mu_static'", lambda: m.block_on_incline(100.0, th, -0.1, 0.3), "mu_static"),
        ("mu_kinetic>mu_static raises ValueError naming 'mu_kinetic'", lambda: m.block_on_incline(100.0, th, 0.2, 0.3), "mu_kinetic"),
        ("gravity=0 raises ValueError naming 'gravity'", lambda: m.block_on_incline(100.0, th, 0.4, 0.3, gravity=0.0), "gravity"),
    ]
    out = [("valid input unchanged (a = 2.3563 m/s^2)", _close(ok["acceleration"], G * (np.sin(th) - 0.3 * np.cos(th))))]
    out += [(label, raises(call, name)) for label, call, name in cases]
    out.append(("module docstring has no typo 'resutlants'", "resutlants" not in (m.__doc__ or "")))
    return out


def check_T6(m):
    skills = Path(m.__file__).resolve().parents[1] / "Skills" / "fea_skills.md"
    text = " ".join(skills.read_text().split()) if skills.exists() else ""
    r = m.resultant_2d([[100.0, 0.0], [0.0, 100.0]])
    couple = m.equivalent_force_couple_2d([[0, -100], [0, -200]], [[1, 0], [3, 0]], [0, 0])
    couple_b = m.equivalent_force_couple_2d([[0, -100], [0, -200]], [[1, 0], [3, 0]], [2, 0])
    return [
        ("moment of (0,-100) N at (2,0) about origin = -200 N*m (counter-clockwise positive)",
         _close(m.moment_about_point_2d([0.0, -100.0], [2.0, 0.0]), -200.0)),
        ("moment of (100,0) N at (0,3) about origin = -300 N*m", _close(m.moment_about_point_2d([100.0, 0.0], [0.0, 3.0]), -300.0)),
        ("moment about a reference point: (0,100) N at (3,1) about (1,1) = +200 N*m",
         _close(m.moment_about_point_2d([0.0, 100.0], [3.0, 1.0], [1.0, 1.0]), 200.0)),
        ("3D moment z-component equals the 2D moment", _close(m.moment_about_point_3d([0, -100, 0], [2, 0, 0])[2], -200.0)),
        ("3D moment of (0,0,10) N at (1,2,0): (20, -10, 0) N*m", _close(m.moment_about_point_3d([0, 0, 10], [1, 2, 0]), [20.0, -10.0, 0.0])),
        ("force-couple about origin: R = (0,-300) N, M = -700 N*m", _close(couple["force"], [0.0, -300.0]) and _close(couple["moment"], -700.0)),
        ("force-couple about (2,0): M = -100 N*m", _close(couple_b["moment"], -100.0)),
        ("resultant of (100,0) and (0,100): 141.42 N at pi/4", _close([r["magnitude"], r["angle_rad"]], [141.42136, np.pi / 4])),
        ("force_from_polar(10, pi/2) = (0, 10)", _close(m.force_from_polar(10.0, np.pi / 2), [0.0, 10.0], atol=1e-12)),
        ("fea_skills.md still states counter-clockwise rotation positive", "counter-clockwise rotation positive" in text),
        ("fea_skills.md was not changed to a clockwise-positive convention", "clockwise rotation positive" not in text.replace("counter-clockwise rotation positive", "")),
    ]


CHECKS = {f"T{i}": globals()[f"check_T{i}"] for i in range(1, 7)}


def run_check(task, module):
    """Run one task's check; any exception counts as a failed check."""
    try:
        return CHECKS[task](module)
    except Exception as exc:  # noqa: BLE001 - dataset tool, report anything
        return [(f"raised {type(exc).__name__}: {exc}", False)]


def main():
    src = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1] / "Src" / "forces.py"
    module = load_module(src.parent)
    failed = 0
    for task in CHECKS:
        results = run_check(task, module)
        n_ok = sum(ok for _, ok in results)
        status = "PASS" if n_ok == len(results) else "FAIL"
        failed += status == "FAIL"
        print(f"{task:>3}  {status}  ({n_ok}/{len(results)})")
        for label, ok in results:
            if not ok:
                print(f"        x {label}")
    problems = lint_conventions(src)
    print(f"\nConvention lint: {'clean' if not problems else str(len(problems)) + ' problem(s)'}")
    for p in problems:
        print("  -", p)
    sys.exit(1 if failed or problems else 0)


if __name__ == "__main__":
    main()
