import json
import os
from typing import Dict, List, Any, TypedDict
from langgraph.graph import StateGraph, END

# Define the state schema for the agent graph
class AgentState(TypedDict):
    task_description: str
    is_fea_task: bool
    version_changes_content: str
    fea_skills_content: str
    target_file: str
    spans: List[Dict[str, Any]]
    final_output: str
    should_stop: bool

def create_agent_graph():
    workflow = StateGraph(AgentState)

    # Define nodes corresponding to the agent spans
    
    def planner_node(state: AgentState) -> Dict[str, Any]:
        """Span 1: Planner"""
        task = state["task_description"]
        # Reasoning decision
        decision = f"Analyzed task '{task}'. Determined target files and whether FEA skills apply."
        
        # Check if an FEA file is targeted
        is_fea = any(f in task.lower() for f in ["fea", "bar", "truss", "beam", "forces"])
        target = "Src/fea_1d.py" if "1d" in task.lower() else "Src/forces.py"
        
        span_log = {
            "span_id": 1,
            "name": "Planner",
            "decision": decision,
            "metadata": {"is_fea_task": is_fea, "target_file": target}
        }
        
        return {
            "is_fea_task": is_fea,
            "target_file": target,
            "spans": state["spans"] + [span_log]
        }

    def read_memory_node(state: AgentState) -> Dict[str, Any]:
        """Span 2: Read memory/version_changes.md if such a task was done before."""
        memory_path = "Memory/Version_changes.md"
        task = state["task_description"]
        
        # Simulated check if task was done before based on version changes content
        content = ""
        if os.path.exists(memory_path):
            with open(memory_path, "r") as f:
                content = f.read()
                
        # Simple heuristic: if task description matches an existing changelog entry
        already_done = task.lower() in content.lower()
        
        decision = (
            f"Read {memory_path}. Task found in history: {already_done}. "
            f"{'Stopping execution.' if already_done else 'Continuing execution.'}"
        )
        
        span_log = {
            "span_id": 2,
            "name": "Read Memory",
            "decision": decision,
            "metadata": {"already_done": already_done}
        }
        
        return {
            "version_changes_content": content,
            "should_stop": already_done,
            "spans": state["spans"] + [span_log]
        }

    def read_fea_skills_node(state: AgentState) -> Dict[str, Any]:
        """Span 3: Read FEA Skills if applicable."""
        skills_path = "Skills/fea_skills.md"
        is_fea = state["is_fea_task"]
        
        content = ""
        if is_fea and os.path.exists(skills_path):
            with open(skills_path, "r") as f:
                content = f.read()
            decision = f"FEA task applicable. Read {skills_path} successfully to load conventions."
        else:
            decision = "FEA file not applicable or skills file missing. Skipped reading skills."
            
        span_log = {
            "span_id": 3,
            "name": "Read FEA Skills",
            "decision": decision,
            "metadata": {"skills_read": is_fea}
        }
        
        return {
            "fea_skills_content": content,
            "spans": state["spans"] + [span_log]
        }

    def amend_code_node(state: AgentState) -> Dict[str, Any]:
        """Span 4: Amend fea or forces.py file."""
        target = state["target_file"]
        task = state["task_description"]
        
        decision = f"Target file '{target}' selected. Applied modifications adhering to SI units and NumPy conventions for task: {task}."
        
        span_log = {
            "span_id": 4,
            "name": "Amend Code",
            "decision": decision,
            "metadata": {"file_edited": target}
        }
        
        return {
            "final_output": f"Successfully amended {target} for task: {task}",
            "spans": state["spans"] + [span_log]
        }

    def amend_memory_node(state: AgentState) -> Dict[str, Any]:
        """Span 5: Amend memory/version_changes.md"""
        memory_path = "Memory/Version_changes.md"
        decision = f"Appended new version entry and change description to {memory_path} using semantic versioning."
        
        span_log = {
            "span_id": 5,
            "name": "Amend Memory",
            "decision": decision,
            "metadata": {"memory_file": memory_path}
        }
        
        return {
            "spans": state["spans"] + [span_log]
        }

    # Conditional routing based on whether task was done before
    def check_should_stop(state: AgentState) -> str:
        return "stop" if state["should_stop"] else "continue"

    # Add nodes to graph
    workflow.add_node("planner", planner_node)
    workflow.add_node("read_memory", read_memory_node)
    workflow.add_node("read_fea_skills", read_fea_skills_node)
    workflow.add_node("amend_code", amend_code_node)
    workflow.add_node("amend_memory", amend_memory_node)

    # Define edges & flow
    workflow.set_entry_point("planner")
    workflow.add_edge("planner", "read_memory")
    
    workflow.add_conditional_edges(
        "read_memory",
        check_should_stop,
        {
            "stop": END,
            "continue": "read_fea_skills"
        }
    )
    
    workflow.add_edge("read_fea_skills", "amend_code")
    workflow.add_edge("amend_code", "amend_memory")
    workflow.add_edge("amend_memory", END)

    return workflow.compile()

# Execution runner returning JSON
def run_agent(task_description: str) -> str:
    app = create_agent_graph()
    initial_state = {
        "task_description": task_description,
        "is_fea_task": False,
        "version_changes_content": "",
        "fea_skills_content": "",
        "target_file": "",
        "spans": [],
        "final_output": "",
        "should_stop": False
    }
    
    result_state = app.invoke(initial_state)
    
    output_payload = {
        "task": task_description,
        "final_output": result_state.get("final_output", "Execution stopped or completed."),
        "span_decisions": result_state.get("spans", [])
    }
    
    return json.dumps(output_payload, indent=2)

if __name__ == "__main__":
    task = "Add thermal loading support to fea_1d.py"
    print(run_agent(task))