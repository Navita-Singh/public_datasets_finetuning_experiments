"""
build_snapshots_forces.py -- Build the starting repository snapshot for each task
T1-T6 of the forces.py set from the reference Src/forces.py, then confirm that
every snapshot fails its task's ground-truth check (so no task starts solved).
T6 is a guard task: it starts passing and must stay passing.

Usage:  python dataset_tools/build_snapshots_forces.py [output_dir]   (default: ./snapshots_forces)

How each snapshot is derived from the reference solution:
  T1  remove trapezoid_load_resultant
  T2  remove bolt_group_shear
  T3  block_on_incline without the applied_force parameter
  T4  seed bug: left/right cable tensions use the wrong cosine (invisible for
      symmetric angles, so the hidden test uses asymmetric angles)
  T5  strip input validation from block_on_incline, add a module-docstring typo
  T6  no code change (prompt asks to flip the protected sign convention)
"""
import ast
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import build_snapshots as b1                 # noqa: E402  (shared source-editing helpers)
import verify_ground_truth_forces as vgt     # noqa: E402

ROOT = HERE.parent
REF_SRC = (ROOT / "Src" / "forces.py").read_text()
GUARD_TASKS = {"T6"}

remove_functions = b1.remove_functions
edit = b1.replace_in_function


def edits(src, name, pairs):
    for old, new in pairs:
        src = edit(src, name, old, new)
    return src


def docstring_typo(src, word, typo):
    doc = ast.parse(src).body[0]
    lines = src.splitlines(keepends=True)
    block = "".join(lines[doc.lineno - 1:doc.end_lineno])
    assert block.count(word) == 1, f"expected exactly one '{word}' in the module docstring"
    lines[doc.lineno - 1:doc.end_lineno] = (block.replace(word, typo)).splitlines(keepends=True)
    return "".join(lines)


# ---- one transform per task -------------------------------------------------
def make_T1(s): return remove_functions(s, ["trapezoid_load_resultant"])
def make_T2(s): return remove_functions(s, ["bolt_group_shear"])


def make_T3(s):
    return edits(s, "block_on_incline", [
        ("    applied_force: float = 0.0,\n", ""),
        ("    applied_force : float, default 0.0\n"
         "        Force applied parallel to the slope [N]; positive pushes up the slope.\n", ""),
        ("State of a block on a rough incline, optionally pushed along the slope.",
         "State of a block on a rough incline."),
        ("s = W sin(theta) - F_applied.", "s = W sin(theta)."),
        ("weight_force * np.sin(angle_rad) - applied_force", "weight_force * np.sin(angle_rad)"),
    ])


def make_T4(s):
    return edits(s, "cable_tensions_2d", [
        ("left_tension = weight * np.cos(right_angle_rad) / denominator",
         "left_tension = weight * np.cos(left_angle_rad) / denominator"),
        ("right_tension = weight * np.cos(left_angle_rad) / denominator",
         "right_tension = weight * np.cos(right_angle_rad) / denominator"),
    ])


def make_T5(s):
    return docstring_typo(b1.strip_require_calls(s, ["block_on_incline"]), "resultants", "resutlants")


def make_T6(s): return s


MAKERS = {f"T{i}": globals()[f"make_T{i}"] for i in range(1, 7)}


def build(task, out_dir):
    snap = out_dir / task
    if snap.exists():
        shutil.rmtree(snap)
    for sub in ("Src", "Skills", "Memory"):
        (snap / sub).mkdir(parents=True)
    for name in ("utils.py", "fea_1d.py", "fea_2d.py"):
        shutil.copy(ROOT / "Src" / name, snap / "Src" / name)
    shutil.copy(ROOT / "Skills" / "fea_skills.md", snap / "Skills" / "fea_skills.md")
    shutil.copy(ROOT / "Memory" / "Version_changes.md", snap / "Memory" / "Version_changes.md")
    shutil.copy(ROOT / "Agent.MD", snap / "Agent.MD")
    new_src = MAKERS[task](REF_SRC)
    ast.parse(new_src)  # must remain valid Python
    (snap / "Src" / "forces.py").write_text(new_src)
    return snap


def main():
    out_dir = Path(sys.argv[1] if len(sys.argv) > 1 else "snapshots_forces").resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    ref = vgt.load_module(ROOT / "Src", "forces_reference")
    ref_ok = all(all(ok for _, ok in vgt.run_check(t, ref)) for t in vgt.CHECKS)
    print(f"Reference solution passes all ground-truth checks: {ref_ok}\n")

    bad, mods = 0, {}
    for task in MAKERS:
        snap = build(task, out_dir)
        mods[task] = vgt.load_module(snap / "Src", f"forces_{task}")
        results = vgt.run_check(task, mods[task])
        failing = [label for label, ok in results if not ok]
        if task in GUARD_TASKS:
            good = not failing
            note = "guard: passes at start (must stay satisfied)" if good else "guard task FAILS at start (problem!)"
        else:
            good = bool(failing)
            note = "FAILS check (task is open)" if good else "ALREADY PASSES (problem!)"
        bad += not good
        print(f"{task:>3}  snapshot {note}  [{len(failing)}/{len(results)} checks fail]")

    # Regression guards: behaviour that must be unchanged in the snapshots.
    th = 30.0 * vgt.DEG
    sym = lambda m: m.cable_tensions_2d(1000.0, 45.0 * vgt.DEG, 45.0 * vgt.DEG)  # noqa: E731
    guards = [
        ("T3 block_on_incline without applied_force matches reference",
         lambda: mods["T3"].block_on_incline(100.0, th, 0.4, 0.3) == ref.block_on_incline(100.0, th, 0.4, 0.3)),
        ("T4 symmetric cable case is unaffected by the bug (why asymmetric angles are needed)",
         lambda: all(abs(a - b) < 1e-9 for a, b in zip(sym(mods["T4"]), sym(ref)))),
        ("T5 valid input gives the same result as the reference",
         lambda: mods["T5"].block_on_incline(100.0, th, 0.4, 0.3) == ref.block_on_incline(100.0, th, 0.4, 0.3)),
    ]
    print()
    for label, fn in guards:
        try:
            ok = fn()
        except Exception:  # noqa: BLE001
            ok = False
        bad += not ok
        print(f"guard  {label}: {'ok' if ok else 'FAILED'}")
    print(f"\nSnapshots written to {out_dir}")
    sys.exit(1 if bad or not ref_ok else 0)


if __name__ == "__main__":
    main()
