"""
verify_ground_truth.py -- Check Src/fea_1d.py against the ground-truth values
of tasks T1-T10 (see fea_1d_evaluation_tasks.docx) and lint it against
Skills/fea_skills.md conventions.

Usage:  python dataset_tools/verify_ground_truth.py [path/to/Src/fea_1d.py]

Each check_Tn(module) returns a list of (description, passed) tuples. These
are dataset-side checks: they are not shown to the agent.
Load sign convention: positive = +axis direction, so a downward load is negative.
"""
import ast
import importlib.util
import sys
from pathlib import Path

import numpy as np

E = 200.0e9          # Pa
I = 8.0e-6           # m^4
EI = E * I           # N*m^2 (1.6e6)


def _close(got, expected, rtol=1e-6, atol=0.0):
    return bool(np.allclose(got, expected, rtol=rtol, atol=atol))


def load_module(src_dir, name="fea_1d_under_test"):
    """Import fea_1d.py from ``src_dir`` together with that folder's utils.py."""
    src_dir = str(Path(src_dir).resolve())
    sys.modules.pop("utils", None)
    sys.path.insert(0, src_dir)
    try:
        spec = importlib.util.spec_from_file_location(name, Path(src_dir) / "fea_1d.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
    finally:
        sys.path.remove(src_dir)
    return module


# ---------------------------------------------------------------------------
def check_T1(m):
    L, A, al, dT = 2.0, 1.0e-4, 12.0e-6, 50.0
    free = m.solve_bar_thermal(length=L, area=A, youngs_modulus=E, alpha=al,
                               delta_t=dT, n_elements=4, fixed_far_end=False)
    fixed = m.solve_bar_thermal(length=L, area=A, youngs_modulus=E, alpha=al,
                                delta_t=dT, n_elements=4, fixed_far_end=True)
    f_th = m.element_load_bar_thermal(A, E, al, dT)
    return [
        ("free bar tip = alpha*dT*L = 1.2e-3 m", _close(free["displacements"][-1], 1.2e-3)),
        ("free bar stress = 0", _close(free["stresses"], 0.0, atol=1e-3)),
        ("fixed-fixed stress = -E*alpha*dT = -120 MPa", _close(fixed["stresses"], -120.0e6)),
        ("fixed-fixed displacements = 0", _close(fixed["displacements"], 0.0, atol=1e-12)),
        ("fixed-fixed reactions = +12 kN / -12 kN",
         _close([fixed["reactions"][0], fixed["reactions"][-1]], [12.0e3, -12.0e3])),
        ("equivalent thermal load = E*A*alpha*dT = 12 kN", _close(np.abs(f_th), 12.0e3)),
    ]


def check_T2(m):
    r = m.solve_truss_2d(nodes=[[0, 0], [2, 0], [1, 1]], elements=[(0, 2), (1, 2)],
                         areas=1.0e-4, loads={2: (0.0, -10.0e3)},
                         supports={0: (True, True), 1: (True, True)})
    u = r["displacements"]
    rx = r["reactions"]
    return [
        ("member forces = -7.071 kN (compression)", _close(r["member_forces"], -7071.0678, rtol=1e-6)),
        ("member stresses = -70.71 MPa", _close(r["stresses"], -70.710678e6)),
        ("apex v = -7.071e-4 m", _close(u[5], -7.0710678e-4)),
        ("apex u = 0", _close(u[4], 0.0, atol=1e-12)),
        ("vertical reactions = 5 kN each", _close([rx[1], rx[3]], [5000.0, 5000.0])),
        ("horizontal reactions = +5 kN / -5 kN", _close([rx[0], rx[2]], [5000.0, -5000.0])),
    ]


def check_T3(m):
    out = []
    for n in (1, 2, 4):
        r = m.solve_beam_udl(length=2.0, youngs_modulus=E, second_moment=I,
                             distributed_load=-5000.0, n_elements=n)
        out += [
            (f"n={n}: tip deflection = -qL^4/(8EI) = -6.25e-3 m", _close(r["deflections"][-1], -6.25e-3)),
            (f"n={n}: tip rotation = -qL^3/(6EI) = -4.1667e-3 rad", _close(r["rotations"][-1], -5000.0 * 8.0 / (6.0 * EI))),
            (f"n={n}: wall reaction = 10 kN and 10 kN*m", _close(r["reactions"][:2], [10.0e3, 10.0e3])),
        ]
    f = m.element_load_beam_udl(2.0, -5000.0)
    out.append(("consistent loads = q*[L/2, L^2/12, L/2, -L^2/12]",
                _close(f, -5000.0 * np.array([1.0, 1.0 / 3.0, 1.0, -1.0 / 3.0]))))
    return out


def check_T4(m):
    out = []
    for n in (1, 3, 8):
        r = m.solve_bar(length=2.0, area=1.0e-4, youngs_modulus=E, tip_load=10.0e3, n_elements=n)
        out += [
            (f"n={n}: tip u = PL/EA = 1.0e-3 m", _close(r["displacements"][-1], 1.0e-3)),
            (f"n={n}: stress = P/A = 100 MPa", _close(r["stresses"], 100.0e6)),
        ]
    default = m.solve_bar(length=2.0, area=1.0e-4, youngs_modulus=E, tip_load=10.0e3)
    out.append(("call without n_elements still works (regression)", _close(default["displacements"][-1], 1.0e-3)))
    try:
        m.solve_bar(n_elements=0)
        out.append(("n_elements=0 raises ValueError", False))
    except ValueError:
        out.append(("n_elements=0 raises ValueError", True))
    return out


def check_T5(m):
    r = m.solve_beam(length=4.0, youngs_modulus=E, second_moment=I, point_load=-1000.0,
                     n_elements=4, support="simply_supported")
    cant = m.solve_beam(length=4.0, youngs_modulus=E, second_moment=I, point_load=-1000.0, n_elements=4)
    out = [
        ("midspan deflection = -PL^3/(48EI) = -8.333e-4 m", _close(r["deflections"][2], -8.3333333e-4)),
        ("end rotations = -/+ PL^2/(16EI) = 6.25e-4 rad", _close([r["rotations"][0], r["rotations"][-1]], [-6.25e-4, 6.25e-4])),
        ("support reactions = 500 N each", _close([r["reactions"][0], r["reactions"][-2]], [500.0, 500.0])),
        ("default cantilever tip = -PL^3/(3EI) = -0.013333 m", _close(cant["deflections"][-1], -0.0133333333)),
    ]
    try:
        m.solve_beam(n_elements=3, support="simply_supported")
        out.append(("odd n_elements on simply supported raises ValueError", False))
    except ValueError:
        out.append(("odd n_elements on simply supported raises ValueError", True))
    return out


def check_T6(m):
    length = 1.5
    expected = (E * I / length ** 3) * np.array([
        [12, 6 * length, -12, 6 * length],
        [6 * length, 4 * length ** 2, -6 * length, 2 * length ** 2],
        [-12, -6 * length, 12, -6 * length],
        [6 * length, 2 * length ** 2, -6 * length, 4 * length ** 2]])
    r = m.solve_beam(length=length, youngs_modulus=E, second_moment=I, point_load=-500.0, n_elements=3)
    return [
        ("element stiffness matrix matches (EI/L^3)[12, 6L, ...]", _close(m.element_stiffness_beam(length, E, I), expected, rtol=1e-12)),
        ("element stiffness matrix is symmetric", _close(m.element_stiffness_beam(length, E, I), m.element_stiffness_beam(length, E, I).T, rtol=1e-12)),
        ("tip deflection = -PL^3/(3EI) = -3.5156e-4 m", _close(r["deflections"][-1], -500.0 * length ** 3 / (3.0 * EI))),
    ]


def check_T7(m):
    r = m.solve_truss_2d(nodes=[[0, 0], [0, 3], [4, 0]], elements=[(0, 2), (1, 2)],
                         areas=2.0e-4, loads={2: (0.0, -10.0e3)},
                         supports={0: (True, True), 1: (True, True)})
    u = r["displacements"]
    return [
        ("member 1-3 = -13.333 kN", _close(r["member_forces"][0], -13333.333, rtol=1e-6)),
        ("member 2-3 = +16.667 kN", _close(r["member_forces"][1], 16666.667, rtol=1e-6)),
        ("node 3 u = -1.3333e-3 m", _close(u[4], -1.3333333e-3)),
        ("node 3 v = -5.25e-3 m", _close(u[5], -5.25e-3)),
    ]


def check_T8(m):
    out = []
    ok = m.solve_bar(length=2.0, area=1.0e-4, youngs_modulus=E, tip_load=10.0e3)
    out.append(("valid input unchanged (tip u = 1e-3 m)", _close(ok["displacements"][-1], 1.0e-3)))
    for label, kwargs, name in (("L=0", {"length": 0.0}, "length"),
                                ("A<0", {"area": -1.0e-4}, "area"),
                                ("E=0", {"youngs_modulus": 0.0}, "youngs_modulus")):
        try:
            m.solve_bar(**kwargs)
            out.append((f"{label} raises ValueError naming '{name}'", False))
        except ValueError as exc:
            out.append((f"{label} raises ValueError naming '{name}'", name in str(exc)))
        except Exception:
            out.append((f"{label} raises ValueError naming '{name}'", False))
    doc = m.__doc__ or ""
    out.append(("module docstring has no typo 'analyis'", "analyis" not in doc))
    return out


def check_T9(m):
    doc = m.element_stiffness_beam.__doc__ or ""
    needed = ["Parameters", "Returns", "Notes", "[m]", "[Pa]", "[m^4]"]
    out = [(f"docstring contains '{token}'", token in doc) for token in needed]
    out.append(("behaviour unchanged (tip = -3.5156e-4 m)",
                _close(m.solve_beam(length=1.5, youngs_modulus=E, second_moment=I,
                                    point_load=-500.0, n_elements=3)["deflections"][-1],
                       -500.0 * 1.5 ** 3 / (3.0 * EI))))
    return out


def check_T10(m):
    r = m.solve_beam(length=1.5, youngs_modulus=E, second_moment=I, point_load=-500.0, n_elements=3)
    import utils
    return [
        ("tip deflection = -3.5156e-4 m", _close(r["deflections"][-1], -500.0 * 1.5 ** 3 / (3.0 * EI))),
        ("utils.element_dofs is node-major ([2,5] -> [4,5,10,11])",
         list(utils.element_dofs([2, 5], 2)) == [4, 5, 10, 11]),
    ]


CHECKS = {f"T{i}": globals()[f"check_T{i}"] for i in range(1, 11)}


def run_check(task, module):
    """Run one task's check; any exception counts as a failed check."""
    try:
        return CHECKS[task](module)
    except Exception as exc:  # noqa: BLE001 - dataset tool, report anything
        return [(f"raised {type(exc).__name__}: {exc}", False)]


# ---------------------------------------------------------------------------
# Convention lint (Skills/fea_skills.md)
# ---------------------------------------------------------------------------
def lint_conventions(path):
    problems = []
    tree = ast.parse(Path(path).read_text())
    allowed = {"numpy", "typing", "__future__", "utils"}
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            mods = [a.name.split(".")[0] for a in node.names]
        elif isinstance(node, ast.ImportFrom):
            mods = [(node.module or "").split(".")[0]]
        else:
            continue
        problems += [f"disallowed import: {mod}" for mod in mods if mod not in allowed]
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and not node.name.startswith("_"):
            doc = ast.get_docstring(node) or ""
            for section in ("Parameters", "Returns", "Notes"):
                if section not in doc:
                    problems.append(f"{node.name}: docstring lacks '{section}'")
            if node.returns is None:
                problems.append(f"{node.name}: missing return annotation")
            for arg in node.args.args:
                if arg.annotation is None:
                    problems.append(f"{node.name}: argument '{arg.arg}' has no type hint")
            if any(isinstance(n, ast.Raise) for n in ast.walk(node)) and "Raises" not in doc:
                problems.append(f"{node.name}: raises but docstring lacks 'Raises'")
    return problems


def main():
    src = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1] / "Evaluation Dataset/Src" / "fea_1d.py"
    module = load_module(src.parent)
    failed = 0
    for task in CHECKS:
        results = run_check(task, module)
        n_ok = sum(ok for _, ok in results)
        status = "PASS" if n_ok == len(results) else "FAIL"
        failed += status == "FAIL"
        print(f"{task:>3}  {status}  ({n_ok}/{len(results)})")
        for label, ok in results:
            if not ok:
                print(f"        x {label}")
    problems = lint_conventions(src)
    print(f"\nConvention lint: {'clean' if not problems else str(len(problems)) + ' problem(s)'}")
    for p in problems:
        print("  -", p)
    sys.exit(1 if failed or problems else 0)


if __name__ == "__main__":
    main()
