"""
fea_2d.py -- Two-dimensional finite element solvers.

Plane stress and plane strain problems with 3-node constant strain triangles
(CST) and 4-node bilinear quadrilaterals (Q4), built on the shared assembly,
boundary-condition and shape-function utilities in ``utils.py``. Linear
elastic analysis with small displacements. All quantities are SI (m, N, Pa,
K); see Skills/fea_skills.md for the conventions.

Conventions
-----------
* DOF ordering is node-major with 2 DOFs per node (u, v).
* Triangles and quadrilaterals list their nodes counter-clockwise.
* Strains are engineering strains ``[eps_x, eps_y, gamma_xy]``; stresses are
  ``[sigma_x, sigma_y, tau_xy]`` [Pa]; tension is positive.
* Loads are signed: positive in the positive axis direction.
* Plane stress is the default; plane strain is selected with ``plane_type``.

Run with the ``Src`` folder on ``sys.path`` so that ``import utils`` resolves.
"""

from __future__ import annotations

from typing import Dict, List, Mapping, Sequence, Tuple, Union

import numpy as np

from utils import (
    assemble_global,
    assemble_global_vector,
    cst_B_matrix,
    element_dofs,
    gauss_points_2d,
    init_global_system,
    q4_B_matrix,
    solve_system,
)

# ---------------------------------------------------------------------------
# Named constants (SI)
# ---------------------------------------------------------------------------

STEEL_E_PA = 200.0e9
STEEL_NU = 0.30
STEEL_ALPHA_PER_K = 12.0e-6
STEEL_RHO_KG_M3 = 7850.0

ALUMINIUM_E_PA = 69.0e9
ALUMINIUM_NU = 0.33
ALUMINIUM_ALPHA_PER_K = 23.0e-6
ALUMINIUM_RHO_KG_M3 = 2700.0

DEFAULT_THICKNESS_M = 0.01
DEFAULT_DELTA_T_K = 50.0
DEFAULT_N_GAUSS = 2

DOFS_PER_NODE = 2
CST_NODES = 3
Q4_NODES = 4

PLANE_STRESS = "plane_stress"
PLANE_STRAIN = "plane_strain"

ELEMENT_CST = "cst"
ELEMENT_Q4 = "q4"
NODES_PER_ELEMENT = {ELEMENT_CST: CST_NODES, ELEMENT_Q4: Q4_NODES}

Number = Union[float, int]


# ---------------------------------------------------------------------------
# Input validation helpers
# ---------------------------------------------------------------------------

def _require_positive(name: str, value: float) -> None:
    """Raise ValueError unless ``value`` is a positive number."""
    if not value > 0.0:
        raise ValueError(f"{name} must be positive, got {value}")


def _require_positive_array(name: str, values: np.ndarray) -> None:
    """Raise ValueError unless every entry of ``values`` is positive."""
    if np.any(~(values > 0.0)):
        raise ValueError(f"{name} must be positive, got {values.tolist()}")


def _require_positive_int(name: str, value: int) -> None:
    """Raise ValueError unless ``value`` is an integer >= 1."""
    if isinstance(value, bool) or not isinstance(value, (int, np.integer)) or value < 1:
        raise ValueError(f"{name} must be an integer >= 1, got {value!r}")


def _require_poisson(value: float) -> None:
    """Raise ValueError unless 0 <= nu < 0.5."""
    if not 0.0 <= value < 0.5:
        raise ValueError(f"poissons_ratio must satisfy 0 <= nu < 0.5, got {value}")


# ---------------------------------------------------------------------------
# Constitutive law
# ---------------------------------------------------------------------------

def constitutive_matrix(
    youngs_modulus: float,
    poissons_ratio: float,
    plane_type: str = PLANE_STRESS,
) -> np.ndarray:
    """
    Elasticity matrix D relating engineering strains to stresses.

    Parameters
    ----------
    youngs_modulus : float
        Young's modulus [Pa], must be positive.
    poissons_ratio : float
        Poisson's ratio (dimensionless), 0 <= nu < 0.5.
    plane_type : str, default PLANE_STRESS
        ``"plane_stress"`` or ``"plane_strain"``.

    Returns
    -------
    numpy.ndarray, shape (3, 3)
        D [Pa] such that ``[sigma_x, sigma_y, tau_xy] = D @
        [eps_x, eps_y, gamma_xy]``.

    Raises
    ------
    ValueError
        If a property is out of range or ``plane_type`` is unknown.

    Notes
    -----
    Plane stress: D = E / (1 - nu^2) [[1, nu, 0], [nu, 1, 0], [0, 0, (1 - nu)/2]].
    Plane strain: D = E / ((1 + nu)(1 - 2 nu)) [[1 - nu, nu, 0], [nu, 1 - nu, 0],
    [0, 0, (1 - 2 nu)/2]]. The shear entry equals the shear modulus
    G = E / (2 (1 + nu)) in both cases.
    """
    _require_positive("youngs_modulus", youngs_modulus)
    _require_poisson(poissons_ratio)
    if plane_type == PLANE_STRESS:
        factor = youngs_modulus / (1.0 - poissons_ratio ** 2)
        shear = (1.0 - poissons_ratio) / 2.0
        return factor * np.array([
            [1.0, poissons_ratio, 0.0],
            [poissons_ratio, 1.0, 0.0],
            [0.0, 0.0, shear],
        ])
    if plane_type == PLANE_STRAIN:
        factor = youngs_modulus / ((1.0 + poissons_ratio) * (1.0 - 2.0 * poissons_ratio))
        return factor * np.array([
            [1.0 - poissons_ratio, poissons_ratio, 0.0],
            [poissons_ratio, 1.0 - poissons_ratio, 0.0],
            [0.0, 0.0, (1.0 - 2.0 * poissons_ratio) / 2.0],
        ])
    raise ValueError(
        f"plane_type must be '{PLANE_STRESS}' or '{PLANE_STRAIN}', got {plane_type!r}"
    )


def _thermal_strain(
    poissons_ratio: float, alpha: float, delta_t: float, plane_type: str
) -> np.ndarray:
    """In-plane free thermal strain vector for a uniform temperature change."""
    scale = 1.0 + poissons_ratio if plane_type == PLANE_STRAIN else 1.0
    return scale * alpha * delta_t * np.array([1.0, 1.0, 0.0])


# ---------------------------------------------------------------------------
# Element matrices and stress recovery
# ---------------------------------------------------------------------------

def element_stiffness_cst(
    coords: np.ndarray,
    youngs_modulus: float,
    poissons_ratio: float,
    thickness: float,
    plane_type: str = PLANE_STRESS,
) -> np.ndarray:
    """
    Stiffness matrix of a 3-node constant strain triangle.

    Parameters
    ----------
    coords : numpy.ndarray, shape (3, 2)
        Nodal coordinates (x, y) [m], listed counter-clockwise.
    youngs_modulus : float
        Young's modulus [Pa], must be positive.
    poissons_ratio : float
        Poisson's ratio (dimensionless), 0 <= nu < 0.5.
    thickness : float
        Element thickness [m], must be positive.
    plane_type : str, default PLANE_STRESS
        ``"plane_stress"`` or ``"plane_strain"``.

    Returns
    -------
    numpy.ndarray, shape (6, 6)
        Element stiffness matrix [N/m] for DOFs ``[u1, v1, u2, v2, u3, v3]``.

    Raises
    ------
    ValueError
        If an input is invalid or the triangle is degenerate or clockwise.

    Notes
    -----
    k = t A B^T D B, with B constant over the element and A the element
    area [m^2]. The matrix is symmetric and has three zero eigenvalues
    (rigid-body motions).
    """
    _require_positive("thickness", thickness)
    d_matrix = constitutive_matrix(youngs_modulus, poissons_ratio, plane_type)
    b_matrix, area = cst_B_matrix(coords)
    return thickness * area * (b_matrix.T @ d_matrix @ b_matrix)


def element_stiffness_q4(
    coords: np.ndarray,
    youngs_modulus: float,
    poissons_ratio: float,
    thickness: float,
    plane_type: str = PLANE_STRESS,
    n_gauss: int = DEFAULT_N_GAUSS,
) -> np.ndarray:
    """
    Stiffness matrix of a 4-node bilinear quadrilateral by Gauss integration.

    Parameters
    ----------
    coords : numpy.ndarray, shape (4, 2)
        Nodal coordinates (x, y) [m], listed counter-clockwise.
    youngs_modulus : float
        Young's modulus [Pa], must be positive.
    poissons_ratio : float
        Poisson's ratio (dimensionless), 0 <= nu < 0.5.
    thickness : float
        Element thickness [m], must be positive.
    plane_type : str, default PLANE_STRESS
        ``"plane_stress"`` or ``"plane_strain"``.
    n_gauss : int, default DEFAULT_N_GAUSS
        Gauss points per direction (dimensionless), must be >= 1.

    Returns
    -------
    numpy.ndarray, shape (8, 8)
        Element stiffness matrix [N/m] for DOFs ``[u1, v1, ..., u4, v4]``.

    Raises
    ------
    ValueError
        If an input is invalid or the element is distorted or clockwise.

    Notes
    -----
    k = sum_g w_g t det(J_g) B_g^T D B_g. The full 2 x 2 rule gives exactly
    three zero eigenvalues (rigid-body modes); a 1-point rule adds two
    spurious hourglass modes.
    """
    _require_positive("thickness", thickness)
    d_matrix = constitutive_matrix(youngs_modulus, poissons_ratio, plane_type)
    points, weights = gauss_points_2d(n_gauss)
    stiffness = np.zeros((DOFS_PER_NODE * Q4_NODES, DOFS_PER_NODE * Q4_NODES))
    for (xi, eta), weight in zip(points, weights):
        b_matrix, det_j = q4_B_matrix(xi, eta, coords)
        stiffness += thickness * weight * det_j * (b_matrix.T @ d_matrix @ b_matrix)
    return stiffness


def element_stress_cst(
    coords: np.ndarray,
    element_displacements: np.ndarray,
    youngs_modulus: float,
    poissons_ratio: float,
    plane_type: str = PLANE_STRESS,
) -> np.ndarray:
    """
    Stress in a constant strain triangle.

    Parameters
    ----------
    coords : numpy.ndarray, shape (3, 2)
        Nodal coordinates (x, y) [m], listed counter-clockwise.
    element_displacements : numpy.ndarray, shape (6,)
        Nodal displacements ``[u1, v1, u2, v2, u3, v3]`` [m].
    youngs_modulus : float
        Young's modulus [Pa], must be positive.
    poissons_ratio : float
        Poisson's ratio (dimensionless), 0 <= nu < 0.5.
    plane_type : str, default PLANE_STRESS
        ``"plane_stress"`` or ``"plane_strain"``.

    Returns
    -------
    numpy.ndarray, shape (3,)
        ``[sigma_x, sigma_y, tau_xy]`` [Pa], constant over the element.

    Raises
    ------
    ValueError
        If an input is invalid or the triangle is degenerate or clockwise.

    Notes
    -----
    sigma = D B u.
    """
    d_matrix = constitutive_matrix(youngs_modulus, poissons_ratio, plane_type)
    b_matrix, _ = cst_B_matrix(coords)
    return d_matrix @ (b_matrix @ element_displacements)


def element_stress_q4(
    coords: np.ndarray,
    element_displacements: np.ndarray,
    youngs_modulus: float,
    poissons_ratio: float,
    plane_type: str = PLANE_STRESS,
    xi: float = 0.0,
    eta: float = 0.0,
) -> np.ndarray:
    """
    Stress in a Q4 element at a point given in natural coordinates.

    Parameters
    ----------
    coords : numpy.ndarray, shape (4, 2)
        Nodal coordinates (x, y) [m], listed counter-clockwise.
    element_displacements : numpy.ndarray, shape (8,)
        Nodal displacements ``[u1, v1, ..., u4, v4]`` [m].
    youngs_modulus : float
        Young's modulus [Pa], must be positive.
    poissons_ratio : float
        Poisson's ratio (dimensionless), 0 <= nu < 0.5.
    plane_type : str, default PLANE_STRESS
        ``"plane_stress"`` or ``"plane_strain"``.
    xi, eta : float, default 0.0
        Natural coordinates of the evaluation point in [-1, 1]
        (dimensionless); the default is the element centre.

    Returns
    -------
    numpy.ndarray, shape (3,)
        ``[sigma_x, sigma_y, tau_xy]`` [Pa] at (xi, eta).

    Raises
    ------
    ValueError
        If an input is invalid or the element is distorted or clockwise.

    Notes
    -----
    sigma = D B(xi, eta) u. Q4 stresses vary within the element.
    """
    d_matrix = constitutive_matrix(youngs_modulus, poissons_ratio, plane_type)
    b_matrix, _ = q4_B_matrix(xi, eta, coords)
    return d_matrix @ (b_matrix @ element_displacements)


def element_thermal_load_cst(
    coords: np.ndarray,
    youngs_modulus: float,
    poissons_ratio: float,
    thickness: float,
    alpha: float,
    delta_t: float,
    plane_type: str = PLANE_STRESS,
) -> np.ndarray:
    """
    Equivalent nodal thermal load of a constant strain triangle.

    Parameters
    ----------
    coords : numpy.ndarray, shape (3, 2)
        Nodal coordinates (x, y) [m], listed counter-clockwise.
    youngs_modulus : float
        Young's modulus [Pa], must be positive.
    poissons_ratio : float
        Poisson's ratio (dimensionless), 0 <= nu < 0.5.
    thickness : float
        Element thickness [m], must be positive.
    alpha : float
        Coefficient of thermal expansion [1/K], must be positive.
    delta_t : float
        Uniform temperature change [K]; positive is heating.
    plane_type : str, default PLANE_STRESS
        ``"plane_stress"`` or ``"plane_strain"``.

    Returns
    -------
    numpy.ndarray, shape (6,)
        Element load vector [N] for DOFs ``[u1, v1, u2, v2, u3, v3]``.

    Raises
    ------
    ValueError
        If an input is invalid.

    Notes
    -----
    f = t A B^T D eps_th with eps_th = alpha dT [1, 1, 0] in plane stress and
    (1 + nu) alpha dT [1, 1, 0] in plane strain (out-of-plane strain zero).
    """
    _require_positive("thickness", thickness)
    _require_positive("alpha", alpha)
    d_matrix = constitutive_matrix(youngs_modulus, poissons_ratio, plane_type)
    b_matrix, area = cst_B_matrix(coords)
    thermal_strain = _thermal_strain(poissons_ratio, alpha, delta_t, plane_type)
    return thickness * area * (b_matrix.T @ (d_matrix @ thermal_strain))


# ---------------------------------------------------------------------------
# Global solvers
# ---------------------------------------------------------------------------

def _fixed_dofs(supports: Mapping[int, Sequence[bool]], n_nodes: int) -> List[int]:
    """Constrained global DOF indices from a node -> (fix_x, fix_y) mapping."""
    fixed: List[int] = []
    for node, (fix_x, fix_y) in supports.items():
        if not 0 <= node < n_nodes:
            raise ValueError(f"support node {node} is outside 0..{n_nodes - 1}")
        if fix_x:
            fixed.append(DOFS_PER_NODE * node)
        if fix_y:
            fixed.append(DOFS_PER_NODE * node + 1)
    return sorted(fixed)


def _element_strain(
    element_type: str, coords: np.ndarray, element_displacements: np.ndarray
) -> np.ndarray:
    """Engineering strain at the element centroid (CST) or centre (Q4)."""
    if element_type == ELEMENT_CST:
        b_matrix, _ = cst_B_matrix(coords)
    else:
        b_matrix, _ = q4_B_matrix(0.0, 0.0, coords)
    return b_matrix @ element_displacements


def _solve_plane(
    element_type: str,
    nodes: Sequence[Sequence[float]],
    elements: Sequence[Sequence[int]],
    loads: Mapping[int, Sequence[float]],
    supports: Mapping[int, Sequence[bool]],
    youngs_modulus: float,
    poissons_ratio: float,
    thickness: Union[Number, Sequence[float]],
    plane_type: str,
) -> Dict[str, np.ndarray]:
    """Shared assembly, solution and recovery for CST and Q4 meshes."""
    node_xy = np.asarray(nodes, dtype=float)
    if node_xy.ndim != 2 or node_xy.shape[1] != 2:
        raise ValueError(f"nodes must have shape (n_nodes, 2), got {node_xy.shape}")
    n_nodes = node_xy.shape[0]

    nodes_per_element = NODES_PER_ELEMENT[element_type]
    connectivity = np.asarray(elements, dtype=int)
    if (connectivity.ndim != 2 or connectivity.shape[1] != nodes_per_element
            or connectivity.shape[0] < 1):
        raise ValueError(
            f"elements must have shape (n_elements, {nodes_per_element}), "
            f"got {connectivity.shape}"
        )
    if np.any(connectivity < 0) or np.any(connectivity >= n_nodes):
        raise ValueError(f"elements reference a node outside 0..{n_nodes - 1}")
    n_elements = connectivity.shape[0]

    thickness_arr = np.broadcast_to(np.asarray(thickness, dtype=float), (n_elements,))
    _require_positive_array("thickness", thickness_arr)

    if element_type == ELEMENT_CST:
        stiffness_fn, stress_fn = element_stiffness_cst, element_stress_cst
    else:
        stiffness_fn, stress_fn = element_stiffness_q4, element_stress_q4

    stiffness, load = init_global_system(n_nodes, DOFS_PER_NODE)
    for e, conn in enumerate(connectivity):
        k_elem = stiffness_fn(
            node_xy[conn], youngs_modulus, poissons_ratio, thickness_arr[e], plane_type
        )
        assemble_global(stiffness, k_elem, element_dofs(conn, DOFS_PER_NODE))

    for node, (fx, fy) in loads.items():
        if not 0 <= node < n_nodes:
            raise ValueError(f"load node {node} is outside 0..{n_nodes - 1}")
        load[DOFS_PER_NODE * node] += fx
        load[DOFS_PER_NODE * node + 1] += fy

    displacements, reactions = solve_system(
        stiffness, load, _fixed_dofs(supports, n_nodes)
    )

    stresses = np.array([
        stress_fn(
            node_xy[conn], displacements[element_dofs(conn, DOFS_PER_NODE)],
            youngs_modulus, poissons_ratio, plane_type,
        )
        for conn in connectivity
    ])
    strains = np.array([
        _element_strain(
            element_type, node_xy[conn],
            displacements[element_dofs(conn, DOFS_PER_NODE)],
        )
        for conn in connectivity
    ])
    return {
        "displacements": displacements,
        "reactions": reactions,
        "stresses": stresses,
        "strains": strains,
    }


def solve_plate_cst(
    nodes: Sequence[Sequence[float]],
    elements: Sequence[Sequence[int]],
    loads: Mapping[int, Sequence[float]],
    supports: Mapping[int, Sequence[bool]],
    youngs_modulus: float = STEEL_E_PA,
    poissons_ratio: float = STEEL_NU,
    thickness: Union[Number, Sequence[float]] = DEFAULT_THICKNESS_M,
    plane_type: str = PLANE_STRESS,
) -> Dict[str, np.ndarray]:
    """
    Solve a plate meshed with constant strain triangles.

    Parameters
    ----------
    nodes : array_like, shape (n_nodes, 2)
        Node coordinates (x, y) [m].
    elements : array_like of int, shape (n_elements, 3)
        Zero-based node numbers of each triangle, counter-clockwise.
    loads : mapping of int to (float, float)
        Node index -> applied force (Fx, Fy) [N].
    supports : mapping of int to (bool, bool)
        Node index -> (fix_x, fix_y); True constrains that DOF.
    youngs_modulus : float, default STEEL_E_PA
        Young's modulus [Pa], must be positive.
    poissons_ratio : float, default STEEL_NU
        Poisson's ratio (dimensionless), 0 <= nu < 0.5.
    thickness : float or array_like, default DEFAULT_THICKNESS_M
        Plate thickness [m]; a scalar applies to every element, an array has
        one positive entry per element.
    plane_type : str, default PLANE_STRESS
        ``"plane_stress"`` or ``"plane_strain"``.

    Returns
    -------
    dict
        ``"displacements"`` : numpy.ndarray, shape (2 n_nodes,) [m], (u, v)
        per node. ``"reactions"`` : numpy.ndarray, shape (2 n_nodes,) [N].
        ``"stresses"`` : numpy.ndarray, shape (n_elements, 3) [Pa].
        ``"strains"`` : numpy.ndarray, shape (n_elements, 3) [-].

    Raises
    ------
    ValueError
        If an input has the wrong shape or is out of range, or the model is
        unstable (insufficient supports).

    Notes
    -----
    Loads are applied as nodal forces. Stresses and strains are constant per
    element (the centroid values).
    """
    return _solve_plane(
        ELEMENT_CST, nodes, elements, loads, supports,
        youngs_modulus, poissons_ratio, thickness, plane_type,
    )


def solve_plate_q4(
    nodes: Sequence[Sequence[float]],
    elements: Sequence[Sequence[int]],
    loads: Mapping[int, Sequence[float]],
    supports: Mapping[int, Sequence[bool]],
    youngs_modulus: float = STEEL_E_PA,
    poissons_ratio: float = STEEL_NU,
    thickness: Union[Number, Sequence[float]] = DEFAULT_THICKNESS_M,
    plane_type: str = PLANE_STRESS,
) -> Dict[str, np.ndarray]:
    """
    Solve a plate meshed with 4-node bilinear quadrilaterals.

    Parameters
    ----------
    nodes : array_like, shape (n_nodes, 2)
        Node coordinates (x, y) [m].
    elements : array_like of int, shape (n_elements, 4)
        Zero-based node numbers of each quadrilateral, counter-clockwise.
    loads : mapping of int to (float, float)
        Node index -> applied force (Fx, Fy) [N].
    supports : mapping of int to (bool, bool)
        Node index -> (fix_x, fix_y); True constrains that DOF.
    youngs_modulus : float, default STEEL_E_PA
        Young's modulus [Pa], must be positive.
    poissons_ratio : float, default STEEL_NU
        Poisson's ratio (dimensionless), 0 <= nu < 0.5.
    thickness : float or array_like, default DEFAULT_THICKNESS_M
        Plate thickness [m]; a scalar applies to every element, an array has
        one positive entry per element.
    plane_type : str, default PLANE_STRESS
        ``"plane_stress"`` or ``"plane_strain"``.

    Returns
    -------
    dict
        ``"displacements"`` : numpy.ndarray, shape (2 n_nodes,) [m], (u, v)
        per node. ``"reactions"`` : numpy.ndarray, shape (2 n_nodes,) [N].
        ``"stresses"`` : numpy.ndarray, shape (n_elements, 3) [Pa].
        ``"strains"`` : numpy.ndarray, shape (n_elements, 3) [-].

    Raises
    ------
    ValueError
        If an input has the wrong shape or is out of range, or the model is
        unstable (insufficient supports).

    Notes
    -----
    Loads are applied as nodal forces. Stresses and strains are evaluated at
    the element centre.
    """
    return _solve_plane(
        ELEMENT_Q4, nodes, elements, loads, supports,
        youngs_modulus, poissons_ratio, thickness, plane_type,
    )


def solve_plate_cst_thermal(
    nodes: Sequence[Sequence[float]],
    elements: Sequence[Sequence[int]],
    supports: Mapping[int, Sequence[bool]],
    alpha: float = STEEL_ALPHA_PER_K,
    delta_t: float = DEFAULT_DELTA_T_K,
    youngs_modulus: float = STEEL_E_PA,
    poissons_ratio: float = STEEL_NU,
    thickness: float = DEFAULT_THICKNESS_M,
    plane_type: str = PLANE_STRESS,
) -> Dict[str, np.ndarray]:
    """
    Solve a CST plate under a uniform temperature change.

    Parameters
    ----------
    nodes : array_like, shape (n_nodes, 2)
        Node coordinates (x, y) [m].
    elements : array_like of int, shape (n_elements, 3)
        Zero-based node numbers of each triangle, counter-clockwise.
    supports : mapping of int to (bool, bool)
        Node index -> (fix_x, fix_y); True constrains that DOF.
    alpha : float, default STEEL_ALPHA_PER_K
        Coefficient of thermal expansion [1/K], must be positive.
    delta_t : float, default DEFAULT_DELTA_T_K
        Uniform temperature change [K]; positive is heating.
    youngs_modulus : float, default STEEL_E_PA
        Young's modulus [Pa], must be positive.
    poissons_ratio : float, default STEEL_NU
        Poisson's ratio (dimensionless), 0 <= nu < 0.5.
    thickness : float, default DEFAULT_THICKNESS_M
        Plate thickness [m], must be positive.
    plane_type : str, default PLANE_STRESS
        ``"plane_stress"`` or ``"plane_strain"``.

    Returns
    -------
    dict
        ``"displacements"`` : numpy.ndarray, shape (2 n_nodes,) [m].
        ``"reactions"`` : numpy.ndarray, shape (2 n_nodes,) [N].
        ``"stresses"`` : numpy.ndarray, shape (n_elements, 3) [Pa], the
        mechanical stress ``D (B u - eps_th)``.

    Raises
    ------
    ValueError
        If an input is invalid or the model is unstable.

    Notes
    -----
    A free plate expands by u = alpha dT x, v = alpha dT y with zero stress.
    With every boundary node fixed in plane stress the stress is
    -E alpha dT / (1 - nu) in both directions; in plane strain it is
    -E alpha dT / (1 - 2 nu).
    """
    _require_positive("thickness", thickness)
    _require_positive("alpha", alpha)
    node_xy = np.asarray(nodes, dtype=float)
    if node_xy.ndim != 2 or node_xy.shape[1] != 2:
        raise ValueError(f"nodes must have shape (n_nodes, 2), got {node_xy.shape}")
    n_nodes = node_xy.shape[0]
    connectivity = np.asarray(elements, dtype=int)
    if connectivity.ndim != 2 or connectivity.shape[1] != CST_NODES:
        raise ValueError(
            f"elements must have shape (n_elements, {CST_NODES}), got {connectivity.shape}"
        )
    if np.any(connectivity < 0) or np.any(connectivity >= n_nodes):
        raise ValueError(f"elements reference a node outside 0..{n_nodes - 1}")

    stiffness, load = init_global_system(n_nodes, DOFS_PER_NODE)
    for conn in connectivity:
        coords = node_xy[conn]
        dofs = element_dofs(conn, DOFS_PER_NODE)
        assemble_global(stiffness, element_stiffness_cst(
            coords, youngs_modulus, poissons_ratio, thickness, plane_type), dofs)
        assemble_global_vector(load, element_thermal_load_cst(
            coords, youngs_modulus, poissons_ratio, thickness, alpha, delta_t,
            plane_type), dofs)

    displacements, reactions = solve_system(
        stiffness, load, _fixed_dofs(supports, n_nodes)
    )

    d_matrix = constitutive_matrix(youngs_modulus, poissons_ratio, plane_type)
    thermal_strain = _thermal_strain(poissons_ratio, alpha, delta_t, plane_type)
    stresses = np.array([
        d_matrix @ (cst_B_matrix(node_xy[conn])[0]
                    @ displacements[element_dofs(conn, DOFS_PER_NODE)]
                    - thermal_strain)
        for conn in connectivity
    ])
    return {"displacements": displacements, "reactions": reactions, "stresses": stresses}


# ---------------------------------------------------------------------------
# Meshing and loads
# ---------------------------------------------------------------------------

def _grid_nodes(width: float, height: float, nx: int, ny: int) -> np.ndarray:
    """Row-major grid of (nx + 1)(ny + 1) nodes; x varies fastest."""
    xs = np.linspace(0.0, width, nx + 1)
    ys = np.linspace(0.0, height, ny + 1)
    return np.array([[x, y] for y in ys for x in xs])


def generate_rect_mesh_q4(
    width: float, height: float, nx: int, ny: int
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Structured Q4 mesh of a rectangle with its lower-left corner at the origin.

    Parameters
    ----------
    width : float
        Extent in x [m], must be positive.
    height : float
        Extent in y [m], must be positive.
    nx, ny : int
        Number of elements in x and y (dimensionless), each >= 1.

    Returns
    -------
    nodes : numpy.ndarray, shape ((nx + 1)(ny + 1), 2)
        Node coordinates (x, y) [m]; node ``j (nx + 1) + i`` sits at column
        i, row j.
    elements : numpy.ndarray of int, shape (nx ny, 4)
        Counter-clockwise node numbers of each quadrilateral, ordered with
        the x index varying fastest.

    Raises
    ------
    ValueError
        If a dimension is not positive or a division count is invalid.

    Notes
    -----
    The element in column i, row j has nodes
    ``[n, n + 1, n + nx + 2, n + nx + 1]`` with ``n = j (nx + 1) + i``.
    """
    _require_positive("width", width)
    _require_positive("height", height)
    _require_positive_int("nx", nx)
    _require_positive_int("ny", ny)
    nodes = _grid_nodes(width, height, nx, ny)
    elements = []
    for j in range(ny):
        for i in range(nx):
            n0 = j * (nx + 1) + i
            elements.append([n0, n0 + 1, n0 + nx + 2, n0 + nx + 1])
    return nodes, np.array(elements, dtype=int)


def generate_rect_mesh_cst(
    width: float, height: float, nx: int, ny: int
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Structured triangle mesh of a rectangle with its lower-left corner at the origin.

    Parameters
    ----------
    width : float
        Extent in x [m], must be positive.
    height : float
        Extent in y [m], must be positive.
    nx, ny : int
        Number of rectangular cells in x and y (dimensionless), each >= 1.

    Returns
    -------
    nodes : numpy.ndarray, shape ((nx + 1)(ny + 1), 2)
        Node coordinates (x, y) [m], numbered as in ``generate_rect_mesh_q4``.
    elements : numpy.ndarray of int, shape (2 nx ny, 3)
        Counter-clockwise node numbers of each triangle; every cell yields
        two triangles.

    Raises
    ------
    ValueError
        If a dimension is not positive or a division count is invalid.

    Notes
    -----
    Cell nodes ``[n0, n1, n2, n3]`` are split along the n0-n2 diagonal into
    ``[n0, n1, n2]`` and ``[n0, n2, n3]``.
    """
    _require_positive("width", width)
    _require_positive("height", height)
    _require_positive_int("nx", nx)
    _require_positive_int("ny", ny)
    nodes = _grid_nodes(width, height, nx, ny)
    elements = []
    for j in range(ny):
        for i in range(nx):
            n0 = j * (nx + 1) + i
            n1, n2, n3 = n0 + 1, n0 + nx + 2, n0 + nx + 1
            elements.append([n0, n1, n2])
            elements.append([n0, n2, n3])
    return nodes, np.array(elements, dtype=int)


def edge_traction_loads(
    nodes: Sequence[Sequence[float]],
    edge_nodes: Sequence[int],
    traction: Sequence[float],
    thickness: float = DEFAULT_THICKNESS_M,
) -> Dict[int, Tuple[float, float]]:
    """
    Consistent nodal forces for a uniform traction on a polyline edge.

    Parameters
    ----------
    nodes : array_like, shape (n_nodes, 2)
        Node coordinates (x, y) [m].
    edge_nodes : sequence of int
        Node numbers along the loaded edge, in order; at least two.
    traction : (float, float)
        Uniform traction (tx, ty) [Pa] in global axes; positive in the
        positive axis direction.
    thickness : float, default DEFAULT_THICKNESS_M
        Plate thickness [m], must be positive.

    Returns
    -------
    dict of int to (float, float)
        Node number -> nodal force (Fx, Fy) [N].

    Raises
    ------
    ValueError
        If fewer than two edge nodes are given, an index is out of range, or
        ``thickness`` is not positive.

    Notes
    -----
    Each segment of length L contributes t L (tx, ty) / 2 to each of its two
    end nodes, so the total force equals traction x thickness x edge length.
    """
    _require_positive("thickness", thickness)
    node_xy = np.asarray(nodes, dtype=float)
    if node_xy.ndim != 2 or node_xy.shape[1] != 2:
        raise ValueError(f"nodes must have shape (n_nodes, 2), got {node_xy.shape}")
    edge = [int(n) for n in edge_nodes]
    if len(edge) < 2:
        raise ValueError(f"edge_nodes needs at least two nodes, got {len(edge)}")
    if any(not 0 <= n < node_xy.shape[0] for n in edge):
        raise ValueError(f"edge_nodes reference a node outside 0..{node_xy.shape[0] - 1}")

    traction_vec = np.asarray(traction, dtype=float)
    forces: Dict[int, Tuple[float, float]] = {}
    for start, end in zip(edge[:-1], edge[1:]):
        segment_length = float(np.linalg.norm(node_xy[end] - node_xy[start]))
        segment_force = 0.5 * thickness * segment_length * traction_vec
        for node in (start, end):
            fx, fy = forces.get(node, (0.0, 0.0))
            forces[node] = (fx + float(segment_force[0]), fy + float(segment_force[1]))
    return forces


# ---------------------------------------------------------------------------
# Stress measures
# ---------------------------------------------------------------------------

def von_mises_plane_stress(stress: np.ndarray) -> np.ndarray:
    """
    Von Mises equivalent stress for plane stress states.

    Parameters
    ----------
    stress : array_like, shape (3,) or (n, 3)
        ``[sigma_x, sigma_y, tau_xy]`` [Pa].

    Returns
    -------
    numpy.ndarray
        Equivalent stress [Pa], shape () for one state or (n,) for many.

    Raises
    ------
    ValueError
        If the last axis of ``stress`` does not have length 3.

    Notes
    -----
    sigma_vm = sqrt(sigma_x^2 - sigma_x sigma_y + sigma_y^2 + 3 tau_xy^2).
    """
    stress_arr = np.asarray(stress, dtype=float)
    if stress_arr.shape[-1:] != (3,):
        raise ValueError(f"stress must have last dimension 3, got shape {stress_arr.shape}")
    sx, sy, txy = stress_arr[..., 0], stress_arr[..., 1], stress_arr[..., 2]
    return np.sqrt(sx ** 2 - sx * sy + sy ** 2 + 3.0 * txy ** 2)


def principal_stresses_2d(
    stress: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    In-plane principal stresses and principal direction.

    Parameters
    ----------
    stress : array_like, shape (3,) or (n, 3)
        ``[sigma_x, sigma_y, tau_xy]`` [Pa].

    Returns
    -------
    sigma_1 : numpy.ndarray
        Larger principal stress [Pa].
    sigma_2 : numpy.ndarray
        Smaller principal stress [Pa].
    theta_p : numpy.ndarray
        Angle [rad] from the x axis to the sigma_1 direction.

    Raises
    ------
    ValueError
        If the last axis of ``stress`` does not have length 3.

    Notes
    -----
    sigma_{1,2} = (sigma_x + sigma_y)/2 +/- sqrt(((sigma_x - sigma_y)/2)^2 +
    tau_xy^2) and theta_p = 0.5 atan2(2 tau_xy, sigma_x - sigma_y).
    """
    stress_arr = np.asarray(stress, dtype=float)
    if stress_arr.shape[-1:] != (3,):
        raise ValueError(f"stress must have last dimension 3, got shape {stress_arr.shape}")
    sx, sy, txy = stress_arr[..., 0], stress_arr[..., 1], stress_arr[..., 2]
    centre = 0.5 * (sx + sy)
    radius = np.hypot(0.5 * (sx - sy), txy)
    return centre + radius, centre - radius, 0.5 * np.arctan2(2.0 * txy, sx - sy)
