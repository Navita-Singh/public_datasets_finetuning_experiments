"""
forces.py -- Force and moment helpers for rigid-body statics.

Resultants of force systems, moments about a point, equivalent force-couple
systems, resultants of distributed loads, cable tensions, friction on an
incline and in-plane bolt-group shear. Plain NumPy: this module is independent
of the finite element solvers (fea_1d.py, fea_2d.py) and of utils.py. All
quantities are SI (m, N, N*m, kg, rad); see Skills/fea_skills.md.

Conventions
-----------
* x to the right, y up. Angles are in radians, measured counter-clockwise
  from the +x axis unless a function states otherwise.
* Forces are signed components: positive in the +axis direction.
* Moments are counter-clockwise positive.
"""

from __future__ import annotations

from typing import Dict, Sequence, Tuple, Union

import numpy as np

# ---------------------------------------------------------------------------
# Named constants (SI)
# ---------------------------------------------------------------------------

GRAVITY_M_S2 = 9.81
PLANE_DIMENSIONS = 2
SPACE_DIMENSIONS = 3
MIN_BOLTS = 2
QUARTER_TURN_RAD = np.pi / 2.0

Number = Union[float, int]


# ---------------------------------------------------------------------------
# Input validation helpers
# ---------------------------------------------------------------------------

def _require_positive(name: str, value: float) -> None:
    """Raise ValueError unless ``value`` is a positive number."""
    if not value > 0.0:
        raise ValueError(f"{name} must be positive, got {value}")


def _require_non_negative(name: str, value: float) -> None:
    """Raise ValueError unless ``value`` is zero or positive."""
    if not value >= 0.0:
        raise ValueError(f"{name} must be non-negative, got {value}")


def _require_acute_angle(name: str, value: float) -> None:
    """Raise ValueError unless 0 <= value < pi/2 radians."""
    if not 0.0 <= value < QUARTER_TURN_RAD:
        raise ValueError(f"{name} must satisfy 0 <= {name} < pi/2 rad, got {value}")


def _require_kinetic_not_above_static(mu_static: float, mu_kinetic: float) -> None:
    """Raise ValueError if the kinetic friction coefficient exceeds the static one."""
    if mu_kinetic > mu_static:
        raise ValueError(
            f"mu_kinetic must not exceed mu_static, got {mu_kinetic} > {mu_static}"
        )


def _as_array(name: str, value: Sequence, shape: Tuple[int, ...]) -> np.ndarray:
    """Convert to a float array and check its shape."""
    arr = np.asarray(value, dtype=float)
    if arr.shape != shape:
        raise ValueError(f"{name} must have shape {shape}, got {arr.shape}")
    return arr


def _as_vectors(name: str, value: Sequence, dims: int) -> np.ndarray:
    """Convert to an (n, dims) float array with n >= 1."""
    arr = np.asarray(value, dtype=float)
    if arr.ndim != 2 or arr.shape[1] != dims or arr.shape[0] < 1:
        raise ValueError(f"{name} must have shape (n, {dims}) with n >= 1, got {arr.shape}")
    return arr


# ---------------------------------------------------------------------------
# Force systems and moments
# ---------------------------------------------------------------------------

def force_from_polar(magnitude: float, angle_rad: float) -> np.ndarray:
    """
    Components of a planar force given its magnitude and direction.

    Parameters
    ----------
    magnitude : float
        Force magnitude [N], must be non-negative.
    angle_rad : float
        Direction of the force [rad], counter-clockwise from the +x axis.

    Returns
    -------
    numpy.ndarray, shape (2,)
        ``[Fx, Fy]`` [N].

    Raises
    ------
    ValueError
        If ``magnitude`` is negative.

    Notes
    -----
    Fx = F cos(theta), Fy = F sin(theta).
    """
    _require_non_negative("magnitude", magnitude)
    return magnitude * np.array([np.cos(angle_rad), np.sin(angle_rad)])


def resultant_2d(forces: Sequence[Sequence[float]]) -> Dict[str, Union[float, np.ndarray]]:
    """
    Resultant of a planar system of forces.

    Parameters
    ----------
    forces : array_like, shape (n, 2)
        Force components ``[Fx, Fy]`` [N], one row per force.

    Returns
    -------
    dict
        ``"force"`` : numpy.ndarray, shape (2,), the vector sum [N].
        ``"magnitude"`` : float [N].
        ``"angle_rad"`` : float [rad], direction counter-clockwise from +x
        (0 for a zero resultant).

    Raises
    ------
    ValueError
        If ``forces`` does not have shape (n, 2) with n >= 1.

    Notes
    -----
    R = sum F_i; the angle is atan2(Ry, Rx).
    """
    force_arr = _as_vectors("forces", forces, PLANE_DIMENSIONS)
    total = force_arr.sum(axis=0)
    return {
        "force": total,
        "magnitude": float(np.hypot(total[0], total[1])),
        "angle_rad": float(np.arctan2(total[1], total[0])),
    }


def moment_about_point_2d(
    force: Sequence[float],
    application_point: Sequence[float],
    reference_point: Sequence[float] = (0.0, 0.0),
) -> float:
    """
    Moment of a planar force about a reference point.

    Parameters
    ----------
    force : array_like, shape (2,)
        Force components ``[Fx, Fy]`` [N].
    application_point : array_like, shape (2,)
        Point of application (x, y) [m].
    reference_point : array_like, shape (2,), default (0, 0)
        Point about which the moment is taken (x, y) [m].

    Returns
    -------
    float
        Moment [N*m], counter-clockwise positive.

    Raises
    ------
    ValueError
        If an argument does not have shape (2,).

    Notes
    -----
    M = rx Fy - ry Fx with r = application_point - reference_point.
    """
    force_vec = _as_array("force", force, (PLANE_DIMENSIONS,))
    arm = (_as_array("application_point", application_point, (PLANE_DIMENSIONS,))
           - _as_array("reference_point", reference_point, (PLANE_DIMENSIONS,)))
    return float(arm[0] * force_vec[1] - arm[1] * force_vec[0])


def moment_about_point_3d(
    force: Sequence[float],
    application_point: Sequence[float],
    reference_point: Sequence[float] = (0.0, 0.0, 0.0),
) -> np.ndarray:
    """
    Moment vector of a force in space about a reference point.

    Parameters
    ----------
    force : array_like, shape (3,)
        Force components ``[Fx, Fy, Fz]`` [N].
    application_point : array_like, shape (3,)
        Point of application (x, y, z) [m].
    reference_point : array_like, shape (3,), default (0, 0, 0)
        Point about which the moment is taken [m].

    Returns
    -------
    numpy.ndarray, shape (3,)
        Moment vector [N*m], right-hand rule.

    Raises
    ------
    ValueError
        If an argument does not have shape (3,).

    Notes
    -----
    M = r x F with r = application_point - reference_point.
    """
    force_vec = _as_array("force", force, (SPACE_DIMENSIONS,))
    arm = (_as_array("application_point", application_point, (SPACE_DIMENSIONS,))
           - _as_array("reference_point", reference_point, (SPACE_DIMENSIONS,)))
    return np.cross(arm, force_vec)


def equivalent_force_couple_2d(
    forces: Sequence[Sequence[float]],
    points: Sequence[Sequence[float]],
    reference_point: Sequence[float] = (0.0, 0.0),
) -> Dict[str, Union[float, np.ndarray]]:
    """
    Equivalent force-couple system of planar forces at a reference point.

    Parameters
    ----------
    forces : array_like, shape (n, 2)
        Force components ``[Fx, Fy]`` [N].
    points : array_like, shape (n, 2)
        Points of application (x, y) [m], one per force.
    reference_point : array_like, shape (2,), default (0, 0)
        Point to which the system is reduced [m].

    Returns
    -------
    dict
        ``"force"`` : numpy.ndarray, shape (2,), the resultant [N].
        ``"moment"`` : float, the couple about the reference point [N*m],
        counter-clockwise positive.

    Raises
    ------
    ValueError
        If the arrays have inconsistent shapes.

    Notes
    -----
    The resultant is sum F_i and the couple is sum (r_i x F_i).
    """
    force_arr = _as_vectors("forces", forces, PLANE_DIMENSIONS)
    point_arr = _as_vectors("points", points, PLANE_DIMENSIONS)
    if force_arr.shape != point_arr.shape:
        raise ValueError(
            f"forces and points must have the same shape, got {force_arr.shape} "
            f"and {point_arr.shape}"
        )
    moment = sum(
        moment_about_point_2d(f, p, reference_point)
        for f, p in zip(force_arr, point_arr)
    )
    return {"force": force_arr.sum(axis=0), "moment": float(moment)}


# ---------------------------------------------------------------------------
# Distributed loads
# ---------------------------------------------------------------------------

def trapezoid_load_resultant(
    length: float, w_start: float, w_end: float
) -> Tuple[float, float]:
    """
    Resultant of a linearly varying (trapezoidal) distributed load.

    Parameters
    ----------
    length : float
        Loaded length [m], must be positive.
    w_start : float
        Load intensity at the start [N/m].
    w_end : float
        Load intensity at the end [N/m].

    Returns
    -------
    resultant : float
        Total force [N], with the sign of the load.
    x_bar : float
        Distance of the line of action from the start [m].

    Raises
    ------
    ValueError
        If ``length`` is not positive, or if ``w_start + w_end`` is zero
        (the load is a pure couple and has no single line of action).

    Notes
    -----
    R = L (w1 + w2) / 2 and x_bar = L (w1 + 2 w2) / (3 (w1 + w2)). A uniform
    load gives x_bar = L/2; a triangle growing from zero gives 2L/3.
    """
    _require_positive("length", length)
    intensity_sum = w_start + w_end
    if intensity_sum == 0.0:
        raise ValueError(
            "w_start + w_end must be non-zero; the load has no single line of action"
        )
    resultant = length * intensity_sum / 2.0
    x_bar = length * (w_start + 2.0 * w_end) / (3.0 * intensity_sum)
    return float(resultant), float(x_bar)


# ---------------------------------------------------------------------------
# Particle equilibrium and friction
# ---------------------------------------------------------------------------

def cable_tensions_2d(
    weight: float, left_angle_rad: float, right_angle_rad: float
) -> Tuple[float, float]:
    """
    Tensions in two cables supporting a hanging weight.

    Parameters
    ----------
    weight : float
        Weight carried at the joint [N], must be positive.
    left_angle_rad : float
        Angle of the left cable above the horizontal [rad], 0 < angle < pi/2.
    right_angle_rad : float
        Angle of the right cable above the horizontal [rad], 0 < angle < pi/2.

    Returns
    -------
    left_tension : float
        Tension in the left cable [N].
    right_tension : float
        Tension in the right cable [N].

    Raises
    ------
    ValueError
        If ``weight`` is not positive or an angle is outside (0, pi/2).

    Notes
    -----
    Horizontal balance T1 cos(a1) = T2 cos(a2) and vertical balance
    T1 sin(a1) + T2 sin(a2) = W give T1 = W cos(a2) / sin(a1 + a2) and
    T2 = W cos(a1) / sin(a1 + a2).
    """
    _require_positive("weight", weight)
    if not 0.0 < left_angle_rad < QUARTER_TURN_RAD:
        raise ValueError(f"left_angle_rad must lie in (0, pi/2), got {left_angle_rad}")
    if not 0.0 < right_angle_rad < QUARTER_TURN_RAD:
        raise ValueError(f"right_angle_rad must lie in (0, pi/2), got {right_angle_rad}")
    denominator = np.sin(left_angle_rad + right_angle_rad)
    left_tension = weight * np.cos(right_angle_rad) / denominator
    right_tension = weight * np.cos(left_angle_rad) / denominator
    return float(left_tension), float(right_tension)


def block_on_incline(
    mass: float,
    angle_rad: float,
    mu_static: float,
    mu_kinetic: float,
    applied_force: float = 0.0,
    gravity: float = GRAVITY_M_S2,
) -> Dict[str, Union[float, bool]]:
    """
    State of a block on a rough incline, optionally pushed along the slope.

    Parameters
    ----------
    mass : float
        Block mass [kg], must be positive.
    angle_rad : float
        Incline angle above the horizontal [rad], 0 <= angle < pi/2.
    mu_static : float
        Coefficient of static friction (dimensionless), must be non-negative.
    mu_kinetic : float
        Coefficient of kinetic friction (dimensionless), non-negative and not
        larger than ``mu_static``.
    applied_force : float, default 0.0
        Force applied parallel to the slope [N]; positive pushes up the slope.
    gravity : float, default GRAVITY_M_S2
        Gravitational acceleration [m/s^2], must be positive.

    Returns
    -------
    dict
        ``"normal_force"`` : float [N].
        ``"friction_force"`` : float [N], positive when it acts up the slope;
        the value needed for equilibrium if the block is at rest, otherwise
        the kinetic friction force.
        ``"slipping"`` : bool.
        ``"acceleration"`` : float [m/s^2] along the slope, positive down the
        slope (0 if the block is at rest).

    Raises
    ------
    ValueError
        If an argument is outside its allowed range.

    Notes
    -----
    Normal force N = W cos(theta); net driving force down the slope
    s = W sin(theta) - F_applied. The block stays at rest if |s| <= mu_static N,
    with friction equal to s. Otherwise it slides with friction
    sign(s) mu_kinetic N and acceleration (s - sign(s) mu_kinetic N) / m.
    """
    _require_positive("mass", mass)
    _require_acute_angle("angle_rad", angle_rad)
    _require_non_negative("mu_static", mu_static)
    _require_non_negative("mu_kinetic", mu_kinetic)
    _require_kinetic_not_above_static(mu_static, mu_kinetic)
    _require_positive("gravity", gravity)

    weight_force = mass * gravity
    normal_force = weight_force * np.cos(angle_rad)
    driving_force = weight_force * np.sin(angle_rad) - applied_force

    if abs(driving_force) <= mu_static * normal_force:
        return {
            "normal_force": float(normal_force),
            "friction_force": float(driving_force),
            "slipping": False,
            "acceleration": 0.0,
        }
    kinetic_friction = np.sign(driving_force) * mu_kinetic * normal_force
    return {
        "normal_force": float(normal_force),
        "friction_force": float(kinetic_friction),
        "slipping": True,
        "acceleration": float((driving_force - kinetic_friction) / mass),
    }


# ---------------------------------------------------------------------------
# Bolt groups
# ---------------------------------------------------------------------------

def bolt_group_shear(
    bolt_positions: Sequence[Sequence[float]],
    load: Sequence[float],
    load_position: Sequence[float],
) -> Dict[str, Union[float, np.ndarray]]:
    """
    In-plane shear forces in a group of identical bolts under an eccentric load.

    Parameters
    ----------
    bolt_positions : array_like, shape (n, 2)
        Bolt centres (x, y) [m], n >= 2, all bolts identical.
    load : array_like, shape (2,)
        Applied force ``[Fx, Fy]`` [N].
    load_position : array_like, shape (2,)
        Point of application of the load (x, y) [m].

    Returns
    -------
    dict
        ``"forces"`` : numpy.ndarray, shape (n, 2), force ``[Fx, Fy]`` on each
        bolt [N]. ``"magnitudes"`` : numpy.ndarray, shape (n,) [N].
        ``"centroid"`` : numpy.ndarray, shape (2,) [m].
        ``"moment"`` : float, moment of the load about the centroid [N*m],
        counter-clockwise positive. ``"polar_moment"`` : float, sum of squared
        bolt distances from the centroid [m^2].

    Raises
    ------
    ValueError
        If fewer than two bolts are given, the bolts coincide at one point,
        or an argument has the wrong shape.

    Notes
    -----
    Elastic method. Each bolt carries the direct share P / n plus a torsional
    force of magnitude M r_i / J, perpendicular to its radius vector r_i from
    the centroid, with J = sum |r_i|^2: F_torsion,i = (M / J) (-r_iy, r_ix).
    The bolt forces sum to the load and their moment about the centroid
    equals M.
    """
    bolts = np.asarray(bolt_positions, dtype=float)
    if bolts.ndim != 2 or bolts.shape[1] != PLANE_DIMENSIONS or bolts.shape[0] < MIN_BOLTS:
        raise ValueError(
            f"bolt_positions must have shape (n, 2) with n >= {MIN_BOLTS}, got {bolts.shape}"
        )
    load_vec = _as_array("load", load, (PLANE_DIMENSIONS,))
    load_point = _as_array("load_position", load_position, (PLANE_DIMENSIONS,))

    centroid = bolts.mean(axis=0)
    radii = bolts - centroid
    polar_moment = float(np.sum(radii ** 2))
    if polar_moment <= 0.0:
        raise ValueError("bolt_positions must not all coincide at one point")

    moment = moment_about_point_2d(load_vec, load_point, centroid)
    direct = load_vec / bolts.shape[0]
    torsional = (moment / polar_moment) * np.column_stack((-radii[:, 1], radii[:, 0]))
    forces = direct + torsional
    return {
        "forces": forces,
        "magnitudes": np.hypot(forces[:, 0], forces[:, 1]),
        "centroid": centroid,
        "moment": float(moment),
        "polar_moment": polar_moment,
    }
