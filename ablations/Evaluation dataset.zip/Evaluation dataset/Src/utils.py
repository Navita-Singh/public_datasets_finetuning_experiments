"""
utils.py -- Shared finite element utilities.

PROTECTED FILE. Do not edit. Solver modules (fea_1d.py, fea_2d.py,
forces.py) import from here; they must not copy, shadow or patch these
functions.

Contents
--------
1. Quadrature            gauss_points_1d, gauss_points_2d
2. Global assembly       element_dofs, init_global_system, assemble_global,
                         assemble_global_vector
3. Boundary conditions   apply_dirichlet_bc, solve_system
4. Shape functions       bar_*, beam_* (Hermite), cst_*, q4_*
5. Geometry helpers      bar_direction_cosines, truss_transformation_matrix

Conventions
-----------
* SI units throughout (m, N, Pa). This module is unit-agnostic, but all
  callers must pass consistent SI values.
* DOF ordering is node-major: the DOFs of node ``n`` with ``d`` DOFs per
  node are ``n*d, n*d + 1, ..., n*d + d - 1``. For a 2D solid the order
  per node is (u, v); for a beam it is (w, theta).
* Node numbering and DOF indices are zero-based.
* Quadrilateral and triangular elements list nodes counter-clockwise.
* Only NumPy is used.
"""

from __future__ import annotations

from typing import Optional, Sequence, Tuple

import numpy as np

__all__ = [
    "gauss_points_1d",
    "gauss_points_2d",
    "element_dofs",
    "init_global_system",
    "assemble_global",
    "assemble_global_vector",
    "apply_dirichlet_bc",
    "solve_system",
    "bar_shape_functions",
    "bar_B_matrix",
    "beam_shape_functions",
    "beam_shape_second_derivatives",
    "cst_shape_functions",
    "cst_B_matrix",
    "q4_shape_functions",
    "q4_shape_derivatives",
    "q4_jacobian",
    "q4_B_matrix",
    "bar_direction_cosines",
    "truss_transformation_matrix",
]

# ---------------------------------------------------------------------------
# Named constants
# ---------------------------------------------------------------------------

# Elements whose length is below this value [m] are treated as zero length.
_MIN_ELEMENT_LENGTH_M = 1.0e-12

# Triangle / quadrilateral area (or Jacobian determinant) must exceed this
# fraction of the squared characteristic element size to be accepted.
_MIN_RELATIVE_AREA = 1.0e-12

# A constrained stiffness matrix whose condition number exceeds 1/eps is
# numerically singular (typically a missing support / rigid-body mode).
_MAX_CONDITION_NUMBER = 1.0 / np.finfo(float).eps

_DOFS_PER_NODE_2D_SOLID = 2  # (u, v) per node for CST and Q4 elements


# ---------------------------------------------------------------------------
# 1. Quadrature
# ---------------------------------------------------------------------------

def gauss_points_1d(n_points: int = 2) -> Tuple[np.ndarray, np.ndarray]:
    """
    Gauss-Legendre points and weights on the interval [-1, 1].

    Parameters
    ----------
    n_points : int, default 2
        Number of integration points (dimensionless), must be >= 1.

    Returns
    -------
    points : numpy.ndarray, shape (n_points,)
        Abscissae in natural coordinates, ascending order.
    weights : numpy.ndarray, shape (n_points,)
        Corresponding weights; they sum to 2.

    Notes
    -----
    An n-point rule integrates polynomials up to degree 2n - 1 exactly.
    """
    if not isinstance(n_points, (int, np.integer)) or n_points < 1:
        raise ValueError(f"n_points must be an integer >= 1, got {n_points!r}")
    points, weights = np.polynomial.legendre.leggauss(int(n_points))
    return points, weights


def gauss_points_2d(n_points: int = 2) -> Tuple[np.ndarray, np.ndarray]:
    """
    Tensor-product Gauss-Legendre rule on the square [-1, 1] x [-1, 1].

    Parameters
    ----------
    n_points : int, default 2
        Number of points per direction (dimensionless), must be >= 1.

    Returns
    -------
    points : numpy.ndarray, shape (n_points**2, 2)
        Columns are (xi, eta). The xi index varies slowest.
    weights : numpy.ndarray, shape (n_points**2,)
        Products of the 1D weights; they sum to 4.
    """
    pts_1d, w_1d = gauss_points_1d(n_points)
    points = np.array([[xi, eta] for xi in pts_1d for eta in pts_1d])
    weights = np.array([wi * wj for wi in w_1d for wj in w_1d])
    return points, weights


# ---------------------------------------------------------------------------
# 2. Global assembly
# ---------------------------------------------------------------------------

def element_dofs(node_ids: Sequence[int], dofs_per_node: int = 1) -> np.ndarray:
    """
    Global DOF indices of an element, in node-major order.

    Parameters
    ----------
    node_ids : sequence of int
        Zero-based global node numbers of the element, in element-local
        node order.
    dofs_per_node : int, default 1
        Number of DOFs carried by each node (dimensionless).

    Returns
    -------
    numpy.ndarray of int, shape (len(node_ids) * dofs_per_node,)
        For node ``n`` the entries ``n*d ... n*d + d - 1`` appear in the
        position of that node in ``node_ids``.

    Notes
    -----
    Example: ``element_dofs([2, 5], 2)`` returns ``[4, 5, 10, 11]``.
    """
    if dofs_per_node < 1:
        raise ValueError(f"dofs_per_node must be >= 1, got {dofs_per_node}")
    nodes = np.asarray(node_ids, dtype=int)
    if nodes.ndim != 1 or nodes.size == 0:
        raise ValueError("node_ids must be a non-empty 1D sequence")
    if np.any(nodes < 0):
        raise ValueError(f"node_ids must be non-negative, got {nodes.tolist()}")
    if len(np.unique(nodes)) != len(nodes):
        raise ValueError(f"node_ids must be unique, got {nodes.tolist()}")
    offsets = np.arange(dofs_per_node)
    return (nodes[:, None] * dofs_per_node + offsets[None, :]).ravel()


def init_global_system(
    n_nodes: int, dofs_per_node: int = 1
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Allocate a zero global stiffness matrix and zero global load vector.

    Parameters
    ----------
    n_nodes : int
        Number of nodes in the mesh (dimensionless), must be >= 1.
    dofs_per_node : int, default 1
        DOFs per node (dimensionless).

    Returns
    -------
    K : numpy.ndarray, shape (n_dof, n_dof)
        Dense global stiffness matrix of zeros, with n_dof = n_nodes * dofs_per_node.
    F : numpy.ndarray, shape (n_dof,)
        Global load vector of zeros.
    """
    if n_nodes < 1 or dofs_per_node < 1:
        raise ValueError(
            f"n_nodes and dofs_per_node must be >= 1, got {n_nodes}, {dofs_per_node}"
        )
    n_dof = int(n_nodes) * int(dofs_per_node)
    return np.zeros((n_dof, n_dof)), np.zeros(n_dof)


def _check_dofs(dofs: Sequence[int], n_dof: int) -> np.ndarray:
    """Validate an element DOF list against the global system size."""
    idx = np.asarray(dofs, dtype=int)
    if idx.ndim != 1 or idx.size == 0:
        raise ValueError("dofs must be a non-empty 1D sequence")
    if np.any(idx < 0) or np.any(idx >= n_dof):
        raise ValueError(
            f"dofs out of range for a system with {n_dof} DOFs: {idx.tolist()}"
        )
    if len(np.unique(idx)) != len(idx):
        raise ValueError(f"dofs must be unique within an element: {idx.tolist()}")
    return idx


def assemble_global(
    K_global: np.ndarray, k_elem: np.ndarray, dofs: Sequence[int]
) -> np.ndarray:
    """
    Add an element stiffness matrix into the global stiffness matrix.

    Parameters
    ----------
    K_global : numpy.ndarray, shape (n_dof, n_dof)
        Global stiffness matrix [N/m or N*m/rad]. Modified in place.
    k_elem : numpy.ndarray, shape (m, m)
        Element stiffness matrix in global coordinates, with rows and
        columns ordered like ``dofs``.
    dofs : sequence of int, length m
        Global DOF indices of the element (see ``element_dofs``).

    Returns
    -------
    numpy.ndarray
        The same array object as ``K_global`` (for call chaining).

    Notes
    -----
    Implements ``K[dofs[i], dofs[j]] += k_elem[i, j]``. Row ``i`` of the
    element matrix always maps to ``dofs[i]``; the DOF order is never
    re-sorted.
    """
    n_dof = K_global.shape[0]
    if K_global.ndim != 2 or K_global.shape[0] != K_global.shape[1]:
        raise ValueError(f"K_global must be square, got shape {K_global.shape}")
    idx = _check_dofs(dofs, n_dof)
    k_elem = np.asarray(k_elem, dtype=float)
    if k_elem.shape != (idx.size, idx.size):
        raise ValueError(
            f"k_elem shape {k_elem.shape} does not match {idx.size} element DOFs"
        )
    K_global[np.ix_(idx, idx)] += k_elem
    return K_global


def assemble_global_vector(
    F_global: np.ndarray, f_elem: np.ndarray, dofs: Sequence[int]
) -> np.ndarray:
    """
    Add an element load vector into the global load vector.

    Parameters
    ----------
    F_global : numpy.ndarray, shape (n_dof,)
        Global load vector [N or N*m]. Modified in place.
    f_elem : numpy.ndarray, shape (m,)
        Element load vector, ordered like ``dofs``.
    dofs : sequence of int, length m
        Global DOF indices of the element.

    Returns
    -------
    numpy.ndarray
        The same array object as ``F_global``.
    """
    if F_global.ndim != 1:
        raise ValueError(f"F_global must be 1D, got shape {F_global.shape}")
    idx = _check_dofs(dofs, F_global.shape[0])
    f_elem = np.asarray(f_elem, dtype=float)
    if f_elem.shape != (idx.size,):
        raise ValueError(
            f"f_elem shape {f_elem.shape} does not match {idx.size} element DOFs"
        )
    F_global[idx] += f_elem
    return F_global


# ---------------------------------------------------------------------------
# 3. Boundary conditions and solution
# ---------------------------------------------------------------------------

def _check_bc(
    n_dof: int,
    fixed_dofs: Sequence[int],
    fixed_values: Optional[Sequence[float]],
) -> Tuple[np.ndarray, np.ndarray]:
    """Validate and normalise prescribed-DOF arguments."""
    fixed = np.asarray(fixed_dofs, dtype=int).ravel()
    if fixed.size and (np.any(fixed < 0) or np.any(fixed >= n_dof)):
        raise ValueError(
            f"fixed_dofs out of range for a system with {n_dof} DOFs: {fixed.tolist()}"
        )
    if len(np.unique(fixed)) != len(fixed):
        raise ValueError(f"fixed_dofs must be unique: {fixed.tolist()}")
    if fixed_values is None:
        values = np.zeros(fixed.size)
    else:
        values = np.asarray(fixed_values, dtype=float).ravel()
        if values.size != fixed.size:
            raise ValueError(
                f"fixed_values has {values.size} entries for {fixed.size} fixed_dofs"
            )
    return fixed, values


def apply_dirichlet_bc(
    K: np.ndarray,
    F: np.ndarray,
    fixed_dofs: Sequence[int],
    fixed_values: Optional[Sequence[float]] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Impose prescribed DOF values by row/column modification.

    Parameters
    ----------
    K : numpy.ndarray, shape (n_dof, n_dof)
        Global stiffness matrix. Not modified.
    F : numpy.ndarray, shape (n_dof,)
        Global load vector. Not modified.
    fixed_dofs : sequence of int
        Global indices of constrained DOFs.
    fixed_values : sequence of float, optional
        Prescribed value for each constrained DOF [m or rad]. Defaults to
        zero for every constrained DOF.

    Returns
    -------
    K_mod : numpy.ndarray, shape (n_dof, n_dof)
        Copy of K with constrained rows/columns zeroed and a unit diagonal.
    F_mod : numpy.ndarray, shape (n_dof,)
        Copy of F adjusted for non-zero prescribed values, holding the
        prescribed value in each constrained entry.

    Notes
    -----
    Symmetry of K is preserved. Solving ``K_mod u = F_mod`` returns the
    full displacement vector. Reactions are not computed here; use
    ``solve_system`` when reactions are needed.
    """
    K = np.asarray(K, dtype=float)
    F = np.asarray(F, dtype=float)
    fixed, values = _check_bc(K.shape[0], fixed_dofs, fixed_values)

    K_mod = K.copy()
    F_mod = F.copy()
    if fixed.size:
        F_mod -= K[:, fixed] @ values
        K_mod[fixed, :] = 0.0
        K_mod[:, fixed] = 0.0
        K_mod[fixed, fixed] = 1.0
        F_mod[fixed] = values
    return K_mod, F_mod


def solve_system(
    K: np.ndarray,
    F: np.ndarray,
    fixed_dofs: Sequence[int],
    fixed_values: Optional[Sequence[float]] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Solve ``K u = F`` with prescribed DOFs and recover support reactions.

    Parameters
    ----------
    K : numpy.ndarray, shape (n_dof, n_dof)
        Global stiffness matrix [N/m or N*m/rad].
    F : numpy.ndarray, shape (n_dof,)
        Global external load vector [N or N*m].
    fixed_dofs : sequence of int
        Global indices of constrained DOFs.
    fixed_values : sequence of float, optional
        Prescribed value for each constrained DOF [m or rad]. Defaults to
        zero for every constrained DOF.

    Returns
    -------
    u : numpy.ndarray, shape (n_dof,)
        Full displacement vector [m or rad], including prescribed values.
    reactions : numpy.ndarray, shape (n_dof,)
        Support reactions [N or N*m]: ``K u - F`` at constrained DOFs and
        zero at free DOFs.

    Raises
    ------
    ValueError
        If the constrained system is singular or numerically singular
        (insufficient supports, i.e. a rigid-body mode remains).

    Notes
    -----
    Uses partitioning: ``K_ff u_f = F_f - K_fc u_c``. The reaction sign
    convention is the force the support exerts on the structure.
    """
    K = np.asarray(K, dtype=float)
    F = np.asarray(F, dtype=float)
    n_dof = K.shape[0]
    if K.ndim != 2 or K.shape[0] != K.shape[1]:
        raise ValueError(f"K must be square, got shape {K.shape}")
    if F.shape != (n_dof,):
        raise ValueError(f"F shape {F.shape} does not match K with {n_dof} DOFs")
    fixed, values = _check_bc(n_dof, fixed_dofs, fixed_values)

    is_free = np.ones(n_dof, dtype=bool)
    is_free[fixed] = False
    free = np.flatnonzero(is_free)

    u = np.zeros(n_dof)
    u[fixed] = values

    if free.size:
        K_ff = K[np.ix_(free, free)]
        rhs = F[free] - K[np.ix_(free, fixed)] @ values
        if np.linalg.cond(K_ff) > _MAX_CONDITION_NUMBER:
            raise ValueError(
                "Constrained stiffness matrix is singular: the model has "
                "insufficient supports (rigid-body motion is not prevented)."
            )
        try:
            u[free] = np.linalg.solve(K_ff, rhs)
        except np.linalg.LinAlgError as exc:
            raise ValueError(
                "Constrained stiffness matrix is singular: the model has "
                "insufficient supports (rigid-body motion is not prevented)."
            ) from exc

    reactions = np.zeros(n_dof)
    reactions[fixed] = K[fixed, :] @ u - F[fixed]
    return u, reactions


# ---------------------------------------------------------------------------
# 4. Shape functions
# ---------------------------------------------------------------------------

def bar_shape_functions(xi: float) -> np.ndarray:
    """
    Linear shape functions of a 2-node bar element.

    Parameters
    ----------
    xi : float
        Normalised coordinate x / L along the element, in [0, 1]
        (dimensionless).

    Returns
    -------
    numpy.ndarray, shape (2,)
        ``[N1, N2] = [1 - xi, xi]``; they sum to 1.
    """
    return np.array([1.0 - xi, xi])


def bar_B_matrix(length: float) -> np.ndarray:
    """
    Strain-displacement matrix of a 2-node bar element (constant strain).

    Parameters
    ----------
    length : float
        Element length L [m], must be > 0.

    Returns
    -------
    numpy.ndarray, shape (2,)
        ``[-1/L, 1/L]``, so that axial strain = B @ [u1, u2].
    """
    if length <= 0.0:
        raise ValueError(f"length must be positive, got {length}")
    return np.array([-1.0 / length, 1.0 / length])


def beam_shape_functions(xi: float, length: float) -> np.ndarray:
    """
    Hermite cubic shape functions of an Euler-Bernoulli beam element.

    Parameters
    ----------
    xi : float
        Normalised coordinate x / L, in [0, 1] (dimensionless).
    length : float
        Element length L [m], must be > 0.

    Returns
    -------
    numpy.ndarray, shape (4,)
        ``[N1, N2, N3, N4]`` for DOFs ``[w1, theta1, w2, theta2]``.
        N1 and N3 are dimensionless; N2 and N4 have units of metres.

    Notes
    -----
    N1 = 1 - 3 xi^2 + 2 xi^3,  N2 = L (xi - 2 xi^2 + xi^3),
    N3 = 3 xi^2 - 2 xi^3,      N4 = L (-xi^2 + xi^3).
    """
    if length <= 0.0:
        raise ValueError(f"length must be positive, got {length}")
    xi2 = xi * xi
    xi3 = xi2 * xi
    return np.array([
        1.0 - 3.0 * xi2 + 2.0 * xi3,
        length * (xi - 2.0 * xi2 + xi3),
        3.0 * xi2 - 2.0 * xi3,
        length * (-xi2 + xi3),
    ])


def beam_shape_second_derivatives(xi: float, length: float) -> np.ndarray:
    """
    Second derivatives d2N/dx2 of the Hermite beam shape functions.

    Parameters
    ----------
    xi : float
        Normalised coordinate x / L, in [0, 1] (dimensionless).
    length : float
        Element length L [m], must be > 0.

    Returns
    -------
    numpy.ndarray, shape (4,)
        ``[N1'', N2'', N3'', N4'']`` with respect to x [1/m^2, 1/m, 1/m^2, 1/m].
        Curvature is ``kappa = B @ [w1, theta1, w2, theta2]``.
    """
    if length <= 0.0:
        raise ValueError(f"length must be positive, got {length}")
    inv_l = 1.0 / length
    return np.array([
        (-6.0 + 12.0 * xi) * inv_l ** 2,
        (-4.0 + 6.0 * xi) * inv_l,
        (6.0 - 12.0 * xi) * inv_l ** 2,
        (-2.0 + 6.0 * xi) * inv_l,
    ])


def cst_shape_functions(xi: float, eta: float) -> np.ndarray:
    """
    Area-coordinate shape functions of the 3-node constant strain triangle.

    Parameters
    ----------
    xi, eta : float
        Natural coordinates of the point in the reference triangle with
        vertices (0, 0), (1, 0), (0, 1) (dimensionless).

    Returns
    -------
    numpy.ndarray, shape (3,)
        ``[1 - xi - eta, xi, eta]``; they sum to 1.
    """
    return np.array([1.0 - xi - eta, xi, eta])


def _check_coords(coords: np.ndarray, n_nodes: int) -> np.ndarray:
    """Validate an (n_nodes, 2) coordinate array."""
    coords = np.asarray(coords, dtype=float)
    if coords.shape != (n_nodes, 2):
        raise ValueError(
            f"coords must have shape ({n_nodes}, 2), got {coords.shape}"
        )
    return coords


def cst_B_matrix(coords: np.ndarray) -> Tuple[np.ndarray, float]:
    """
    Strain-displacement matrix and area of a constant strain triangle.

    Parameters
    ----------
    coords : numpy.ndarray, shape (3, 2)
        Nodal coordinates (x, y) [m], listed counter-clockwise.

    Returns
    -------
    B : numpy.ndarray, shape (3, 6)
        Maps ``[u1, v1, u2, v2, u3, v3]`` to engineering strains
        ``[eps_x, eps_y, gamma_xy]``. Constant over the element.
    area : float
        Element area [m^2], always positive.

    Raises
    ------
    ValueError
        If the triangle is degenerate or its nodes are not counter-clockwise.
    """
    coords = _check_coords(coords, 3)
    (x1, y1), (x2, y2), (x3, y3) = coords
    two_area = (x2 - x1) * (y3 - y1) - (x3 - x1) * (y2 - y1)
    edges = coords - np.roll(coords, -1, axis=0)
    scale = float(np.max(np.sum(edges ** 2, axis=1)))
    if two_area <= _MIN_RELATIVE_AREA * scale:
        raise ValueError(
            "Triangle has zero or negative area; list nodes counter-clockwise."
        )

    b = np.array([y2 - y3, y3 - y1, y1 - y2])
    c = np.array([x3 - x2, x1 - x3, x2 - x1])
    B = np.zeros((3, 6))
    B[0, 0::2] = b
    B[1, 1::2] = c
    B[2, 0::2] = c
    B[2, 1::2] = b
    B /= two_area
    return B, 0.5 * two_area


# Natural-coordinate signs (xi, eta) of the four Q4 nodes, counter-clockwise.
_Q4_NODE_SIGNS = np.array(
    [[-1.0, -1.0], [1.0, -1.0], [1.0, 1.0], [-1.0, 1.0]]
)


def q4_shape_functions(xi: float, eta: float) -> np.ndarray:
    """
    Bilinear shape functions of the 4-node quadrilateral (Q4).

    Parameters
    ----------
    xi, eta : float
        Natural coordinates in [-1, 1] (dimensionless).

    Returns
    -------
    numpy.ndarray, shape (4,)
        ``N_i = (1 + xi_i xi)(1 + eta_i eta) / 4`` for nodes ordered
        (-1,-1), (1,-1), (1,1), (-1,1); they sum to 1.
    """
    sx = _Q4_NODE_SIGNS[:, 0]
    sy = _Q4_NODE_SIGNS[:, 1]
    return 0.25 * (1.0 + sx * xi) * (1.0 + sy * eta)


def q4_shape_derivatives(xi: float, eta: float) -> np.ndarray:
    """
    Derivatives of the Q4 shape functions with respect to (xi, eta).

    Parameters
    ----------
    xi, eta : float
        Natural coordinates in [-1, 1] (dimensionless).

    Returns
    -------
    numpy.ndarray, shape (2, 4)
        Row 0 holds dN/dxi, row 1 holds dN/deta.
    """
    sx = _Q4_NODE_SIGNS[:, 0]
    sy = _Q4_NODE_SIGNS[:, 1]
    d_dxi = 0.25 * sx * (1.0 + sy * eta)
    d_deta = 0.25 * sy * (1.0 + sx * xi)
    return np.vstack([d_dxi, d_deta])


def q4_jacobian(
    xi: float, eta: float, coords: np.ndarray
) -> Tuple[np.ndarray, float]:
    """
    Jacobian matrix and determinant of the Q4 isoparametric mapping.

    Parameters
    ----------
    xi, eta : float
        Natural coordinates in [-1, 1] (dimensionless).
    coords : numpy.ndarray, shape (4, 2)
        Nodal coordinates (x, y) [m], listed counter-clockwise.

    Returns
    -------
    J : numpy.ndarray, shape (2, 2)
        ``[[dx/dxi, dy/dxi], [dx/deta, dy/deta]]`` [m].
    det_J : float
        Determinant of J [m^2]; positive for a valid counter-clockwise element.
    """
    coords = _check_coords(coords, 4)
    J = q4_shape_derivatives(xi, eta) @ coords
    return J, float(np.linalg.det(J))


def q4_B_matrix(
    xi: float, eta: float, coords: np.ndarray
) -> Tuple[np.ndarray, float]:
    """
    Strain-displacement matrix of the Q4 element at a point.

    Parameters
    ----------
    xi, eta : float
        Natural coordinates in [-1, 1] (dimensionless).
    coords : numpy.ndarray, shape (4, 2)
        Nodal coordinates (x, y) [m], listed counter-clockwise.

    Returns
    -------
    B : numpy.ndarray, shape (3, 8)
        Maps ``[u1, v1, ..., u4, v4]`` to engineering strains
        ``[eps_x, eps_y, gamma_xy]`` at (xi, eta).
    det_J : float
        Jacobian determinant [m^2], for the integration factor ``det_J * w``.

    Raises
    ------
    ValueError
        If det_J is zero or negative (distorted or clockwise element).
    """
    coords = _check_coords(coords, 4)
    J, det_J = q4_jacobian(xi, eta, coords)
    edges = coords - np.roll(coords, -1, axis=0)
    scale = float(np.max(np.sum(edges ** 2, axis=1)))
    if det_J <= _MIN_RELATIVE_AREA * scale:
        raise ValueError(
            "Non-positive Jacobian determinant; list nodes counter-clockwise "
            "and avoid degenerate or re-entrant elements."
        )
    dN_dxy = np.linalg.solve(J, q4_shape_derivatives(xi, eta))  # (2, 4)

    B = np.zeros((3, 2 * _Q4_NODE_SIGNS.shape[0]))
    B[0, 0::2] = dN_dxy[0]
    B[1, 1::2] = dN_dxy[1]
    B[2, 0::2] = dN_dxy[1]
    B[2, 1::2] = dN_dxy[0]
    return B, det_J


# ---------------------------------------------------------------------------
# 5. Geometry helpers
# ---------------------------------------------------------------------------

def bar_direction_cosines(coords: np.ndarray) -> Tuple[float, float, float]:
    """
    Length and direction cosines of a 2D bar / truss member.

    Parameters
    ----------
    coords : numpy.ndarray, shape (2, 2)
        Coordinates (x, y) [m] of the start and end nodes.

    Returns
    -------
    length : float
        Member length [m].
    c : float
        Cosine of the angle from the global x axis (dimensionless).
    s : float
        Sine of the angle from the global x axis (dimensionless).

    Raises
    ------
    ValueError
        If the member has zero length.
    """
    coords = _check_coords(coords, 2)
    delta = coords[1] - coords[0]
    length = float(np.hypot(delta[0], delta[1]))
    if length <= _MIN_ELEMENT_LENGTH_M:
        raise ValueError("Member has zero length (coincident nodes).")
    return length, float(delta[0] / length), float(delta[1] / length)


def truss_transformation_matrix(c: float, s: float) -> np.ndarray:
    """
    Transformation from global 2D DOFs to the local axial DOFs of a truss member.

    Parameters
    ----------
    c, s : float
        Direction cosines of the member (dimensionless), c^2 + s^2 = 1.

    Returns
    -------
    numpy.ndarray, shape (2, 4)
        T such that ``u_local = T @ [u1, v1, u2, v2]``. The global element
        stiffness is ``T.T @ k_local @ T``.
    """
    return np.array([
        [c, s, 0.0, 0.0],
        [0.0, 0.0, c, s],
    ])
