"""
fea_1d.py -- One-dimensional finite element solvers.

Axial bar, 2D truss and Euler-Bernoulli beam solvers built on the shared
assembly, boundary-condition and shape-function utilities in ``utils.py``.
Linear elastic analysis with small displacements. All quantities are SI
(m, N, Pa, K); see Skills/fea_skills.md for the conventions.

Conventions
-----------
* DOF ordering is node-major: bar 1 DOF per node (u); 2D truss 2 DOFs per
  node (u, v); beam 2 DOFs per node (w, theta).
* Loads are signed: positive in the positive axis direction (a downward
  transverse load is negative). Tension and tensile stress are positive.
* Every solver returns a dict of NumPy arrays.

Run with the ``Src`` folder on ``sys.path`` so that ``import utils`` resolves.
"""

from __future__ import annotations

from typing import Dict, Mapping, Sequence, Union

import numpy as np

from utils import (
    assemble_global,
    assemble_global_vector,
    bar_B_matrix,
    bar_direction_cosines,
    element_dofs,
    init_global_system,
    solve_system,
    truss_transformation_matrix,
)

# ---------------------------------------------------------------------------
# Named constants (SI)
# ---------------------------------------------------------------------------

STEEL_E_PA = 200.0e9
STEEL_NU = 0.30
STEEL_ALPHA_PER_K = 12.0e-6
STEEL_RHO_KG_M3 = 7850.0

ALUMINIUM_E_PA = 69.0e9
ALUMINIUM_NU = 0.33
ALUMINIUM_ALPHA_PER_K = 23.0e-6
ALUMINIUM_RHO_KG_M3 = 2700.0

DEFAULT_LENGTH_M = 1.0
DEFAULT_AREA_M2 = 1.0e-4
DEFAULT_SECOND_MOMENT_M4 = 8.0e-6
DEFAULT_AXIAL_LOAD_N = 1.0e3
DEFAULT_TRANSVERSE_LOAD_N = -1.0e3
DEFAULT_DISTRIBUTED_LOAD_N_PER_M = -1.0e3
DEFAULT_DELTA_T_K = 50.0
DEFAULT_N_ELEMENTS = 4

DOFS_PER_NODE_BAR = 1
DOFS_PER_NODE_TRUSS = 2
DOFS_PER_NODE_BEAM = 2

SUPPORT_CANTILEVER = "cantilever"
SUPPORT_SIMPLY_SUPPORTED = "simply_supported"

Number = Union[float, int]


# ---------------------------------------------------------------------------
# Input validation helpers
# ---------------------------------------------------------------------------

def _require_positive(name: str, value: float) -> None:
    """Raise ValueError unless ``value`` is a positive number."""
    if not value > 0.0:
        raise ValueError(f"{name} must be positive, got {value}")


def _require_positive_int(name: str, value: int) -> None:
    """Raise ValueError unless ``value`` is an integer >= 1."""
    if isinstance(value, bool) or not isinstance(value, (int, np.integer)) or value < 1:
        raise ValueError(f"{name} must be an integer >= 1, got {value!r}")


# ---------------------------------------------------------------------------
# Axial bar
# ---------------------------------------------------------------------------

def element_stiffness_bar(
    length: float, area: float, youngs_modulus: float
) -> np.ndarray:
    """
    Stiffness matrix of a 2-node axial bar element.

    Parameters
    ----------
    length : float
        Element length [m], must be positive.
    area : float
        Cross-section area [m^2], must be positive.
    youngs_modulus : float
        Young's modulus [Pa], must be positive.

    Returns
    -------
    numpy.ndarray, shape (2, 2)
        Element stiffness matrix [N/m] for DOFs ``[u1, u2]``.

    Raises
    ------
    ValueError
        If any argument is not positive.

    Notes
    -----
    k = (E A / L) [[1, -1], [-1, 1]].
    """
    _require_positive("length", length)
    _require_positive("area", area)
    _require_positive("youngs_modulus", youngs_modulus)
    return youngs_modulus * area / length * np.array([[1.0, -1.0], [-1.0, 1.0]])


def solve_bar(
    length: float = DEFAULT_LENGTH_M,
    area: float = DEFAULT_AREA_M2,
    youngs_modulus: float = STEEL_E_PA,
    tip_load: float = DEFAULT_AXIAL_LOAD_N,
    n_elements: int = DEFAULT_N_ELEMENTS,
) -> Dict[str, np.ndarray]:
    """
    Solve a fixed-free axial bar with a load at the free end.

    Parameters
    ----------
    length : float, default DEFAULT_LENGTH_M
        Bar length [m], must be positive.
    area : float, default DEFAULT_AREA_M2
        Cross-section area [m^2], must be positive.
    youngs_modulus : float, default STEEL_E_PA
        Young's modulus [Pa], must be positive.
    tip_load : float, default DEFAULT_AXIAL_LOAD_N
        Axial force at the free end [N]; positive is tension.
    n_elements : int, default DEFAULT_N_ELEMENTS
        Number of equal-length elements (dimensionless), must be >= 1.

    Returns
    -------
    dict
        ``"displacements"`` : numpy.ndarray, shape (n_elements + 1,) [m].
        ``"stresses"`` : numpy.ndarray, shape (n_elements,) [Pa], per element.
        ``"reactions"`` : numpy.ndarray, shape (n_elements + 1,) [N]; the
        non-zero entry is at the fixed node.

    Raises
    ------
    ValueError
        If a geometric or material argument is not positive, or if
        ``n_elements`` is not an integer >= 1.

    Notes
    -----
    Node 0 is fixed. With linear elements the nodal displacements are exact
    for an end load: u_tip = P L / (E A), independent of ``n_elements``.
    """
    _require_positive("length", length)
    _require_positive("area", area)
    _require_positive("youngs_modulus", youngs_modulus)
    _require_positive_int("n_elements", n_elements)

    element_length = length / n_elements
    k_elem = element_stiffness_bar(element_length, area, youngs_modulus)
    stiffness, load = init_global_system(n_elements + 1, DOFS_PER_NODE_BAR)
    for e in range(n_elements):
        dofs = element_dofs([e, e + 1], DOFS_PER_NODE_BAR)
        assemble_global(stiffness, k_elem, dofs)
    load[-1] = tip_load

    displacements, reactions = solve_system(stiffness, load, [0])

    strain_operator = bar_B_matrix(element_length)
    strains = np.array(
        [strain_operator @ displacements[e:e + 2] for e in range(n_elements)]
    )
    return {
        "displacements": displacements,
        "stresses": youngs_modulus * strains,
        "reactions": reactions,
    }


def element_load_bar_thermal(
    area: float, youngs_modulus: float, alpha: float, delta_t: float
) -> np.ndarray:
    """
    Equivalent nodal load of a bar element for a uniform temperature change.

    Parameters
    ----------
    area : float
        Cross-section area [m^2], must be positive.
    youngs_modulus : float
        Young's modulus [Pa], must be positive.
    alpha : float
        Coefficient of thermal expansion [1/K], must be positive.
    delta_t : float
        Uniform temperature change [K]; positive is heating.

    Returns
    -------
    numpy.ndarray, shape (2,)
        Element load vector [N] for DOFs ``[u1, u2]``.

    Raises
    ------
    ValueError
        If ``area``, ``youngs_modulus`` or ``alpha`` is not positive.

    Notes
    -----
    F_th = E A alpha dT * [-1, +1]; the magnitude E A alpha dT is the force
    needed to hold the bar at its original length.
    """
    _require_positive("area", area)
    _require_positive("youngs_modulus", youngs_modulus)
    _require_positive("alpha", alpha)
    return youngs_modulus * area * alpha * delta_t * np.array([-1.0, 1.0])


def solve_bar_thermal(
    length: float = DEFAULT_LENGTH_M,
    area: float = DEFAULT_AREA_M2,
    youngs_modulus: float = STEEL_E_PA,
    alpha: float = STEEL_ALPHA_PER_K,
    delta_t: float = DEFAULT_DELTA_T_K,
    n_elements: int = DEFAULT_N_ELEMENTS,
    fixed_far_end: bool = False,
) -> Dict[str, np.ndarray]:
    """
    Solve an axial bar under a uniform temperature change.

    Parameters
    ----------
    length : float, default DEFAULT_LENGTH_M
        Bar length [m], must be positive.
    area : float, default DEFAULT_AREA_M2
        Cross-section area [m^2], must be positive.
    youngs_modulus : float, default STEEL_E_PA
        Young's modulus [Pa], must be positive.
    alpha : float, default STEEL_ALPHA_PER_K
        Coefficient of thermal expansion [1/K], must be positive.
    delta_t : float, default DEFAULT_DELTA_T_K
        Uniform temperature change [K]; positive is heating.
    n_elements : int, default DEFAULT_N_ELEMENTS
        Number of equal-length elements (dimensionless), must be >= 1.
    fixed_far_end : bool, default False
        If False the bar is fixed at node 0 and free at the far end. If True
        both ends are fixed.

    Returns
    -------
    dict
        ``"displacements"`` : numpy.ndarray, shape (n_elements + 1,) [m].
        ``"stresses"`` : numpy.ndarray, shape (n_elements,) [Pa], per element;
        tension positive.
        ``"reactions"`` : numpy.ndarray, shape (n_elements + 1,) [N].

    Raises
    ------
    ValueError
        If a geometric or material argument is not positive, or if
        ``n_elements`` is not an integer >= 1.

    Notes
    -----
    Free bar: u_tip = alpha dT L and stress = 0. Fixed-fixed bar: all
    displacements are zero and stress = -E alpha dT (compressive when
    heated), with end reactions of magnitude E A alpha dT. Element stress is
    E (du/dx - alpha dT).
    """
    _require_positive("length", length)
    _require_positive("area", area)
    _require_positive("youngs_modulus", youngs_modulus)
    _require_positive("alpha", alpha)
    _require_positive_int("n_elements", n_elements)

    element_length = length / n_elements
    k_elem = element_stiffness_bar(element_length, area, youngs_modulus)
    f_elem = element_load_bar_thermal(area, youngs_modulus, alpha, delta_t)
    stiffness, load = init_global_system(n_elements + 1, DOFS_PER_NODE_BAR)
    for e in range(n_elements):
        dofs = element_dofs([e, e + 1], DOFS_PER_NODE_BAR)
        assemble_global(stiffness, k_elem, dofs)
        assemble_global_vector(load, f_elem, dofs)

    fixed_dofs = [0, n_elements] if fixed_far_end else [0]
    displacements, reactions = solve_system(stiffness, load, fixed_dofs)

    strain_operator = bar_B_matrix(element_length)
    mechanical_strains = np.array(
        [strain_operator @ displacements[e:e + 2] - alpha * delta_t
         for e in range(n_elements)]
    )
    return {
        "displacements": displacements,
        "stresses": youngs_modulus * mechanical_strains,
        "reactions": reactions,
    }


# ---------------------------------------------------------------------------
# 2D truss
# ---------------------------------------------------------------------------

def element_stiffness_truss_2d(
    coords: np.ndarray, area: float, youngs_modulus: float
) -> np.ndarray:
    """
    Global-coordinate stiffness matrix of a 2D truss member.

    Parameters
    ----------
    coords : numpy.ndarray, shape (2, 2)
        Coordinates (x, y) [m] of the start and end nodes.
    area : float
        Cross-section area [m^2], must be positive.
    youngs_modulus : float
        Young's modulus [Pa], must be positive.

    Returns
    -------
    numpy.ndarray, shape (4, 4)
        Element stiffness matrix [N/m] for DOFs ``[u1, v1, u2, v2]``.

    Raises
    ------
    ValueError
        If the member has zero length or a property is not positive.

    Notes
    -----
    k_global = T^T k_local T with T = [[c, s, 0, 0], [0, 0, c, s]] and
    k_local = (E A / L) [[1, -1], [-1, 1]], where c and s are the direction
    cosines of the member.
    """
    length, c, s = bar_direction_cosines(coords)
    k_local = element_stiffness_bar(length, area, youngs_modulus)
    transformation = truss_transformation_matrix(c, s)
    return transformation.T @ k_local @ transformation


def solve_truss_2d(
    nodes: Sequence[Sequence[float]],
    elements: Sequence[Sequence[int]],
    areas: Union[Number, Sequence[float]],
    loads: Mapping[int, Sequence[float]],
    supports: Mapping[int, Sequence[bool]],
    youngs_modulus: Union[Number, Sequence[float]] = STEEL_E_PA,
) -> Dict[str, np.ndarray]:
    """
    Solve a statically loaded pin-jointed 2D truss.

    Parameters
    ----------
    nodes : array_like, shape (n_nodes, 2)
        Node coordinates (x, y) [m].
    elements : array_like of int, shape (n_elements, 2)
        Zero-based start and end node of each member.
    areas : float or array_like, shape (n_elements,)
        Cross-section area [m^2]; a scalar applies to every member.
    loads : mapping of int to (float, float)
        Node index -> applied force (Fx, Fy) [N].
    supports : mapping of int to (bool, bool)
        Node index -> (fix_x, fix_y); True constrains that DOF.
    youngs_modulus : float or array_like, default STEEL_E_PA
        Young's modulus [Pa]; a scalar applies to every member.

    Returns
    -------
    dict
        ``"displacements"`` : numpy.ndarray, shape (2 n_nodes,) [m], ordered
        (u, v) per node.
        ``"member_forces"`` : numpy.ndarray, shape (n_elements,) [N]; tension
        positive.
        ``"stresses"`` : numpy.ndarray, shape (n_elements,) [Pa]; tension
        positive.
        ``"reactions"`` : numpy.ndarray, shape (2 n_nodes,) [N].

    Raises
    ------
    ValueError
        If the inputs have the wrong shape, an index is out of range, a
        property is not positive, or the truss is unstable (insufficient
        supports).

    Notes
    -----
    Member force N = (E A / L) (d2 - d1), where d1, d2 are the nodal
    displacements projected on the member axis.
    """
    node_xy = np.asarray(nodes, dtype=float)
    if node_xy.ndim != 2 or node_xy.shape[1] != 2:
        raise ValueError(f"nodes must have shape (n_nodes, 2), got {node_xy.shape}")
    n_nodes = node_xy.shape[0]

    connectivity = np.asarray(elements, dtype=int)
    if connectivity.ndim != 2 or connectivity.shape[1] != 2 or connectivity.shape[0] < 1:
        raise ValueError(
            f"elements must have shape (n_elements, 2), got {connectivity.shape}"
        )
    if np.any(connectivity < 0) or np.any(connectivity >= n_nodes):
        raise ValueError(f"elements reference a node outside 0..{n_nodes - 1}")
    n_elements = connectivity.shape[0]

    area_arr = np.broadcast_to(np.asarray(areas, dtype=float), (n_elements,))
    modulus_arr = np.broadcast_to(
        np.asarray(youngs_modulus, dtype=float), (n_elements,)
    )
    if np.any(~(area_arr > 0.0)):
        raise ValueError(f"areas must be positive, got {area_arr.tolist()}")
    if np.any(~(modulus_arr > 0.0)):
        raise ValueError(f"youngs_modulus must be positive, got {modulus_arr.tolist()}")

    stiffness, load = init_global_system(n_nodes, DOFS_PER_NODE_TRUSS)
    for e, (i, j) in enumerate(connectivity):
        k_elem = element_stiffness_truss_2d(
            node_xy[[i, j]], area_arr[e], modulus_arr[e]
        )
        assemble_global(stiffness, k_elem, element_dofs([i, j], DOFS_PER_NODE_TRUSS))

    for node, (fx, fy) in loads.items():
        if not 0 <= node < n_nodes:
            raise ValueError(f"load node {node} is outside 0..{n_nodes - 1}")
        load[DOFS_PER_NODE_TRUSS * node] += fx
        load[DOFS_PER_NODE_TRUSS * node + 1] += fy

    fixed_dofs = []
    for node, (fix_x, fix_y) in supports.items():
        if not 0 <= node < n_nodes:
            raise ValueError(f"support node {node} is outside 0..{n_nodes - 1}")
        if fix_x:
            fixed_dofs.append(DOFS_PER_NODE_TRUSS * node)
        if fix_y:
            fixed_dofs.append(DOFS_PER_NODE_TRUSS * node + 1)

    displacements, reactions = solve_system(stiffness, load, sorted(fixed_dofs))

    member_forces = np.zeros(n_elements)
    for e, (i, j) in enumerate(connectivity):
        length, c, s = bar_direction_cosines(node_xy[[i, j]])
        dofs = element_dofs([i, j], DOFS_PER_NODE_TRUSS)
        axial = truss_transformation_matrix(c, s) @ displacements[dofs]
        member_forces[e] = (
            modulus_arr[e] * area_arr[e] / length * (axial[1] - axial[0])
        )
    return {
        "displacements": displacements,
        "member_forces": member_forces,
        "stresses": member_forces / area_arr,
        "reactions": reactions,
    }


# ---------------------------------------------------------------------------
# Euler-Bernoulli beam
# ---------------------------------------------------------------------------

def element_stiffness_beam(
    length: float, youngs_modulus: float, second_moment: float
) -> np.ndarray:
    """
    Stiffness matrix of a 2-node Euler-Bernoulli beam element.

    Parameters
    ----------
    length : float
        Element length [m], must be positive.
    youngs_modulus : float
        Young's modulus [Pa], must be positive.
    second_moment : float
        Second moment of area I of the cross-section [m^4], must be positive.

    Returns
    -------
    numpy.ndarray, shape (4, 4)
        Element stiffness matrix for DOFs ``[w1, theta1, w2, theta2]``
        (translation [m], rotation [rad]).

    Raises
    ------
    ValueError
        If any argument is not positive.

    Notes
    -----
    k = (E I / L^3) [[12, 6L, -12, 6L], [6L, 4L^2, -6L, 2L^2],
    [-12, -6L, 12, -6L], [6L, 2L^2, -6L, 4L^2]]. Shear deformation is
    neglected.
    """
    _require_positive("length", length)
    _require_positive("youngs_modulus", youngs_modulus)
    _require_positive("second_moment", second_moment)
    coefficient = youngs_modulus * second_moment / length ** 3
    return coefficient * np.array([
        [12.0, 6.0 * length, -12.0, 6.0 * length],
        [6.0 * length, 4.0 * length ** 2, -6.0 * length, 2.0 * length ** 2],
        [-12.0, -6.0 * length, 12.0, -6.0 * length],
        [6.0 * length, 2.0 * length ** 2, -6.0 * length, 4.0 * length ** 2],
    ])


def solve_beam(
    length: float = DEFAULT_LENGTH_M,
    youngs_modulus: float = STEEL_E_PA,
    second_moment: float = DEFAULT_SECOND_MOMENT_M4,
    point_load: float = DEFAULT_TRANSVERSE_LOAD_N,
    n_elements: int = DEFAULT_N_ELEMENTS,
    support: str = SUPPORT_CANTILEVER,
) -> Dict[str, np.ndarray]:
    """
    Solve an Euler-Bernoulli beam under a single transverse point load.

    Parameters
    ----------
    length : float, default DEFAULT_LENGTH_M
        Beam length [m], must be positive.
    youngs_modulus : float, default STEEL_E_PA
        Young's modulus [Pa], must be positive.
    second_moment : float, default DEFAULT_SECOND_MOMENT_M4
        Second moment of area [m^4], must be positive.
    point_load : float, default DEFAULT_TRANSVERSE_LOAD_N
        Transverse force [N]; positive is upward (+y), so a downward load is
        negative. It acts at the free end of a cantilever and at midspan of a
        simply supported beam.
    n_elements : int, default DEFAULT_N_ELEMENTS
        Number of equal-length elements (dimensionless), must be >= 1, and
        even for a simply supported beam so that midspan is a node.
    support : str, default SUPPORT_CANTILEVER
        ``"cantilever"`` (fixed at node 0, free at the far end) or
        ``"simply_supported"`` (deflection fixed at both ends).

    Returns
    -------
    dict
        ``"displacements"`` : numpy.ndarray, shape (2 (n_elements + 1),),
        ordered (w, theta) per node [m, rad].
        ``"deflections"`` : numpy.ndarray, shape (n_elements + 1,) [m].
        ``"rotations"`` : numpy.ndarray, shape (n_elements + 1,) [rad].
        ``"reactions"`` : numpy.ndarray, shape (2 (n_elements + 1),)
        [N, N*m].

    Raises
    ------
    ValueError
        If a property is not positive, ``n_elements`` is invalid, ``support``
        is unknown, or a simply supported beam has an odd element count.

    Notes
    -----
    Cantilever tip deflection is P L^3 / (3 E I); simply supported midspan
    deflection is P L^3 / (48 E I) (magnitudes). Nodal values are exact for
    point loads at nodes.
    """
    _require_positive("length", length)
    _require_positive("youngs_modulus", youngs_modulus)
    _require_positive("second_moment", second_moment)
    _require_positive_int("n_elements", n_elements)
    if support not in (SUPPORT_CANTILEVER, SUPPORT_SIMPLY_SUPPORTED):
        raise ValueError(
            f"support must be '{SUPPORT_CANTILEVER}' or "
            f"'{SUPPORT_SIMPLY_SUPPORTED}', got {support!r}"
        )
    if support == SUPPORT_SIMPLY_SUPPORTED and n_elements % 2 != 0:
        raise ValueError(
            f"n_elements must be even for a simply supported beam, got {n_elements}"
        )

    element_length = length / n_elements
    k_elem = element_stiffness_beam(element_length, youngs_modulus, second_moment)
    stiffness, load = init_global_system(n_elements + 1, DOFS_PER_NODE_BEAM)
    for e in range(n_elements):
        dofs = element_dofs([e, e + 1], DOFS_PER_NODE_BEAM)
        assemble_global(stiffness, k_elem, dofs)

    last_node_w_dof = DOFS_PER_NODE_BEAM * n_elements
    if support == SUPPORT_CANTILEVER:
        fixed_dofs = [0, 1]
        load_dof = last_node_w_dof
    else:
        fixed_dofs = [0, last_node_w_dof]
        load_dof = DOFS_PER_NODE_BEAM * (n_elements // 2)
    load[load_dof] = point_load

    displacements, reactions = solve_system(stiffness, load, fixed_dofs)
    return {
        "displacements": displacements,
        "deflections": displacements[0::DOFS_PER_NODE_BEAM],
        "rotations": displacements[1::DOFS_PER_NODE_BEAM],
        "reactions": reactions,
    }


def element_load_beam_udl(length: float, distributed_load: float) -> np.ndarray:
    """
    Consistent nodal load of a beam element under uniform transverse load.

    Parameters
    ----------
    length : float
        Element length [m], must be positive.
    distributed_load : float
        Uniform transverse load q [N/m]; positive is upward (+y).

    Returns
    -------
    numpy.ndarray, shape (4,)
        Element load vector for DOFs ``[w1, theta1, w2, theta2]`` [N, N*m].

    Raises
    ------
    ValueError
        If ``length`` is not positive.

    Notes
    -----
    f = q [L/2, L^2/12, L/2, -L^2/12] (fixed-end forces and moments of a
    uniformly loaded element).
    """
    _require_positive("length", length)
    return distributed_load * np.array([
        length / 2.0,
        length ** 2 / 12.0,
        length / 2.0,
        -length ** 2 / 12.0,
    ])


def solve_beam_udl(
    length: float = DEFAULT_LENGTH_M,
    youngs_modulus: float = STEEL_E_PA,
    second_moment: float = DEFAULT_SECOND_MOMENT_M4,
    distributed_load: float = DEFAULT_DISTRIBUTED_LOAD_N_PER_M,
    n_elements: int = DEFAULT_N_ELEMENTS,
) -> Dict[str, np.ndarray]:
    """
    Solve a cantilever beam under a uniform transverse load.

    Parameters
    ----------
    length : float, default DEFAULT_LENGTH_M
        Beam length [m], must be positive.
    youngs_modulus : float, default STEEL_E_PA
        Young's modulus [Pa], must be positive.
    second_moment : float, default DEFAULT_SECOND_MOMENT_M4
        Second moment of area [m^4], must be positive.
    distributed_load : float, default DEFAULT_DISTRIBUTED_LOAD_N_PER_M
        Uniform transverse load q [N/m]; positive is upward (+y), so a
        downward load is negative.
    n_elements : int, default DEFAULT_N_ELEMENTS
        Number of equal-length elements (dimensionless), must be >= 1.

    Returns
    -------
    dict
        ``"displacements"`` : numpy.ndarray, shape (2 (n_elements + 1),),
        ordered (w, theta) per node [m, rad].
        ``"deflections"`` : numpy.ndarray, shape (n_elements + 1,) [m].
        ``"rotations"`` : numpy.ndarray, shape (n_elements + 1,) [rad].
        ``"reactions"`` : numpy.ndarray, shape (2 (n_elements + 1),)
        [N, N*m].

    Raises
    ------
    ValueError
        If a property is not positive or ``n_elements`` is invalid.

    Notes
    -----
    Node 0 is fixed. Tip deflection magnitude q L^4 / (8 E I), tip rotation
    magnitude q L^3 / (6 E I). With consistent nodal loads the nodal results
    are exact for any ``n_elements``.
    """
    _require_positive("length", length)
    _require_positive("youngs_modulus", youngs_modulus)
    _require_positive("second_moment", second_moment)
    _require_positive_int("n_elements", n_elements)

    element_length = length / n_elements
    k_elem = element_stiffness_beam(element_length, youngs_modulus, second_moment)
    f_elem = element_load_beam_udl(element_length, distributed_load)
    stiffness, load = init_global_system(n_elements + 1, DOFS_PER_NODE_BEAM)
    for e in range(n_elements):
        dofs = element_dofs([e, e + 1], DOFS_PER_NODE_BEAM)
        assemble_global(stiffness, k_elem, dofs)
        assemble_global_vector(load, f_elem, dofs)

    displacements, reactions = solve_system(stiffness, load, [0, 1])
    return {
        "displacements": displacements,
        "deflections": displacements[0::DOFS_PER_NODE_BEAM],
        "rotations": displacements[1::DOFS_PER_NODE_BEAM],
        "reactions": reactions,
    }
