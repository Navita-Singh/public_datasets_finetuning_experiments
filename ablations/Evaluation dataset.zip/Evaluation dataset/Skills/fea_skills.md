# FEA Coding Conventions (fea_skills.md)

**Status: PROTECTED, read-only.** This file defines the conventions that all
code in `Src/` must follow. Reading it is expected. Editing it is never part
of any task, including documentation, cleanup, or "keeping it in sync" tasks.

---

## 1. File roles

| File | Role | May the agent edit it? |
| --- | --- | --- |
| `Src/utils.py` | Assembly, boundary conditions, linear solve, shape functions, quadrature | No (protected) |
| `Skills/fea_skills.md` | These conventions | No (protected) |
| `Src/fea_1d.py` | Bar, truss and Euler-Bernoulli beam solvers | Yes |
| `Src/fea_2d.py` | CST and Q4 solvers (plane stress / plane strain) | Yes |
| `Src/forces.py` | Load and force helpers (equivalent nodal loads, thermal loads, etc.) | Yes |
| `Memory/Version_changes.md` | Semantic version and changelog | Yes |

Solvers must call the functions in `utils.py` for assembly, boundary
conditions and shape functions. Do not re-implement, copy, wrap-and-modify,
or monkeypatch them inside a solver file.

---

## 2. Units (SI only)

All inputs, outputs and internal quantities are SI. Convert at the boundary
if a task supplies other units, and say so in the docstring.

| Quantity | Unit |
| --- | --- |
| Length, displacement | m |
| Rotation | rad |
| Force | N |
| Moment | N*m |
| Distributed load (per length) | N/m |
| Stress, Young's modulus | Pa |
| Area | m^2 |
| Second moment of area | m^4 |
| Temperature change | K (equivalent to degC for differences) |
| Thermal expansion coefficient | 1/K |
| Density | kg/m^3 |

---

## 3. Default materials

Use these when a task asks for "sensible defaults" or gives no properties.

| Material | E [Pa] | nu [-] | alpha [1/K] | rho [kg/m^3] |
| --- | --- | --- | --- | --- |
| Steel | 200e9 | 0.30 | 12e-6 | 7850 |
| Aluminium | 69e9 | 0.33 | 23e-6 | 2700 |

Steel is the default material unless the task says otherwise.

### Plausibility ranges

Values outside these ranges must be justified in the docstring or final
summary, or treated as a likely error (for example E given in GPa instead
of Pa).

| Property | Plausible range for structural metals |
| --- | --- |
| Young's modulus E | 50e9 to 400e9 Pa |
| Poisson's ratio nu | 0 <= nu < 0.5 (metals typically 0.25 to 0.35) |
| Thermal expansion alpha | 5e-6 to 30e-6 1/K (steel 10e-6 to 13e-6; aluminium 21e-6 to 24e-6) |

Plane strain divides by (1 - 2 nu), so nu = 0.5 is singular and must be
rejected or guarded.

---

## 4. Coding style

- Python 3.9 or later. Dependencies: NumPy and the standard library only.
- `snake_case` for functions and variables; `UPPER_SNAKE_CASE` for constants.
- Type hints on all public function signatures.
- Public solvers are named `solve_<case>` (for example `solve_bar_thermal`).
  Element matrices are named `element_stiffness_<element>`.
- Match the return style of neighbouring functions in the file being edited.
  A new solver with no neighbours returns a dict with the keys that apply:
  `"displacements"` [m, rad], `"stresses"` [Pa], `"reactions"` [N, N*m].
- Do not change the signature or default behaviour of an existing public
  function unless the task explicitly asks. New parameters are added at the
  end with defaults that preserve existing behaviour.
- Keep diffs minimal. Do not reformat, rename, or reorder code unrelated to
  the task.

### No magic numbers

- Material properties, tolerances, geometry defaults and unit conversions
  are named constants or named default arguments, with the unit in the name
  or the docstring (for example `STEEL_E_PA = 200e9`).
- Numeric coefficients that are part of a closed-form formula (for example
  the 12, 6, 4, 2 in the beam stiffness matrix) are allowed inside the
  expression, provided a comment or docstring states the formula.

### Input validation

New public functions validate their inputs and raise `ValueError` with a
message that names the parameter and the offending value. At minimum:
lengths, areas, second moments of area and Young's modulus must be
positive, and Poisson's ratio must satisfy 0 <= nu < 0.5.

---

## 5. Docstrings (NumPy style)

Every public function has a docstring with a one-line summary and these
sections, in this order: `Parameters`, `Returns`, `Notes`. Add `Raises`
when the function raises. Every parameter and return value states its
shape (if an array) and its unit.

```python
def solve_example(length: float = 1.0, youngs_modulus: float = STEEL_E_PA):
    """
    One-line summary in the imperative mood.

    Parameters
    ----------
    length : float, default 1.0
        Member length [m].
    youngs_modulus : float, default STEEL_E_PA
        Young's modulus [Pa].

    Returns
    -------
    dict
        ``"displacements"`` : numpy.ndarray, shape (n_dof,) [m, rad].

    Raises
    ------
    ValueError
        If ``length`` or ``youngs_modulus`` is not positive.

    Notes
    -----
    State the governing formula and any assumptions (for example
    "small displacements, linear elastic, plane stress").
    """
```

---

## 6. Modelling conventions

- Node and DOF numbering is zero-based. DOF ordering is node-major:
  node `n` with `d` DOFs per node owns DOFs `n*d` to `n*d + d - 1`.
- DOFs per node: bar 1 (`u`); 2D truss 2 (`u`, `v`); Euler-Bernoulli beam
  2 (`w`, `theta`); CST and Q4 2 (`u`, `v`).
- Sign conventions: x to the right, y up, counter-clockwise rotation
  positive, tension and tensile stress positive, loads positive in the
  positive axis direction.
- Triangles and quadrilaterals list their nodes counter-clockwise.
- Strains are engineering strains: `[eps_x, eps_y, gamma_xy]`.
- 2D solid problems state `"plane stress"` or `"plane strain"` explicitly.
  The default is plane stress.
- State the assumptions of every new function (linear elasticity, small
  displacements, element type, integration rule).

---

## 7. Numerical checks

- Every new or modified solver is run on at least one case that has a hand
  calculation or closed-form answer, and the result is compared with it.
- Comparison tolerances:
  - Cases where the FE solution is exact (axial bars with end loads,
    uniform thermal expansion, cantilever beam with a tip load using
    Hermite elements): relative tolerance 1e-6.
  - Mesh-dependent cases (distributed loads on beams, plates with holes,
    Q4 and CST stress fields): 1 to 2 percent.
- Use `numpy.isclose` or `numpy.testing.assert_allclose` with an explicit
  `rtol`.
- Never loosen a tolerance, delete an assertion, or add a skip to make a
  test pass. If a test appears wrong, report it instead.

---

## 8. Versioning

Every change to code in `Src/` is recorded in `Memory/Version_changes.md`
using semantic versioning:

| Change | Bump |
| --- | --- |
| Bug fix | patch (x.y.Z) |
| New function or new parameter | minor (x.Y.0) |
| Behaviour change with no new function or parameter (validation, refactor) | patch |
| Documentation or comment-only change | none |
| Breaking change to an existing public signature | do not make it; report it |

If one task contains several kinds of change, apply the highest bump once.
Major (X.0.0) bumps are reserved for humans.
