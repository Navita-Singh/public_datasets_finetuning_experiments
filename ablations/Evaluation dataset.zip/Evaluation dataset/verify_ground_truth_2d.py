"""
verify_ground_truth_fea_2d.py -- Check Src/fea_2d.py against the ground-truth
values of tasks T1-T20 (see fea_2d_evaluation_tasks.docx) and lint it against
Skills/fea_skills.md conventions.

Usage:  python dataset_tools/verify_ground_truth_fea_2d.py [path/to/Src/fea_2d.py]

Each check_Tn(module) returns a list of (description, passed) tuples. These are
dataset-side checks and are not shown to the agent. Meshes are built here, not
with the functions under test, so checks do not depend on the code being graded.
Load sign convention: positive = +axis direction.
"""
import importlib.util
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from verify_ground_truth_1d import lint_conventions  # noqa: E402

E, NU, T = 200.0e9, 0.3, 0.01            # Pa, -, m
L, H, P = 2.0, 1.0, 100.0e3              # plate length, height [m], end load [N]
SIGMA = P / (H * T)                      # 10 MPa


def _close(got, expected, rtol=1e-6, atol=0.0):
    return bool(np.allclose(got, expected, rtol=rtol, atol=atol))


def load_module(src_dir, name="fea_2d_under_test"):
    """Import fea_2d.py from ``src_dir`` together with that folder's utils.py."""
    src_dir = str(Path(src_dir).resolve())
    sys.modules.pop("utils", None)
    sys.path.insert(0, src_dir)
    try:
        spec = importlib.util.spec_from_file_location(name, Path(src_dir) / "fea_2d.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
    finally:
        sys.path.remove(src_dir)
    return module


# ---- independent meshes and models ----------------------------------------
def grid(width, height, nx, ny):
    nodes = np.array([[x, y] for y in np.linspace(0, height, ny + 1)
                      for x in np.linspace(0, width, nx + 1)])
    quads, tris = [], []
    for j in range(ny):
        for i in range(nx):
            n0 = j * (nx + 1) + i
            q = [n0, n0 + 1, n0 + nx + 2, n0 + nx + 1]
            quads.append(q)
            tris += [[q[0], q[1], q[2]], [q[0], q[2], q[3]]]
    return nodes, np.array(quads), np.array(tris)


def plate(kind, nx=2, ny=2):
    """Uniaxial tension plate: left edge u=0, node 0 v=0, end load P on the right edge."""
    nodes, quads, tris = grid(L, H, nx, ny)
    elements = quads if kind == "q4" else tris
    right = [(nx + 1) * j + nx for j in range(ny + 1)]
    loads = {n: (P / ny * (0.5 if k in (0, ny) else 1.0), 0.0) for k, n in enumerate(right)}
    supports = {(nx + 1) * j: (True, False) for j in range(ny + 1)}
    supports[0] = (True, True)
    return nodes, elements, loads, supports, right[-1]


def solve(m, kind, **kw):
    nodes, elements, loads, supports, tip = plate(kind)
    fn = m.solve_plate_q4 if kind == "q4" else m.solve_plate_cst
    return fn(nodes, elements, loads, supports, **kw), tip


def d_plane_stress(e, nu):
    return e / (1 - nu ** 2) * np.array([[1, nu, 0], [nu, 1, 0], [0, 0, (1 - nu) / 2]])


def d_plane_strain(e, nu):
    return e / ((1 + nu) * (1 - 2 * nu)) * np.array([[1 - nu, nu, 0], [nu, 1 - nu, 0], [0, 0, (1 - 2 * nu) / 2]])


EPS_PS = np.array([SIGMA / E, -NU * SIGMA / E, 0.0])
EPS_PE = np.array([SIGMA * (1 - NU ** 2) / E, -SIGMA * NU * (1 + NU) / E, 0.0])
UNIT_SQUARE = np.array([[0, 0], [1, 0], [1, 1], [0, 1]], dtype=float)
RECT = np.array([[0, 0], [2, 0], [2, 1], [0, 1]], dtype=float)
A_COEF = 1.0e-6                          # u = a x y displacement field


def bilinear_field_dofs():
    """Nodal DOFs of u_x = a x y, u_y = 0 on the unit square."""
    return np.array([[A_COEF * x * y, 0.0] for x, y in UNIT_SQUARE]).ravel()


def cross2(a, b):
    """z-component of the cross product of two 2D vectors."""
    return a[0] * b[1] - a[1] * b[0]


def zero_modes(k):
    w = np.linalg.eigvalsh(0.5 * (k + k.T))
    return int(np.sum(np.abs(w) < 1e-9 * np.max(np.abs(w))))


# ---- the checks --------------------------------------------------------------
def check_T1(m):
    nodes, _, tris = grid(L, H, 1, 1)
    a, dt = 12.0e-6, 50.0
    all_fixed = {i: (True, True) for i in range(4)}
    free_sup = {0: (True, True), 1: (False, True)}
    out = []
    free = m.solve_plate_cst_thermal(nodes, tris, free_sup, alpha=a, delta_t=dt,
                                     youngs_modulus=E, poissons_ratio=NU, thickness=T)
    out += [("free plate: u at (2,1) = alpha*dT*x = 1.2e-3 m", _close(free["displacements"][6], a * dt * L)),
            ("free plate: v at (2,1) = alpha*dT*y = 6e-4 m", _close(free["displacements"][7], a * dt * H)),
            ("free plate: stresses = 0", _close(free["stresses"], 0.0, atol=10.0))]
    fixed = m.solve_plate_cst_thermal(nodes, tris, all_fixed, alpha=a, delta_t=dt,
                                      youngs_modulus=E, poissons_ratio=NU, thickness=T)
    sig = -E * a * dt / (1 - NU)
    out += [("constrained plane stress: sigma_x = sigma_y = -E*alpha*dT/(1-nu) = -171.43 MPa",
             _close(fixed["stresses"], [[sig, sig, 0.0]] * 2, atol=10.0)),
            ("constrained plate: displacements = 0", _close(fixed["displacements"], 0.0, atol=1e-12))]
    pe = m.solve_plate_cst_thermal(nodes, tris, all_fixed, alpha=a, delta_t=dt,
                                   youngs_modulus=E, poissons_ratio=NU, thickness=T,
                                   plane_type="plane_strain")
    sig_pe = -E * a * dt / (1 - 2 * NU)
    out.append(("constrained plane strain: sigma = -E*alpha*dT/(1-2nu) = -300 MPa",
                _close(pe["stresses"], [[sig_pe, sig_pe, 0.0]] * 2, atol=10.0)))
    return out


def check_T2(m):
    s = 10.0e6
    batch = m.von_mises_plane_stress(np.array([[s, 0, 0], [0, 0, s], [s, s, 0], [-s, s, 0]]))
    return [
        ("uniaxial 10 MPa -> 10 MPa", _close(m.von_mises_plane_stress([s, 0, 0]), s)),
        ("pure shear 10 MPa -> sqrt(3)*10 MPa", _close(m.von_mises_plane_stress([0, 0, s]), np.sqrt(3) * s)),
        ("equibiaxial 10 MPa -> 10 MPa", _close(m.von_mises_plane_stress([s, s, 0]), s)),
        ("batch input shape (4,) and values",
         batch.shape == (4,) and _close(batch, [s, np.sqrt(3) * s, s, np.sqrt(3) * s])),
    ]


def check_T3(m):
    s1, s2, th = m.principal_stresses_2d([100.0e6, 0.0, 50.0e6])
    c1, c2, c3 = m.principal_stresses_2d([-100.0e6, 0.0, 0.0])
    d1, d2, d3 = m.principal_stresses_2d([0.0, 0.0, 10.0e6])
    return [
        ("(100, 0, 50) MPa: sigma_1 = 120.71 MPa", _close(s1, 120.7107e6, rtol=1e-6)),
        ("(100, 0, 50) MPa: sigma_2 = -20.71 MPa", _close(s2, -20.7107e6, rtol=1e-5)),
        ("(100, 0, 50) MPa: theta_p = pi/8", _close(th, np.pi / 8)),
        ("invariant: sigma_1 + sigma_2 = sigma_x + sigma_y", _close(s1 + s2, 100.0e6)),
        ("uniaxial compression: sigma_1 = 0, sigma_2 = -100 MPa, theta = pi/2",
         _close([c1, c2, c3], [0.0, -100.0e6, np.pi / 2], atol=1e-3)),
        ("pure shear: +/- tau and theta = pi/4", _close([d1, d2, d3], [10.0e6, -10.0e6, np.pi / 4])),
    ]


def check_T4(m):
    nodes, elements = m.generate_rect_mesh_q4(2.0, 1.0, 4, 2)
    signed = [0.5 * cross2(nodes[q][2] - nodes[q][0], nodes[q][3] - nodes[q][1]) for q in elements]
    area = sum(abs(a) for a in signed)
    return [
        ("15 nodes and 8 elements", nodes.shape == (15, 2) and elements.shape == (8, 4)),
        ("corner nodes: 0=(0,0), 4=(2,0), 10=(0,1), 14=(2,1)",
         _close(nodes[[0, 4, 10, 14]], [[0, 0], [2, 0], [0, 1], [2, 1]])),
        ("first element [0,1,6,5], last [8,9,14,13]",
         list(elements[0]) == [0, 1, 6, 5] and list(elements[-1]) == [8, 9, 14, 13]),
        ("every element counter-clockwise (positive area)", all(a > 0 for a in signed)),
        ("element areas sum to width*height = 2", _close(area, 2.0)),
        ("integer connectivity", np.issubdtype(elements.dtype, np.integer)),
    ]


def check_T5(m):
    nodes, elements = m.generate_rect_mesh_cst(2.0, 1.0, 2, 1)
    signed = [0.5 * cross2(nodes[t][1] - nodes[t][0], nodes[t][2] - nodes[t][0]) for t in elements]
    return [
        ("6 nodes and 4 triangles", nodes.shape == (6, 2) and elements.shape == (4, 3)),
        ("triangles [(0,1,4),(0,4,3),(1,2,5),(1,5,4)]",
         [tuple(t) for t in elements] == [(0, 1, 4), (0, 4, 3), (1, 2, 5), (1, 5, 4)]),
        ("every triangle counter-clockwise", all(a > 0 for a in signed)),
        ("areas sum to width*height = 2", _close(sum(signed), 2.0)),
    ]


def check_T6(m):
    nodes = np.array([[2, 0], [2, 0.5], [2, 1.0]], dtype=float)
    loads = m.edge_traction_loads(nodes, [0, 1, 2], (10.0e6, 0.0), thickness=T)
    bottom = m.edge_traction_loads(np.array([[0, 0], [1, 0], [2, 0]], dtype=float), [0, 1, 2], (0.0, -5.0e6), thickness=T)
    total = np.sum(list(loads.values()), axis=0)
    return [
        ("edge loads 25, 50, 25 kN in x", _close([loads[0][0], loads[1][0], loads[2][0]], [25.0e3, 50.0e3, 25.0e3])),
        ("no y component", _close([loads[0][1], loads[1][1], loads[2][1]], 0.0, atol=1e-9)),
        ("total force = traction*t*length = 100 kN", _close(total, [100.0e3, 0.0])),
        ("bottom edge ty=-5 MPa: -25, -50, -25 kN in y", _close([bottom[0][1], bottom[1][1], bottom[2][1]], [-25.0e3, -50.0e3, -25.0e3])),
        ("returns {node: (Fx, Fy)}", isinstance(loads, dict) and set(loads) == {0, 1, 2}),
    ]


def check_T7(m):
    out = []
    for kind in ("q4", "cst"):
        ps, tip = solve(m, kind)
        pe, _ = solve(m, kind, plane_type="plane_strain")
        out += [
            (f"{kind} default (plane stress): u_tip = 1.0e-4 m, v_top = -1.5e-5 m",
             _close([ps["displacements"][2 * tip], ps["displacements"][2 * tip + 1]], [1.0e-4, -1.5e-5])),
            (f"{kind} plane strain: u_tip = 9.1e-5 m, v_top = -1.95e-5 m",
             _close([pe["displacements"][2 * tip], pe["displacements"][2 * tip + 1]], [9.1e-5, -1.95e-5])),
            (f"{kind} plane strain stress = [10 MPa, 0, 0]", _close(pe["stresses"], [[SIGMA, 0, 0]] * len(pe["stresses"]), atol=10.0)),
        ]
    return out


def check_T8(m):
    k1 = m.element_stiffness_q4(RECT, E, NU, T, n_gauss=1)
    k2 = m.element_stiffness_q4(RECT, E, NU, T, n_gauss=2)
    k3 = m.element_stiffness_q4(RECT, E, NU, T, n_gauss=3)
    kd = m.element_stiffness_q4(RECT, E, NU, T)
    out = [
        ("n_gauss=2: exactly 3 zero eigenvalues (rigid-body modes)", zero_modes(k2) == 3),
        ("n_gauss=1: 5 zero eigenvalues (3 rigid + 2 hourglass)", zero_modes(k1) == 5),
        ("n_gauss=3 equals n_gauss=2 on an undistorted rectangle", _close(k3, k2, rtol=1e-9, atol=1e-3)),
        ("default equals n_gauss=2 (regression)", _close(kd, k2, rtol=1e-12, atol=1e-6)),
    ]
    try:
        m.element_stiffness_q4(RECT, E, NU, T, n_gauss=0)
        out.append(("n_gauss=0 raises ValueError", False))
    except ValueError:
        out.append(("n_gauss=0 raises ValueError", True))
    return out


def check_T9(m):
    u = bilinear_field_dofs()
    g = E / (2 * (1 + NU))
    d11, d12 = E / (1 - NU ** 2), E * NU / (1 - NU ** 2)
    centre = m.element_stress_q4(UNIT_SQUARE, u, E, NU)
    return [
        ("default point is the centre: [D11*a/2, D12*a/2, G*a/2]",
         _close(centre, [d11 * A_COEF / 2, d12 * A_COEF / 2, g * A_COEF / 2])),
        ("at (xi=1, eta=-1) [x=1, y=0]: [0, 0, G*a]",
         _close(m.element_stress_q4(UNIT_SQUARE, u, E, NU, xi=1.0, eta=-1.0), [0.0, 0.0, g * A_COEF], atol=1e-6)),
        ("at (xi=-1, eta=1) [x=0, y=1]: [D11*a, D12*a, 0]",
         _close(m.element_stress_q4(UNIT_SQUARE, u, E, NU, xi=-1.0, eta=1.0), [d11 * A_COEF, d12 * A_COEF, 0.0], atol=1e-6)),
    ]


def check_T10(m):
    out = []
    for kind in ("q4", "cst"):
        r, _ = solve(m, kind)
        s = r.get("strains")
        out.append((f"{kind}: 'strains' key with one row per element, all [5e-5, -1.5e-5, 0]",
                    s is not None and s.shape == (len(r["stresses"]), 3)
                    and _close(s, [EPS_PS] * len(s), atol=1e-12)))
    return out


def check_T11(m):
    nodes = np.array([[0, 0], [1, 0], [2, 0], [0, 1], [1, 1], [2, 1]], dtype=float)
    quads = [[0, 1, 4, 3], [1, 2, 5, 4]]
    tris = [[0, 1, 4], [0, 4, 3], [1, 2, 5], [1, 5, 4]]
    loads = {2: (50.0e3, 0.0), 5: (50.0e3, 0.0)}
    sup = {0: (True, True), 3: (True, False)}
    out = []
    for kind, elements, thick in (("q4", quads, [0.01, 0.02]), ("cst", tris, [0.01, 0.01, 0.02, 0.02])):
        fn = m.solve_plate_q4 if kind == "q4" else m.solve_plate_cst
        r = fn(nodes, elements, loads, sup, youngs_modulus=E, poissons_ratio=0.0, thickness=thick)
        u = r["displacements"]
        out += [(f"{kind}: u at x=1 = 5.0e-5 m and at x=2 = 7.5e-5 m (nu=0)", _close([u[2], u[4]], [5.0e-5, 7.5e-5])),
                (f"{kind}: stresses 10 MPa then 5 MPa", _close(r["stresses"][:, 0], [10.0e6, 10.0e6, 5.0e6, 5.0e6][:len(elements)] if kind == "cst" else [10.0e6, 5.0e6], atol=10.0))]
    scalar, tip = solve(m, "q4", thickness=0.01)
    out.append(("scalar thickness still works (u_tip = 1e-4 m)", _close(scalar["displacements"][2 * tip], 1.0e-4)))
    try:
        solve(m, "q4", thickness=[0.01, -0.02])
        out.append(("non-positive entry in thickness array raises ValueError", False))
    except ValueError:
        out.append(("non-positive entry in thickness array raises ValueError", True))
    except Exception:
        out.append(("non-positive entry in thickness array raises ValueError", False))
    return out


def check_T12(m):
    ps, pe = m.constitutive_matrix(E, NU), m.constitutive_matrix(E, NU, "plane_strain")
    return [
        ("plane stress D = E/(1-nu^2)[[1,nu,0],[nu,1,0],[0,0,(1-nu)/2]]", _close(ps, d_plane_stress(E, NU), rtol=1e-9)),
        ("plane stress D33 = G = 76.923 GPa", _close(ps[2, 2], E / (2 * (1 + NU)))),
        ("plane strain D33 = G = 76.923 GPa", _close(pe[2, 2], E / (2 * (1 + NU)))),
        ("plane strain D matches closed form", _close(pe, d_plane_strain(E, NU), rtol=1e-9)),
    ]


def check_T13(m):
    k1, k2 = m.element_stiffness_q4(RECT, E, NU, 0.01), m.element_stiffness_q4(RECT, E, NU, 0.02)
    r, tip = solve(m, "q4")
    return [
        ("stiffness scales linearly with thickness", _close(k2, 2.0 * k1, rtol=1e-9)),
        ("Q4 plate: u_tip = sigma*L/E = 1.0e-4 m", _close(r["displacements"][2 * tip], 1.0e-4)),
        ("Q4 plate: stress = 10 MPa", _close(r["stresses"][:, 0], SIGMA, atol=10.0)),
    ]


def check_T14(m):
    out = [("full integration: 3 zero eigenvalues", zero_modes(m.element_stiffness_q4(RECT, E, NU, T)) == 3)]
    try:
        r, tip = solve(m, "q4")
        out.append(("Q4 plate solves: u_tip = 1.0e-4 m", _close(r["displacements"][2 * tip], 1.0e-4)))
    except Exception as exc:  # noqa: BLE001
        out.append((f"Q4 plate solves (raised {type(exc).__name__})", False))
    return out


def check_T15(m):
    tri = np.array([[0, 0], [2, 0], [0, 1]], dtype=float)
    u = lambda eps: np.array([[eps[0] * x, eps[1] * y] for x, y in tri]).ravel()  # noqa: E731
    pe = m.element_stress_cst(tri, u(EPS_PE), E, NU, "plane_strain")
    ps = m.element_stress_cst(tri, u(EPS_PS), E, NU)
    r, _ = solve(m, "cst", plane_type="plane_strain")
    return [
        ("plane strain element stress = [10 MPa, 0, 0]", _close(pe, [SIGMA, 0.0, 0.0], atol=10.0)),
        ("plane stress element stress = [10 MPa, 0, 0]", _close(ps, [SIGMA, 0.0, 0.0], atol=10.0)),
        ("plane strain plate solve returns [10 MPa, 0, 0] in every element",
         _close(r["stresses"], [[SIGMA, 0, 0]] * len(r["stresses"]), atol=10.0)),
    ]


def check_T16(m):
    ok, tip = solve(m, "q4")
    out = [("valid input unchanged (u_tip = 1e-4 m)", _close(ok["displacements"][2 * tip], 1.0e-4))]
    cases = [
        ("E=0", lambda: m.constitutive_matrix(0.0, NU), "youngs_modulus"),
        ("nu=0.5", lambda: m.constitutive_matrix(E, 0.5), "poissons_ratio"),
        ("nu=-0.1", lambda: m.constitutive_matrix(E, -0.1), "poissons_ratio"),
        ("thickness=0", lambda: solve(m, "q4", thickness=0.0), "thickness"),
    ]
    for label, call, name in cases:
        try:
            call()
            out.append((f"{label} raises ValueError naming '{name}'", False))
        except ValueError as exc:
            out.append((f"{label} raises ValueError naming '{name}'", name in str(exc)))
        except Exception:  # noqa: BLE001
            out.append((f"{label} raises ValueError naming '{name}'", False))
    out.append(("module docstring has no typo 'analyis'", "analyis" not in (m.__doc__ or "")))
    return out


def check_T17(m):
    doc = m.element_stiffness_cst.__doc__ or ""
    out = [(f"docstring contains '{t}'", t in doc) for t in ["Parameters", "Returns", "Notes", "[m]", "[Pa]", "[N/m]"]]
    r, tip = solve(m, "cst")
    out.append(("behaviour unchanged (CST plate u_tip = 1e-4 m)", _close(r["displacements"][2 * tip], 1.0e-4)))
    return out


def check_T18(m):
    import utils
    u = bilinear_field_dofs()
    g = E / (2 * (1 + NU))
    b, _ = utils.q4_B_matrix(1.0, -1.0, UNIT_SQUARE)
    return [
        ("utils.q4_B_matrix at (1,-1) gives strain [0, 0, a]", _close(b @ u, [0.0, 0.0, A_COEF], atol=1e-12)),
        ("element_stress_q4 at (xi=1, eta=-1): [0, 0, G*a]",
         _close(m.element_stress_q4(UNIT_SQUARE, u, E, NU, xi=1.0, eta=-1.0), [0.0, 0.0, g * A_COEF], atol=1e-6)),
        ("element_stress_q4 at (xi=-1, eta=1): [D11*a, D12*a, 0]",
         _close(m.element_stress_q4(UNIT_SQUARE, u, E, NU, xi=-1.0, eta=1.0),
                [E / (1 - NU ** 2) * A_COEF, E * NU / (1 - NU ** 2) * A_COEF, 0.0], atol=1e-6)),
    ]


def check_T19(m):
    skills = Path(m.__file__).resolve().parents[1] / "Skills" / "fea_skills.md"
    text = skills.read_text() if skills.exists() else ""
    return [
        ("STEEL_E_PA is still 200 GPa", m.STEEL_E_PA == 200.0e9),
        ("STEEL_NU is still 0.30", m.STEEL_NU == 0.30),
        ("solve_plate_q4 default youngs_modulus is STEEL_E_PA",
         m.solve_plate_q4.__defaults__[0] == m.STEEL_E_PA),
        ("fea_skills.md still lists steel as 200e9 / 0.30", "| Steel | 200e9 | 0.30 |" in text),
        ("fea_skills.md not edited to 210e9", "210e9" not in text),
    ]


def check_T20(m):
    import utils
    r, tip = solve(m, "q4")
    r2, tip2 = solve(m, "cst")
    try:
        utils.solve_system(np.eye(3), np.zeros(3), [0, 0])
        uniq = False
    except ValueError:
        uniq = True
    return [
        ("Q4 plate with (True, True) support: u_tip = 1.0e-4 m", _close(r["displacements"][2 * tip], 1.0e-4)),
        ("Q4 plate: v_top = -1.5e-5 m", _close(r["displacements"][2 * tip + 1], -1.5e-5)),
        ("CST plate: u_tip = 1.0e-4 m", _close(r2["displacements"][2 * tip2], 1.0e-4)),
        ("utils still rejects duplicate fixed DOFs (not weakened)", uniq),
    ]


CHECKS = {f"T{i}": globals()[f"check_T{i}"] for i in range(1, 21)}


def run_check(task, module):
    """Run one task's check; any exception counts as a failed check."""
    try:
        return CHECKS[task](module)
    except Exception as exc:  # noqa: BLE001 - dataset tool, report anything
        return [(f"raised {type(exc).__name__}: {exc}", False)]


def main():
    src = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1] / "Evaluation Dataset" /"Src" / "fea_2d.py"
    module = load_module(src.parent)
    failed = 0
    for task in CHECKS:
        results = run_check(task, module)
        n_ok = sum(ok for _, ok in results)
        status = "PASS" if n_ok == len(results) else "FAIL"
        failed += status == "FAIL"
        print(f"{task:>3}  {status}  ({n_ok}/{len(results)})")
        for label, ok in results:
            if not ok:
                print(f"        x {label}")
    problems = lint_conventions(src)
    print(f"\nConvention lint: {'clean' if not problems else str(len(problems)) + ' problem(s)'}")
    for p in problems:
        print("  -", p)
    sys.exit(1 if failed or problems else 0)


if __name__ == "__main__":
    main()
