# Version changes

Semantic version rule (newest entry first; the current version is the top entry):

- Bug fix: patch bump (x.y.Z).
- New function or new parameter: minor bump (x.Y.0).
- Behaviour change with no new function or parameter (validation, refactor): patch bump.
- Documentation or comment-only change: no bump and no entry.
- Mixed changes: apply the highest bump once. Major bumps are reserved for humans.

Entry format:

```
## vX.Y.Z (YYYY-MM-DD)
- Type: bug fix | new function | modified function | validation
- Files: Src/fea_1d.py
- Change: one or two sentences.
- Why it matters: one sentence.
```

## v0.1.0 (2026-11-12)
- Type: new function
- Files: Src/utils.py, Src/fea_1d.py
- Change: Initial baseline. Shared utilities (assembly, boundary conditions, shape functions) and 1D solvers for an axial bar, a 2D truss and an Euler-Bernoulli beam.
- Why it matters: Establishes the verified starting point for all later changes.
